// ---------------------------------------------------------------------------
// Camada de normalização — tipos internos e estáveis da plataforma.
// Nenhuma tela do frontend depende do JSON bruto de um fornecedor específico.
// Qualquer VehicleDataProvider (src/lib/vehicle-provider) deve produzir
// exatamente esta forma através do normalizador.
// ---------------------------------------------------------------------------

export type FindingStatus = 'ok' | 'attention' | 'restriction' | 'unavailable'

export interface Finding {
  status: FindingStatus
  label: string
  detail?: string
}

export interface VehicleIdentity {
  plate: string
  plateFormat: 'antiga' | 'mercosul'
  brand: string
  model: string
  manufactureYear: number
  modelYear: number
  fuel: string
  color: string
  category: string
  species: string
  city: string
  state: string
  chassisMasked?: string
  renavamMasked?: string
}

export interface AttentionScore {
  value: number // 0-100 — quanto menor, melhor (menos pontos de atenção)
  label: string
  isInterpretive: true
}

export interface VehicleReport {
  protocol: string
  productSlug: string
  productName: string
  queriedAt: string // ISO
  provider: string
  plateInput: string
  identity: VehicleIdentity
  score: AttentionScore
  summary: Finding[]
  sections: {
    theft: Finding
    restrictions: Finding
    lien: Finding
    debts: Finding
    claims: Finding
    recall: Finding
    auction: Finding
    other: Finding
  }
}

export interface QuickLookupResult {
  found: boolean
  plate: string
  brand?: string
  model?: string
  modelYear?: string
  message: string
}
