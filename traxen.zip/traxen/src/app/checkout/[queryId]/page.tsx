import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueryById } from '@/lib/store'
import { CheckoutFlow } from '@/components/checkout/checkout-flow'

export const metadata: Metadata = { title: 'Pagamento', robots: { index: false } }

export default async function CheckoutPage({ params }: { params: { queryId: string } }) {
  const user = await getCurrentUser()
  if (!user) redirect(`/entrar?next=/checkout/${params.queryId}`)

  const query = getQueryById(params.queryId)
  if (!query || query.userId !== user.id) notFound()

  if (query.status === 'concluida') {
    redirect(`/painel/consultas/${query.id}`)
  }

  return (
    <CheckoutFlow
      query={{
        id: query.id,
        plate: query.plate,
        productName: query.productName,
        priceCents: query.priceCents,
        status: query.status,
        chargeId: query.chargeId,
      }}
    />
  )
}
