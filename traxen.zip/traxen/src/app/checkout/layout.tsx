import Link from 'next/link'
import { Logo } from '@/components/ui/logo'
import { Icon } from '@/components/ui/icons'

export default function CheckoutLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-surface-muted">
      <header className="border-b border-surface-border bg-white">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/painel">
            <Logo />
          </Link>
          <span className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-positive-600">
            <Icon.Lock className="h-3.5 w-3.5" /> Ambiente seguro
          </span>
        </div>
      </header>
      <main className="py-12">{children}</main>
    </div>
  )
}
