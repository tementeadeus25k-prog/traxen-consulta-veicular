import type { Metadata } from 'next'
import { Suspense } from 'react'
import { RegisterForm } from '@/components/auth/register-form'

export const metadata: Metadata = { title: 'Criar conta', robots: { index: false } }

export default function CadastroPage() {
  return (
    <Suspense>
      <RegisterForm />
    </Suspense>
  )
}
