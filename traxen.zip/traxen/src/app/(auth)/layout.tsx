import Link from 'next/link'
import { Logo } from '@/components/ui/logo'
import { Icon } from '@/components/ui/icons'

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-surface-muted">
      <header className="container flex h-20 items-center">
        <Link href="/" className="focus-ring rounded-md">
          <Logo />
        </Link>
      </header>

      <main className="flex flex-1 items-center justify-center px-5 py-10">{children}</main>

      <footer className="container flex flex-col items-center gap-3 pb-10 text-[12.5px] text-navy-300 sm:flex-row sm:justify-between">
        <p className="inline-flex items-center gap-1.5">
          <Icon.Lock className="h-3.5 w-3.5 text-electric-500" /> Conexão segura e criptografada
        </p>
        <div className="flex items-center gap-4">
          <Link href="/termos" className="hover:text-navy-600">Termos de uso</Link>
          <Link href="/privacidade" className="hover:text-navy-600">Privacidade</Link>
        </div>
      </footer>
    </div>
  )
}
