import type { Metadata } from 'next'
import '@fontsource-variable/inter'
import { ToastProvider } from '@/components/ui/toast'
import './globals.css'

const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://www.traxen.com.br'

export const metadata: Metadata = {
  metadataBase: new URL(appUrl),
  title: {
    default: 'Traxen — Consulta veicular completa e confiável',
    template: '%s · Traxen',
  },
  description:
    'Consulte o histórico de um veículo pela placa antes de comprar: restrições, débitos, roubo e furto, gravame e sinistros em um relatório claro e online.',
  keywords: [
    'consulta veicular',
    'consulta placa',
    'histórico veicular',
    'sinistro',
    'leilão',
    'roubo e furto',
    'gravame veicular',
  ],
  openGraph: {
    title: 'Traxen — Consulta veicular completa e confiável',
    description:
      'Conheça o histórico antes de comprar o veículo. Consulte pela placa e receba um relatório online em poucos minutos.',
    url: appUrl,
    siteName: 'Traxen',
    locale: 'pt_BR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Traxen — Consulta veicular completa e confiável',
    description: 'Conheça o histórico antes de comprar o veículo.',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen font-sans">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  )
}
