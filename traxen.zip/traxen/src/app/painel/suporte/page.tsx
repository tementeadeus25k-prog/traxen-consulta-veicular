import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHeader } from '@/components/dashboard/page-header'
import { SupportForm } from '@/components/dashboard/support-form'
import { Card, CardContent } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'

export const metadata: Metadata = { title: 'Suporte', robots: { index: false } }

const SHORTCUTS = [
  { href: '/duvidas', label: 'Central de dúvidas', icon: Icon.LifeBuoy },
  { href: '/painel/pagamentos', label: 'Meus pagamentos', icon: Icon.Card },
  { href: '/termos', label: 'Termos de uso', icon: Icon.Doc },
]

export default function SuportePage() {
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Suporte" description="Precisa de ajuda? Fale com a gente." />

      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        {SHORTCUTS.map((s) => (
          <Link key={s.href} href={s.href} className="flex items-center gap-2.5 rounded-xl border border-surface-border bg-white p-4 text-[13px] font-medium text-navy-600 transition-colors hover:border-navy-300">
            <s.icon className="h-4 w-4 text-electric-500" />
            {s.label}
          </Link>
        ))}
      </div>

      <Card>
        <CardContent className="p-7">
          <h2 className="mb-5 text-[15px] font-semibold text-navy-950">Abrir um chamado</h2>
          <SupportForm />
        </CardContent>
      </Card>
    </div>
  )
}
