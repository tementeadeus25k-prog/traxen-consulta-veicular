import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueryById } from '@/lib/store'
import { ReportView } from '@/components/report/report-view'
import { ReportActionsBar } from '@/components/report/report-actions-bar'
import { Icon } from '@/components/ui/icons'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export const metadata: Metadata = { title: 'Relatório da consulta', robots: { index: false } }

export default async function ConsultaDetailPage({ params }: { params: { id: string } }) {
  const user = await getCurrentUser()
  if (!user) redirect(`/entrar?next=/painel/consultas/${params.id}`)

  const query = getQueryById(params.id)
  if (!query || query.userId !== user.id) notFound()

  if (query.status === 'aguardando_pagamento') {
    redirect(`/checkout/${query.id}`)
  }

  if (query.status === 'processando') {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-24 text-center">
        <svg className="h-9 w-9 animate-spin text-electric-500" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-20" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
          <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v3.2A4.8 4.8 0 007.2 12H4z" />
        </svg>
        <p className="text-[14.5px] font-semibold text-navy-900">Estamos preparando sua consulta…</p>
        <p className="text-[13px] text-navy-400">Isso costuma levar apenas alguns instantes. Atualize a página em breve.</p>
      </div>
    )
  }

  if (query.status === 'falhou' || !query.report) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-24 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-critical-50 text-critical-600">
          <Icon.Alert className="h-6 w-6" />
        </div>
        <p className="text-[14.5px] font-semibold text-navy-900">Não foi possível concluir esta consulta</p>
        <p className="text-[13px] text-navy-400">Não localizamos o veículo na fonte consultada para a placa {query.plate}.</p>
        <Link href="/painel/nova-consulta">
          <Button variant="outline" className="mt-2">Tentar nova consulta</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="-mx-5 -my-7 sm:-mx-8 lg:-mx-10 lg:-my-9">
      <ReportActionsBar backHref="/painel/consultas" />
      <div className="mx-auto max-w-4xl px-5 py-8 sm:px-8">
        <ReportView report={query.report} id={(s) => s} />
      </div>
    </div>
  )
}
