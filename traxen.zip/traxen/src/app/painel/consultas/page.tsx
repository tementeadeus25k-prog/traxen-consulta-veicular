import type { Metadata } from 'next'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueriesByUser } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { ConsultasTable } from '@/components/dashboard/consultas-table'

export const metadata: Metadata = { title: 'Minhas consultas', robots: { index: false } }

export default async function ConsultasPage() {
  const user = (await getCurrentUser())!
  const queries = getQueriesByUser(user.id)

  return (
    <div>
      <PageHeader title="Minhas consultas" description="Histórico completo das consultas realizadas na sua conta." />
      <ConsultasTable queries={queries} />
    </div>
  )
}
