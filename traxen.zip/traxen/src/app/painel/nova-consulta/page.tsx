import type { Metadata } from 'next'
import { Suspense } from 'react'
import { NovaConsultaFlow } from '@/components/dashboard/nova-consulta-flow'

export const metadata: Metadata = { title: 'Nova consulta', robots: { index: false } }

export default function NovaConsultaPage() {
  return (
    <Suspense>
      <NovaConsultaFlow />
    </Suspense>
  )
}
