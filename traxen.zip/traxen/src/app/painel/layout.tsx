import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth/current-user'
import { DashboardShell } from '@/components/dashboard/shell'

export default async function PainelLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()
  if (!user) redirect('/entrar?next=/painel')

  return (
    <DashboardShell userName={user.name} userEmail={user.email}>
      {children}
    </DashboardShell>
  )
}
