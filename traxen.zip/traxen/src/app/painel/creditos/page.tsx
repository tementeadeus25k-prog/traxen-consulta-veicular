import type { Metadata } from 'next'
import { getCurrentUser } from '@/lib/auth/current-user'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { StatCard } from '@/components/ui/stat-card'
import { Card } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'
import { AddCreditPanel } from '@/components/dashboard/add-credit-panel'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { cn, formatCurrencyBRL, formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Créditos', robots: { index: false } }

export default async function CreditosPage() {
  const user = (await getCurrentUser())!
  const transactions = store.wallet.filter((w) => w.userId === user.id)

  return (
    <div>
      <PageHeader title="Créditos" description="Use saldo em carteira para agilizar suas próximas consultas." />

      <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-start">
        <StatCard label="Saldo disponível" value={formatCurrencyBRL(user.walletCents)} icon={<Icon.Wallet className="h-5 w-5" />} hint="atualizado agora" />
        <AddCreditPanel />
      </div>

      <Card className="mt-8">
        <div className="border-b border-surface-border px-6 py-4">
          <h2 className="text-[15px] font-semibold text-navy-950">Movimentações</h2>
        </div>
        {transactions.length === 0 ? (
          <p className="px-6 py-10 text-center text-[13.5px] text-navy-400">Nenhuma movimentação ainda.</p>
        ) : (
          <Table>
            <THead>
              <tr>
                <TH>Data</TH>
                <TH>Descrição</TH>
                <TH className="text-right">Entrada</TH>
                <TH className="text-right">Saída</TH>
                <TH className="text-right">Saldo</TH>
              </tr>
            </THead>
            <TBody>
              {transactions.map((t) => (
                <TR key={t.id}>
                  <TD>{formatDate(t.createdAt, true)}</TD>
                  <TD>{t.description}</TD>
                  <TD className={cn('text-right font-semibold', t.amountCents > 0 ? 'text-positive-600' : 'text-navy-200')}>
                    {t.amountCents > 0 ? formatCurrencyBRL(t.amountCents) : '—'}
                  </TD>
                  <TD className={cn('text-right font-semibold', t.amountCents < 0 ? 'text-critical-600' : 'text-navy-200')}>
                    {t.amountCents < 0 ? formatCurrencyBRL(Math.abs(t.amountCents)) : '—'}
                  </TD>
                  <TD className="text-right font-semibold text-navy-950">{formatCurrencyBRL(t.balanceAfterCents)}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </Card>
    </div>
  )
}
