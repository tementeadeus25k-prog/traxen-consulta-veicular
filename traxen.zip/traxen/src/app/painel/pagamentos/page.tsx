import type { Metadata } from 'next'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueriesByUser } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { Card } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'
import { QueryStatusBadge } from '@/components/dashboard/query-status-badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { formatCurrencyBRL, formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Pagamentos', robots: { index: false } }

export default async function PagamentosPage() {
  const user = (await getCurrentUser())!
  const queries = getQueriesByUser(user.id)

  return (
    <div>
      <PageHeader title="Pagamentos" description="Cobranças realizadas na sua conta, por consulta." />
      <Card>
        {queries.length === 0 ? (
          <p className="px-6 py-16 text-center text-[13.5px] text-navy-400">Nenhum pagamento realizado ainda.</p>
        ) : (
          <Table>
            <THead>
              <tr>
                <TH>Data</TH>
                <TH>Descrição</TH>
                <TH>Método</TH>
                <TH className="text-right">Valor</TH>
                <TH>Status</TH>
              </tr>
            </THead>
            <TBody>
              {queries.map((q) => (
                <TR key={q.id}>
                  <TD>{formatDate(q.createdAt, true)}</TD>
                  <TD>{q.productName} · <span className="font-mono-plate">{q.plate}</span></TD>
                  <TD>
                    <span className="inline-flex items-center gap-1.5 text-navy-600">
                      {q.paymentMethod === 'card' ? <Icon.Card className="h-3.5 w-3.5" /> : <Icon.Pix className="h-3.5 w-3.5" />}
                      {q.paymentMethod === 'card' ? 'Cartão' : 'PIX'}
                    </span>
                  </TD>
                  <TD className="text-right font-semibold text-navy-950">{formatCurrencyBRL(q.priceCents)}</TD>
                  <TD><QueryStatusBadge status={q.status} /></TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </Card>
    </div>
  )
}
