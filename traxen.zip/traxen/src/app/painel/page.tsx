import type { Metadata } from 'next'
import Link from 'next/link'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueriesByUser } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { StatCard } from '@/components/ui/stat-card'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { QueryStatusBadge } from '@/components/dashboard/query-status-badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { formatCurrencyBRL, formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Visão geral', robots: { index: false } }

export default async function PainelOverviewPage() {
  const user = (await getCurrentUser())!
  const queries = getQueriesByUser(user.id)
  const concluded = queries.filter((q) => q.status === 'concluida')
  const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime()
  const thisMonth = concluded.filter((q) => new Date(q.createdAt).getTime() >= startOfMonth)

  return (
    <div>
      <PageHeader
        title={`Olá, ${user.name.split(' ')[0]}`}
        description="Aqui está um resumo da sua atividade na Traxen."
        actions={
          <Link href="/painel/nova-consulta">
            <Button iconLeft={<Icon.Search className="h-4 w-4" />}>Nova consulta</Button>
          </Link>
        }
      />

      <div className="grid gap-5 sm:grid-cols-3">
        <StatCard label="Consultas realizadas" value={String(concluded.length)} icon={<Icon.Doc className="h-5 w-5" />} hint="desde o início" />
        <StatCard label="Consultas este mês" value={String(thisMonth.length)} icon={<Icon.Chart className="h-5 w-5" />} hint={new Intl.DateTimeFormat('pt-BR', { month: 'long' }).format(new Date())} />
        <StatCard label="Créditos disponíveis" value={formatCurrencyBRL(user.walletCents)} icon={<Icon.Wallet className="h-5 w-5" />} hint="saldo em carteira" />
      </div>

      <Card className="mt-8">
        <div className="flex items-center justify-between border-b border-surface-border px-6 py-4">
          <h2 className="text-[15px] font-semibold text-navy-950">Consultas recentes</h2>
          <Link href="/painel/consultas" className="text-[13px] font-medium text-electric-600 hover:text-electric-700">
            Ver todas
          </Link>
        </div>

        {queries.length === 0 ? (
          <EmptyState />
        ) : (
          <Table>
            <THead>
              <tr>
                <TH>Data</TH>
                <TH>Placa</TH>
                <TH>Veículo</TH>
                <TH>Consulta</TH>
                <TH>Status</TH>
                <TH className="text-right">Ações</TH>
              </tr>
            </THead>
            <TBody>
              {queries.slice(0, 5).map((q) => (
                <TR key={q.id}>
                  <TD>{formatDate(q.createdAt)}</TD>
                  <TD className="font-mono-plate font-semibold">{q.plate}</TD>
                  <TD>{q.vehicleLabel || '—'}</TD>
                  <TD>{q.productName}</TD>
                  <TD><QueryStatusBadge status={q.status} /></TD>
                  <TD className="text-right">
                    <Link href={`/painel/consultas/${q.id}`} className="text-[13px] font-medium text-electric-600 hover:text-electric-700">
                      Ver
                    </Link>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </Card>
    </div>
  )
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-navy-50 text-navy-300">
        <Icon.Search className="h-5 w-5" />
      </div>
      <p className="text-[14px] font-semibold text-navy-800">Você ainda não fez nenhuma consulta</p>
      <p className="max-w-xs text-[13px] text-navy-400">Faça sua primeira consulta veicular para ver o histórico aqui.</p>
      <Link href="/painel/nova-consulta" className="mt-2">
        <Button size="sm">Consultar veículo</Button>
      </Link>
    </div>
  )
}
