import type { Metadata } from 'next'
import { getCurrentUser } from '@/lib/auth/current-user'
import { PageHeader } from '@/components/dashboard/page-header'
import { AccountForm } from '@/components/dashboard/account-form'

export const metadata: Metadata = { title: 'Minha conta', robots: { index: false } }

export default async function ContaPage() {
  const user = (await getCurrentUser())!
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Minha conta" description="Gerencie seus dados pessoais e preferências." />
      <AccountForm initial={{ name: user.name, email: user.email, phone: user.phone }} />
    </div>
  )
}
