import type { Metadata } from 'next'
import { ProductCards } from '@/components/marketing/product-cards'
import { SectionHeading } from '@/components/marketing/section'
import { Faq } from '@/components/marketing/faq'

export const metadata: Metadata = {
  title: 'Preços',
  description: 'Conheça os planos de consulta veicular da Traxen: Básica, Completa e Premium.',
}

const PRICING_FAQ = [
  {
    q: 'Existe mensalidade?',
    a: 'Não. As consultas avulsas são cobradas por uso, sem fidelidade ou mensalidade. Empresas com alto volume podem optar por saldo pré-pago — veja a página Para Empresas.',
  },
  {
    q: 'O que muda entre os planos?',
    a: 'Cada plano inclui um conjunto diferente de informações, sempre limitado ao que a fonte de dados contratada disponibiliza. O plano Completo é o mais escolhido por quem está comprando um veículo usado.',
  },
  {
    q: 'Posso pedir reembolso?',
    a: 'Sim, em caso de falha comprovada na geração do relatório. Consulte nossos Termos de Uso para as condições completas.',
  },
]

export default function PrecosPage() {
  return (
    <>
      <section className="border-b border-surface-border bg-surface-muted py-20">
        <div className="container">
          <SectionHeading
            eyebrow="Preços"
            title="Preços claros, sem surpresa na fatura"
            description="Escolha o nível de consulta de acordo com o momento da sua negociação."
          />
        </div>
      </section>
      <ProductCards />
      <section className="container pb-24">
        <Faq items={PRICING_FAQ} title="Dúvidas sobre preços" />
      </section>
    </>
  )
}
