import type { Metadata } from 'next'
import { SectionHeading } from '@/components/marketing/section'
import { Faq } from '@/components/marketing/faq'

export const metadata: Metadata = {
  title: 'Dúvidas frequentes',
  description: 'Respostas para as principais dúvidas sobre a consulta veicular da Traxen.',
}

const ITEMS = [
  { q: 'Quais placas posso consultar?', a: 'Qualquer veículo emplacado no Brasil, tanto no padrão antigo (LLL-NNNN) quanto no padrão Mercosul (LLLNLNN). O campo de busca reconhece automaticamente o formato digitado.' },
  { q: 'Os dados são em tempo real?', a: 'As informações refletem as bases parceiras consultadas no momento da geração do relatório. A data e hora exatas ficam registradas no protocolo de cada consulta.' },
  { q: 'O que significa "informação indisponível"?', a: 'Significa que a fonte consultada não retornou dado algum para aquele item — é diferente de "nada consta", que indica que a informação foi verificada e não há registro. Deixamos essa distinção sempre clara no relatório.' },
  { q: 'O índice de atenção é uma nota do veículo?', a: 'Não. É uma interpretação interna da Traxen sobre os itens encontrados na consulta, pensada para facilitar a leitura — nunca uma certificação de qualidade, procedência ou estado de conservação.' },
  { q: 'Como funciona o pagamento?', a: 'Aceitamos PIX e cartão de crédito. O relatório só é liberado após a confirmação do pagamento pelo nosso sistema — nunca apenas pela informação enviada pelo navegador.' },
  { q: 'Posso usar a Traxen para consultar vários veículos por mês?', a: 'Sim. Para uso recorrente, oferecemos saldo pré-pago e planos para empresas — veja a página Para Empresas.' },
  { q: 'Meus dados estão seguros?', a: 'Sim. Trafegamos e armazenamos dados com criptografia, seguimos os princípios da LGPD e nunca expomos informações sensíveis desnecessariamente. Veja nossa Política de Privacidade.' },
]

export default function DuvidasPage() {
  return (
    <section className="py-20">
      <div className="container">
        <SectionHeading eyebrow="Dúvidas" title="Perguntas frequentes" />
        <div className="mt-12">
          <Faq items={ITEMS} />
        </div>
      </div>
    </section>
  )
}
