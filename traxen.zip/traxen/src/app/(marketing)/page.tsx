import { Hero } from '@/components/marketing/hero'
import { ProductCards } from '@/components/marketing/product-cards'
import { HowItWorks } from '@/components/marketing/how-it-works'
import { Benefits } from '@/components/marketing/benefits'
import { SampleReportTeaser } from '@/components/marketing/sample-report-teaser'
import { FinalCta } from '@/components/marketing/final-cta'

export default function HomePage() {
  return (
    <>
      <Hero />
      <ProductCards />
      <HowItWorks />
      <Benefits />
      <SampleReportTeaser />
      <FinalCta />
    </>
  )
}
