import type { Metadata } from 'next'
import { SectionHeading } from '@/components/marketing/section'
import { LeadForm } from '@/components/marketing/lead-form'
import { Card } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'

export const metadata: Metadata = {
  title: 'Para empresas',
  description: 'Consultas veiculares em escala para revendas, concessionárias, lojas e despachantes.',
}

const AUDIENCE = ['Revendas', 'Concessionárias', 'Lojas de veículos', 'Despachantes', 'Empresas automotivas']

const BENEFITS = [
  { icon: Icon.Chart, title: 'Consultas em volume', text: 'Preços especiais conforme o volume mensal de consultas da sua operação.' },
  { icon: Icon.Wallet, title: 'Saldo pré-pago', text: 'Recarregue crédito e consulte sem fricção de pagamento a cada operação.' },
  { icon: Icon.History, title: 'Histórico centralizado', text: 'Toda a equipe acessa o histórico de consultas em um só lugar.' },
  { icon: Icon.Users, title: 'Gestão de usuários', text: 'Controle quem pode consultar, com permissões por perfil de acesso.' },
  { icon: Icon.Doc, title: 'Relatórios gerenciais', text: 'Acompanhe consumo, gasto médio e volume por período.' },
  { icon: Icon.Bolt, title: 'API empresarial', title2: 'api', text: 'Integre a Traxen diretamente aos seus sistemas internos via API.' },
]

export default function ParaEmpresasPage() {
  return (
    <>
      <section className="border-b border-white/10 bg-navy-950 py-20 text-white">
        <div className="container">
          <SectionHeading
            align="left"
            eyebrow="Para empresas"
            title="Consultas veiculares para quem consulta em escala."
            description="Feito para revendas, concessionárias, lojas de veículos, despachantes e empresas do setor automotivo que precisam de volume, controle e previsibilidade."
            className="[&_p]:text-navy-300 [&_h2]:text-white"
          />
          <div className="mt-8 flex flex-wrap gap-2">
            {AUDIENCE.map((a) => (
              <span key={a} className="rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-[12.5px] font-medium text-navy-100">
                {a}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="container py-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {BENEFITS.map((item) => (
            <Card key={item.title} id={item.title2} className="p-7">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-electric-50 text-electric-600">
                <item.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-[15.5px] font-semibold text-navy-950">{item.title}</h3>
              <p className="mt-2 text-[13.5px] leading-relaxed text-navy-400">{item.text}</p>
            </Card>
          ))}
        </div>
      </section>

      <section id="comercial" className="border-t border-surface-border bg-surface-muted py-20">
        <div className="container max-w-2xl">
          <SectionHeading eyebrow="Comercial" title="Fale com nosso time" align="left" />
          <div className="mt-8 rounded-lg border border-surface-border bg-white p-7 shadow-card">
            <LeadForm />
          </div>
        </div>
      </section>
    </>
  )
}
