import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Política de Privacidade' }

export default function PrivacidadePage() {
  return (
    <section className="py-16">
      <div className="container max-w-2xl">
        <p className="text-[12.5px] font-semibold uppercase tracking-wide text-electric-600">Documento legal</p>
        <h1 className="mt-2 text-[30px] font-bold tracking-tight text-navy-950">Política de Privacidade</h1>
        <p className="mt-2 text-[13px] text-navy-400">Última atualização: setembro de 2026</p>

        <div className="mt-10 flex flex-col gap-7 text-[14.5px] leading-relaxed text-navy-600">
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">1. Compromisso com a LGPD</h2>
            <p className="mt-2">
              Tratamos dados pessoais em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018),
              seguindo os princípios de finalidade, adequação, necessidade, transparência, segurança e prevenção.
              Coletamos apenas os dados pessoais necessários para prestar o serviço contratado.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">2. Dados que coletamos</h2>
            <p className="mt-2">
              Dados de cadastro (nome, e-mail, telefone), dados de uso da plataforma (histórico de consultas,
              protocolo, data e hora) e dados necessários ao processamento de pagamentos, tratados diretamente pelo
              gateway de pagamento parceiro. Não armazenamos dados completos de cartão de crédito em nossos
              servidores.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">3. Como usamos os dados</h2>
            <p className="mt-2">
              Utilizamos os dados exclusivamente para viabilizar a autenticação, o processamento de pagamentos, a
              geração e o histórico de relatórios, a comunicação sobre o serviço e o cumprimento de obrigações
              legais e regulatórias.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">4. Compartilhamento</h2>
            <p className="mt-2">
              Compartilhamos dados apenas com fornecedores estritamente necessários à prestação do serviço (bureaus
              de dados veiculares, gateway de pagamento, infraestrutura de nuvem), sob obrigações contratuais de
              confidencialidade e segurança.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">5. Retenção e exclusão</h2>
            <p className="mt-2">
              Mantemos dados pessoais apenas pelo tempo necessário às finalidades descritas ou conforme exigido por
              lei. O usuário pode solicitar a exclusão de sua conta e dados associados a qualquer momento, na área
              &quot;Minha conta&quot; do painel ou pelo suporte.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">6. Segurança</h2>
            <p className="mt-2">
              Adotamos medidas técnicas e organizacionais para proteger dados pessoais contra acessos não
              autorizados, incluindo criptografia em trânsito, controle de acesso baseado em função, registro de
              auditoria e monitoramento de segurança.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">7. Seus direitos</h2>
            <p className="mt-2">
              Você pode solicitar confirmação de tratamento, acesso, correção, anonimização, portabilidade ou
              exclusão de seus dados pessoais, conforme os direitos previstos na LGPD, entrando em contato pela
              nossa central de ajuda.
            </p>
          </section>
        </div>
      </div>
    </section>
  )
}
