import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Termos de Uso' }

export default function TermosPage() {
  return (
    <section className="py-16">
      <div className="container max-w-2xl">
        <p className="text-[12.5px] font-semibold uppercase tracking-wide text-electric-600">Documento legal</p>
        <h1 className="mt-2 text-[30px] font-bold tracking-tight text-navy-950">Termos de Uso</h1>
        <p className="mt-2 text-[13px] text-navy-400">Última atualização: setembro de 2026</p>

        <div className="prose-legal mt-10 flex flex-col gap-7 text-[14.5px] leading-relaxed text-navy-600">
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">1. Sobre a plataforma</h2>
            <p className="mt-2">
              A Traxen é uma plataforma de tecnologia que organiza e apresenta, de forma centralizada, informações de
              veículos disponíveis em bases de dados de terceiros devidamente autorizadas. A Traxen não é um órgão
              público, não substitui a vistoria presencial do veículo e não garante a exatidão, atualização ou
              completude das informações de terceiros exibidas.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">2. Natureza das consultas</h2>
            <p className="mt-2">
              Cada relatório reflete exclusivamente os dados disponíveis nas fontes consultadas no momento da
              geração da consulta. A ausência de uma informação em uma fonte é sempre identificada como
              &quot;indisponível&quot; e nunca deve ser interpretada como confirmação de que não existe registro. O
              índice de atenção apresentado é uma interpretação interna da Traxen sobre os itens localizados e não
              constitui certificação, laudo técnico ou opinião sobre o estado de conservação, procedência ou valor
              do veículo.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">3. Pagamentos</h2>
            <p className="mt-2">
              As consultas avulsas são cobradas por uso, via PIX ou cartão. A liberação do relatório ocorre somente
              após a confirmação do pagamento pelo nosso sistema junto ao gateway de pagamento — a informação de
              pagamento aprovado enviada pelo navegador do usuário não é, isoladamente, suficiente para a liberação
              do serviço. Reembolsos são analisados caso a caso em situações de falha comprovada na geração do
              relatório.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">4. Uso aceitável</h2>
            <p className="mt-2">
              É vedado o uso de mecanismos automatizados para realizar consultas em volume incompatível com o uso
              individual, tentativas de enumeração de placas, ou qualquer forma de abuso da plataforma. Empresas com
              necessidade de volume devem contratar um plano empresarial apropriado (ver página Para Empresas).
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">5. Conta e responsabilidades do usuário</h2>
            <p className="mt-2">
              O usuário é responsável por manter a confidencialidade de suas credenciais de acesso e por todas as
              atividades realizadas em sua conta. A Traxen pode suspender contas em caso de suspeita de fraude,
              abuso ou violação destes Termos.
            </p>
          </section>
          <section>
            <h2 className="text-[16px] font-semibold text-navy-950">6. Alterações destes Termos</h2>
            <p className="mt-2">
              Podemos atualizar estes Termos periodicamente. Alterações relevantes serão comunicadas por e-mail ou
              por aviso na plataforma antes de entrarem em vigor.
            </p>
          </section>
        </div>
      </div>
    </section>
  )
}
