import type { Metadata } from 'next'
import Link from 'next/link'
import { SectionHeading } from '@/components/marketing/section'
import { HowItWorks } from '@/components/marketing/how-it-works'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { Card } from '@/components/ui/card'

export const metadata: Metadata = {
  title: 'Como funciona',
  description: 'Entenda como funciona a consulta veicular da Traxen, do início ao relatório final.',
}

const DETAILS = [
  {
    icon: Icon.Search,
    title: 'Reconhecimento automático da placa',
    text: 'Digite a placa do veículo em qualquer um dos dois padrões vigentes no Brasil — o campo identifica automaticamente se é padrão antigo (LLL-NNNN) ou Mercosul (LLLNLNN).',
  },
  {
    icon: Icon.Card,
    title: 'Pagamento único, sem mensalidade',
    text: 'Você paga apenas pela consulta que realizar, via PIX ou cartão, em ambiente seguro. Empresas podem optar por saldo pré-pago (ver Para Empresas).',
  },
  {
    icon: Icon.Doc,
    title: 'Relatório objetivo e rastreável',
    text: 'Cada consulta gera um protocolo único e um relatório com data e hora, disponível para consulta e download em PDF a qualquer momento no seu painel.',
  },
  {
    icon: Icon.Shield,
    title: 'Transparência sobre a origem dos dados',
    text: 'Todo item do relatório indica claramente seu status — inclusive quando uma informação está indisponível na fonte consultada, nunca tratada como "nada consta".',
  },
]

export default function ComoFuncionaPage() {
  return (
    <>
      <section className="border-b border-surface-border bg-surface-muted py-20">
        <div className="container">
          <SectionHeading
            eyebrow="Como funciona"
            title="Da placa ao relatório, em um fluxo simples e transparente"
            description="A Traxen organiza dados de diferentes fontes em um relatório único, fácil de entender — sem letras miúdas."
          />
        </div>
      </section>

      <HowItWorks />

      <section className="container py-20">
        <div className="grid gap-6 md:grid-cols-2">
          {DETAILS.map((item) => (
            <Card key={item.title} className="p-7">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-electric-50 text-electric-600">
                <item.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-[15.5px] font-semibold text-navy-950">{item.title}</h3>
              <p className="mt-2 text-[13.5px] leading-relaxed text-navy-400">{item.text}</p>
            </Card>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center gap-4 text-center">
          <p className="text-[14.5px] text-navy-400">Pronto para consultar o seu primeiro veículo?</p>
          <Link href="/painel/nova-consulta">
            <Button size="lg">
              Consultar veículo
              <Icon.ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>
    </>
  )
}
