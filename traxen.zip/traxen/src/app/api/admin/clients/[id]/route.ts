import { NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAdmin } from '@/lib/auth/require-admin'
import { addAuditLog, findUserById, store } from '@/lib/store'
import { formatCurrencyBRL } from '@/lib/utils'

const schema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('credit'), amountCents: z.number().int().refine((v) => v !== 0) }),
  z.object({ action: z.literal('block') }),
  z.object({ action: z.literal('unblock') }),
  z.object({ action: z.literal('update'), name: z.string().min(2), phone: z.string().min(8) }),
])

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Acesso negado.' }, { status: 403 })

  const client = findUserById(params.id)
  if (!client) return NextResponse.json({ error: 'Cliente não encontrado.' }, { status: 404 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  switch (parsed.data.action) {
    case 'credit': {
      client.walletCents += parsed.data.amountCents
      store.wallet.unshift({
        id: `wtx_${Math.random().toString(36).slice(2, 8)}`,
        userId: client.id,
        description: parsed.data.amountCents > 0 ? 'Crédito adicionado pelo administrador' : 'Crédito removido pelo administrador',
        amountCents: parsed.data.amountCents,
        balanceAfterCents: client.walletCents,
        createdAt: new Date().toISOString(),
      })
      addAuditLog(admin.email, parsed.data.amountCents > 0 ? 'Crédito adicionado' : 'Crédito removido', `${formatCurrencyBRL(Math.abs(parsed.data.amountCents))} · ${client.email}`)
      break
    }
    case 'block':
      client.status = 'bloqueado'
      addAuditLog(admin.email, 'Cliente bloqueado', client.email)
      break
    case 'unblock':
      client.status = 'ativo'
      addAuditLog(admin.email, 'Cliente desbloqueado', client.email)
      break
    case 'update':
      client.name = parsed.data.name
      client.phone = parsed.data.phone
      addAuditLog(admin.email, 'Dados do cliente editados', client.email)
      break
  }

  return NextResponse.json({ client })
}
