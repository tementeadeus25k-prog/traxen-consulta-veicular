import { NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAdmin } from '@/lib/auth/require-admin'
import { store, addAuditLog } from '@/lib/store'

const schema = z.object({
  priceCents: z.number().int().positive().optional(),
  active: z.boolean().optional(),
})

export async function PATCH(req: Request, { params }: { params: { slug: string } }) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Acesso negado.' }, { status: 403 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  const product = store.products.find((p) => p.slug === params.slug)
  if (!product) return NextResponse.json({ error: 'Produto não encontrado.' }, { status: 404 })

  if (parsed.data.priceCents !== undefined) product.priceCents = parsed.data.priceCents
  if (parsed.data.active !== undefined) product.active = parsed.data.active

  addAuditLog(admin.email, 'Produto atualizado', `${product.name} · ${JSON.stringify(parsed.data)}`)

  return NextResponse.json({ product })
}
