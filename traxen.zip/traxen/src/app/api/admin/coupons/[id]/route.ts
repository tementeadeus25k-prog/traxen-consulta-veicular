import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/auth/require-admin'
import { addAuditLog, store } from '@/lib/store'

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Acesso negado.' }, { status: 403 })

  const coupon = store.coupons.find((c) => c.id === params.id)
  if (!coupon) return NextResponse.json({ error: 'Cupom não encontrado.' }, { status: 404 })

  coupon.status = coupon.status === 'ativo' ? 'inativo' : 'ativo'
  addAuditLog(admin.email, `Cupom ${coupon.status === 'ativo' ? 'ativado' : 'desativado'}`, coupon.code)

  return NextResponse.json({ coupon })
}
