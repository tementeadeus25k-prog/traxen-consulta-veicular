import { NextResponse } from 'next/server'
import { z } from 'zod'
import { requireAdmin } from '@/lib/auth/require-admin'
import { addAuditLog, store, type Coupon } from '@/lib/store'

const schema = z.object({
  code: z.string().trim().min(3).max(20),
  discountType: z.enum(['percent', 'fixed']),
  value: z.number().positive(),
  maxUses: z.number().int().positive(),
  expiresAt: z.string(),
})

export async function POST(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Acesso negado.' }, { status: 403 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  const code = parsed.data.code.toUpperCase()
  if (store.coupons.some((c) => c.code === code)) {
    return NextResponse.json({ error: 'Já existe um cupom com este código.' }, { status: 409 })
  }

  const coupon: Coupon = {
    id: `cpn_${Math.random().toString(36).slice(2, 8)}`,
    code,
    discountType: parsed.data.discountType,
    value: parsed.data.value,
    maxUses: parsed.data.maxUses,
    uses: 0,
    expiresAt: parsed.data.expiresAt,
    status: 'ativo',
  }
  store.coupons.unshift(coupon)
  addAuditLog(admin.email, 'Cupom criado', coupon.code)

  return NextResponse.json({ coupon })
}
