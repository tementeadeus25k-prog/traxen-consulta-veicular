import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getCurrentUser } from '@/lib/auth/current-user'
import { findUserById } from '@/lib/store'
import { maskPhone } from '@/lib/utils'

const schema = z.object({ name: z.string().trim().min(2), phone: z.string().trim().min(10) })

export async function PATCH(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  const stored = findUserById(user.id)
  if (!stored) return NextResponse.json({ error: 'Usuário não encontrado.' }, { status: 404 })

  stored.name = parsed.data.name
  stored.phone = maskPhone(parsed.data.phone)

  return NextResponse.json({ ok: true })
}
