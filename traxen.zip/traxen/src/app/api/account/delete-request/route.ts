import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth/current-user'
import { addAuditLog } from '@/lib/store'

// Registra o pedido de exclusão (princípio da LGPD de atendimento ao titular
// de dados). Em produção, isto deve disparar um fluxo assíncrono de
// anonimização/exclusão dentro do prazo legal, preservando apenas o que for
// exigido por obrigação legal (ex.: registros fiscais).
export async function POST() {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  addAuditLog(user.email, 'Solicitação de exclusão de conta registrada (LGPD)')
  return NextResponse.json({ ok: true })
}
