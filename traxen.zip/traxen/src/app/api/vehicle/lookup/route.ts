import { NextResponse } from 'next/server'
import { z } from 'zod'
import { isValidPlate } from '@/lib/plate'
import { getVehicleProvider } from '@/lib/vehicle-provider/normalize'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z.object({ plate: z.string().min(6).max(8) })

// Consulta pública e rápida (seção 4 do produto) — não expõe dados sensíveis,
// apenas o suficiente para confirmar que o veículo foi localizado.
export async function POST(req: Request) {
  const { allowed } = rateLimit(clientKeyFromRequest(req, 'lookup'), 12, 60_000)
  if (!allowed) {
    return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante e tente novamente.' }, { status: 429 })
  }

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success || !isValidPlate(parsed.data.plate)) {
    return NextResponse.json({ error: 'Placa inválida. Verifique o formato e tente novamente.' }, { status: 422 })
  }

  const provider = getVehicleProvider()
  const result = await provider.lookupVehicle(parsed.data.plate)
  return NextResponse.json(result)
}
