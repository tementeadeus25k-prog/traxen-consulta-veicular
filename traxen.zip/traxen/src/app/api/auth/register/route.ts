import { NextResponse } from 'next/server'
import { z } from 'zod'
import { createUser, findUserByEmail } from '@/lib/store'
import { createSessionToken, SESSION_COOKIE, sessionCookieOptions } from '@/lib/auth/session'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z
  .object({
    name: z.string().trim().min(2, 'Informe seu nome completo.'),
    email: z.string().trim().email('E-mail inválido.'),
    phone: z.string().trim().min(10, 'Telefone inválido.'),
    password: z.string().min(8, 'A senha deve ter pelo menos 8 caracteres.'),
    confirmPassword: z.string(),
    acceptedTerms: z.literal(true, { errorMap: () => ({ message: 'É necessário aceitar os termos.' }) }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'As senhas não coincidem.',
    path: ['confirmPassword'],
  })

export async function POST(req: Request) {
  const { allowed } = rateLimit(clientKeyFromRequest(req, 'register'), 8, 60_000)
  if (!allowed) {
    return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante.' }, { status: 429 })
  }

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' }, { status: 422 })
  }

  if (findUserByEmail(parsed.data.email)) {
    return NextResponse.json({ error: 'Já existe uma conta com este e-mail.' }, { status: 409 })
  }

  const user = createUser(parsed.data)
  const token = await createSessionToken({ sub: user.id, name: user.name, email: user.email, role: user.role })

  const res = NextResponse.json({ ok: true })
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions)
  return res
}
