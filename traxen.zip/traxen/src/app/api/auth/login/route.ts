import bcrypt from 'bcryptjs'
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { findUserByEmail } from '@/lib/store'
import { createSessionToken, SESSION_COOKIE, sessionCookieOptions } from '@/lib/auth/session'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z.object({ email: z.string().trim().email(), password: z.string().min(1) })

export async function POST(req: Request) {
  // Proteção contra força bruta: limite por IP e por e-mail combinados.
  const ipLimited = rateLimit(clientKeyFromRequest(req, 'login'), 10, 60_000)
  if (!ipLimited.allowed) {
    return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante e tente novamente.' }, { status: 429 })
  }

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Informe e-mail e senha válidos.' }, { status: 422 })
  }

  const emailLimited = rateLimit(`login-email:${parsed.data.email.toLowerCase()}`, 6, 60_000)
  if (!emailLimited.allowed) {
    return NextResponse.json({ error: 'Muitas tentativas para este e-mail. Tente novamente em instantes.' }, { status: 429 })
  }

  const user = findUserByEmail(parsed.data.email)
  const genericError = NextResponse.json({ error: 'E-mail ou senha incorretos.' }, { status: 401 })
  if (!user) return genericError

  const valid = bcrypt.compareSync(parsed.data.password, user.passwordHash)
  if (!valid) return genericError

  if (user.status === 'bloqueado') {
    return NextResponse.json({ error: 'Esta conta está bloqueada. Fale com o suporte.' }, { status: 403 })
  }

  const token = await createSessionToken({ sub: user.id, name: user.name, email: user.email, role: user.role })
  const res = NextResponse.json({ ok: true, role: user.role })
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions)
  return res
}
