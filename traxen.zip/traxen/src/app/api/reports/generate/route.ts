import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueryById, updateQuery } from '@/lib/store'
import { buildVehicleReport } from '@/lib/vehicle-provider/normalize'

const schema = z.object({ queryId: z.string() })

export async function POST(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  const query = getQueryById(parsed.data.queryId)
  if (!query || query.userId !== user.id) {
    return NextResponse.json({ error: 'Consulta não encontrada.' }, { status: 404 })
  }

  // Idempotente: se o relatório já existe, apenas retorna — nunca gera (ou
  // cobra) duas vezes pela mesma consulta.
  if (query.status === 'concluida' && query.report) {
    return NextResponse.json({ queryId: query.id })
  }

  // Verificação server-side do pagamento: só gera relatório se o webhook (ou
  // o timer de demonstração) já tiver confirmado o pagamento e movido a
  // consulta para "processando". Nenhum campo enviado pelo cliente é
  // suficiente para liberar o relatório.
  if (query.status !== 'processando') {
    return NextResponse.json({ error: 'Pagamento ainda não confirmado.' }, { status: 409 })
  }

  const report = await buildVehicleReport(query.plate, query.productSlug)
  if (!report) {
    updateQuery(query.id, { status: 'falhou' })
    return NextResponse.json({ error: 'Não foi possível localizar o veículo na fonte consultada.' }, { status: 422 })
  }

  updateQuery(query.id, {
    status: 'concluida',
    report,
    vehicleLabel: `${report.identity.brand} ${report.identity.model}`,
    protocol: report.protocol,
  })

  return NextResponse.json({ queryId: query.id })
}
