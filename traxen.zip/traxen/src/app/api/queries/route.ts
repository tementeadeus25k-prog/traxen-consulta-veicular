import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getCurrentUser } from '@/lib/auth/current-user'
import { isValidPlate, sanitizePlate } from '@/lib/plate'
import { createQuery, getActiveProduct } from '@/lib/store'
import { generateProtocol } from '@/lib/utils'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z.object({ plate: z.string().min(6).max(8), productSlug: z.enum(['basica', 'completa', 'premium']) })

export async function POST(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const { allowed } = rateLimit(clientKeyFromRequest(req, `queries:${user.id}`), 20, 60_000)
  if (!allowed) return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante.' }, { status: 429 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success || !isValidPlate(parsed.data.plate)) {
    return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })
  }

  const product = getActiveProduct(parsed.data.productSlug)
  if (!product || !product.active) {
    return NextResponse.json({ error: 'Produto indisponível.' }, { status: 422 })
  }

  const query = createQuery({
    userId: user.id,
    protocol: generateProtocol(),
    plate: sanitizePlate(parsed.data.plate),
    productSlug: product.slug,
    productName: product.name,
    priceCents: product.priceCents,
    providerCostCents: Math.round(product.priceCents * 0.35),
  })

  return NextResponse.json({ id: query.id })
}
