import { NextResponse } from 'next/server'
import { store } from '@/lib/store'

// Catálogo público de produtos — reflete imediatamente qualquer alteração
// feita pelo admin em /admin/produtos (preço, status, ordem).
//
// IMPORTANTE: sem nenhuma API dinâmica (cookies/headers) neste handler, o
// Next.js trataria esta rota como estática e a "congelaria" no momento do
// build — o que faria edições de preço no admin nunca aparecerem para o
// cliente. `force-dynamic` garante que ela sempre execute por requisição.
export const dynamic = 'force-dynamic'

export async function GET() {
  const products = [...store.products].filter((p) => p.active).sort((a, b) => a.order - b.order)
  return NextResponse.json({ products })
}
