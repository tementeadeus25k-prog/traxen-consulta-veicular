import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getPaymentProvider } from '@/lib/payments/mock-provider'
import { confirmPayment } from '@/lib/payments/confirm'

const schema = z.object({
  chargeId: z.string(),
  status: z.enum(['approved', 'refused']),
})

// ---------------------------------------------------------------------------
// Endpoint que o gateway de pagamento real chamaria para notificar o
// resultado de uma cobrança. É o ÚNICO lugar (além do timer de demonstração
// em create-charge) autorizado a confirmar um pagamento — o frontend nunca
// libera uma consulta paga sozinho.
//
// Em produção:
// - Validar a assinatura do payload com o segredo do gateway
//   (PAYMENT_WEBHOOK_SECRET), rejeitando qualquer requisição não assinada.
// - Responder rapidamente (2xx) e processar de forma idempotente, pois
//   gateways reenviam eventos em caso de timeout.
// ---------------------------------------------------------------------------
export async function POST(req: Request) {
  const rawBody = await req.text()
  const signature = req.headers.get('x-webhook-signature')

  const provider = getPaymentProvider()
  if (!provider.verifyWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Assinatura inválida.' }, { status: 401 })
  }

  const parsed = schema.safeParse(JSON.parse(rawBody || '{}'))
  if (!parsed.success) {
    return NextResponse.json({ error: 'Payload inválido.' }, { status: 422 })
  }

  confirmPayment(parsed.data.chargeId, parsed.data.status)
  return NextResponse.json({ received: true })
}
