import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth/current-user'
import { store } from '@/lib/store'
import { getPaymentProvider } from '@/lib/payments/mock-provider'

export async function GET(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const chargeId = new URL(req.url).searchParams.get('chargeId')
  if (!chargeId) return NextResponse.json({ error: 'chargeId ausente.' }, { status: 422 })

  const queryId = store.chargeToQuery.get(chargeId)
  const query = queryId ? store.queries.find((q) => q.id === queryId) : undefined
  if (!query || query.userId !== user.id) {
    return NextResponse.json({ error: 'Cobrança não encontrada.' }, { status: 404 })
  }

  const provider = getPaymentProvider()
  const status = await provider.getChargeStatus(chargeId)
  return NextResponse.json({ status, queryId: query.id })
}
