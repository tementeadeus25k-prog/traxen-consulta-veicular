import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getCurrentUser } from '@/lib/auth/current-user'
import { getQueryById, store, updateQuery } from '@/lib/store'
import { getPaymentProvider } from '@/lib/payments/mock-provider'
import { confirmPayment } from '@/lib/payments/confirm'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z.object({ queryId: z.string(), method: z.enum(['pix', 'card']) })

export async function POST(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const { allowed } = rateLimit(clientKeyFromRequest(req, `charge:${user.id}`), 15, 60_000)
  if (!allowed) return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante.' }, { status: 429 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Dados inválidos.' }, { status: 422 })

  const query = getQueryById(parsed.data.queryId)
  if (!query || query.userId !== user.id) {
    return NextResponse.json({ error: 'Consulta não encontrada.' }, { status: 404 })
  }

  // Idempotência: se já existe cobrança para esta consulta, retorna o estado
  // atual em vez de criar uma nova cobrança/consulta duplicada.
  if (query.chargeId) {
    const provider = getPaymentProvider()
    const status = await provider.getChargeStatus(query.chargeId)
    return NextResponse.json({ chargeId: query.chargeId, status, method: query.paymentMethod, amountCents: query.priceCents })
  }

  if (query.status !== 'aguardando_pagamento') {
    return NextResponse.json({ error: 'Esta consulta não está aguardando pagamento.' }, { status: 409 })
  }

  const provider = getPaymentProvider()
  const charge = await provider.createCharge({
    idempotencyKey: query.id, // garante 1 cobrança por consulta mesmo em retries
    amountCents: query.priceCents,
    method: parsed.data.method,
    description: `${query.productName} · placa ${query.plate}`,
    customer: { name: user.name, email: user.email },
  })

  store.chargeToQuery.set(charge.chargeId, query.id)
  updateQuery(query.id, { chargeId: charge.chargeId, paymentMethod: parsed.data.method })

  // ---------------------------------------------------------------------
  // DEMONSTRAÇÃO: nenhum gateway real está conectado neste protótipo, então
  // simulamos aqui a confirmação assíncrona que, em produção, chegaria via
  // webhook do gateway (ver /api/payments/webhook). O backend nunca confia
  // em "pagamento aprovado" vindo diretamente do navegador.
  // ---------------------------------------------------------------------
  const delay = parsed.data.method === 'pix' ? 3200 : 2000
  setTimeout(() => confirmPayment(charge.chargeId, 'approved'), delay)

  return NextResponse.json(charge)
}
