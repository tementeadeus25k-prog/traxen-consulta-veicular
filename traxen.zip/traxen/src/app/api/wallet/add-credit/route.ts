import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getCurrentUser } from '@/lib/auth/current-user'
import { findUserById, store } from '@/lib/store'
import { clientKeyFromRequest, rateLimit } from '@/lib/rate-limit'

const schema = z.object({ amountCents: z.number().int().positive().max(1_000_000) })

// ---------------------------------------------------------------------------
// Recarga de créditos (carteira). Neste protótipo, credita imediatamente para
// fins de demonstração. Em produção, deve seguir o MESMO fluxo de
// confirmação via webhook usado no checkout (ver /api/payments) — nunca
// creditar saldo apenas por uma chamada direta do cliente.
// ---------------------------------------------------------------------------
export async function POST(req: Request) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado.' }, { status: 401 })

  const { allowed } = rateLimit(clientKeyFromRequest(req, `wallet:${user.id}`), 10, 60_000)
  if (!allowed) return NextResponse.json({ error: 'Muitas tentativas. Aguarde um instante.' }, { status: 429 })

  const body = await req.json().catch(() => null)
  const parsed = schema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: 'Valor inválido.' }, { status: 422 })

  const stored = findUserById(user.id)
  if (!stored) return NextResponse.json({ error: 'Usuário não encontrado.' }, { status: 404 })

  stored.walletCents += parsed.data.amountCents
  store.wallet.unshift({
    id: `wtx_${Math.random().toString(36).slice(2, 8)}`,
    userId: user.id,
    description: 'Recarga via PIX',
    amountCents: parsed.data.amountCents,
    balanceAfterCents: stored.walletCents,
    createdAt: new Date().toISOString(),
  })

  return NextResponse.json({ walletCents: stored.walletCents })
}
