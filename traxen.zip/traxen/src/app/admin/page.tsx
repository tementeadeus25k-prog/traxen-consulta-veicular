import type { Metadata } from 'next'
import { store, adminMetrics } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { StatCard } from '@/components/ui/stat-card'
import { Card } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'
import { BarChart } from '@/components/admin/bar-chart'
import { BreakdownList } from '@/components/admin/breakdown-list'
import { formatCurrencyBRL } from '@/lib/utils'

export const metadata: Metadata = { title: 'Dashboard administrativo', robots: { index: false } }

function lastNDays(n: number) {
  return Array.from({ length: n }).map((_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (n - 1 - i))
    d.setHours(0, 0, 0, 0)
    return d
  })
}

export default function AdminDashboardPage() {
  const metrics = adminMetrics()
  const paid = store.queries.filter((q) => q.status === 'concluida')
  const days = lastNDays(7)

  const revenueByDay = days.map((day) => {
    const next = new Date(day)
    next.setDate(next.getDate() + 1)
    const total = paid
      .filter((q) => {
        const t = new Date(q.createdAt).getTime()
        return t >= day.getTime() && t < next.getTime()
      })
      .reduce((a, q) => a + q.priceCents, 0)
    return { label: day.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''), value: total }
  })

  const queriesByDay = days.map((day) => {
    const next = new Date(day)
    next.setDate(next.getDate() + 1)
    const count = store.queries.filter((q) => {
      const t = new Date(q.createdAt).getTime()
      return t >= day.getTime() && t < next.getTime()
    }).length
    return { label: day.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''), value: count }
  })

  const byProduct = ['basica', 'completa', 'premium'].map((slug) => {
    const count = paid.filter((q) => q.productSlug === slug).length
    return { slug, count }
  })
  const totalSold = byProduct.reduce((a, p) => a + p.count, 0) || 1
  const breakdown = byProduct.map((p) => ({
    label: store.products.find((pr) => pr.slug === p.slug)?.name || p.slug,
    value: p.count,
    percent: Math.round((p.count / totalSold) * 100),
  }))

  return (
    <div>
      <PageHeader title="Dashboard administrativo" description="Visão consolidada da operação Traxen." />

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Receita hoje" value={formatCurrencyBRL(metrics.revenueTodayCents)} icon={<Icon.Wallet className="h-5 w-5" />} />
        <StatCard label="Receita no mês" value={formatCurrencyBRL(metrics.revenueMonthCents)} icon={<Icon.Chart className="h-5 w-5" />} trend={{ value: '12,4%', positive: true }} hint="vs. mês anterior" />
        <StatCard label="Consultas hoje" value={String(metrics.queriesToday)} icon={<Icon.Search className="h-5 w-5" />} />
        <StatCard label="Consultas no mês" value={String(metrics.queriesMonth)} icon={<Icon.Doc className="h-5 w-5" />} />
        <StatCard label="Novos clientes" value={String(metrics.newClients)} icon={<Icon.Users className="h-5 w-5" />} hint="últimos 30 dias" />
        <StatCard label="Ticket médio" value={formatCurrencyBRL(metrics.ticketMedioCents)} icon={<Icon.Card className="h-5 w-5" />} />
        <StatCard label="Taxa de pagamento aprovado" value={`${metrics.approvalRate}%`} icon={<Icon.Check className="h-5 w-5" />} trend={{ value: '2,1%', positive: true }} />
        <StatCard label="Total de clientes" value={String(store.users.filter((u) => u.role !== 'admin').length)} icon={<Icon.Building className="h-5 w-5" />} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <h2 className="text-[15px] font-semibold text-navy-950">Receita por dia</h2>
          <p className="mb-4 text-[12.5px] text-navy-400">Últimos 7 dias</p>
          <BarChart data={revenueByDay} formatValue={formatCurrencyBRL} />
        </Card>
        <Card className="p-6">
          <h2 className="text-[15px] font-semibold text-navy-950">Tipos de consulta vendidos</h2>
          <p className="mb-4 text-[12.5px] text-navy-400">Distribuição por produto</p>
          <BreakdownList items={breakdown} />
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <h2 className="text-[15px] font-semibold text-navy-950">Consultas por dia</h2>
          <p className="mb-4 text-[12.5px] text-navy-400">Últimos 7 dias</p>
          <BarChart data={queriesByDay} />
        </Card>
      </div>
    </div>
  )
}
