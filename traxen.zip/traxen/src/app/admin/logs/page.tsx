import type { Metadata } from 'next'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { Card } from '@/components/ui/card'
import { formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Logs de auditoria', robots: { index: false } }

export default function AdminLogsPage() {
  const logs = [...store.auditLogs].sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  return (
    <div>
      <PageHeader title="Logs de auditoria" description="Todas as ações sensíveis realizadas na plataforma ficam registradas aqui." />
      <Card>
        {logs.length === 0 ? (
          <p className="px-6 py-16 text-center text-[13.5px] text-navy-400">Nenhum log registrado ainda.</p>
        ) : (
          <ul className="divide-y divide-surface-border">
            {logs.map((log) => (
              <li key={log.id} className="flex flex-wrap items-center justify-between gap-2 px-6 py-4">
                <div>
                  <p className="text-[13.5px] font-semibold text-navy-900">{log.action}</p>
                  {log.meta && <p className="text-[12.5px] text-navy-400">{log.meta}</p>}
                </div>
                <div className="text-right">
                  <p className="text-[12.5px] font-medium text-navy-500">{log.actor}</p>
                  <p className="text-[11.5px] text-navy-300">{formatDate(log.createdAt, true)}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}
