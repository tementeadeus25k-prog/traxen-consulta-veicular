import type { Metadata } from 'next'
import * as React from 'react'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { Card } from '@/components/ui/card'
import { QueryStatusBadge } from '@/components/dashboard/query-status-badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { cn, formatCurrencyBRL, formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Consultas', robots: { index: false } }

export default function AdminConsultasPage() {
  const queries = [...store.queries].sort((a, b) => b.createdAt.localeCompare(a.createdAt))

  return (
    <div>
      <PageHeader title="Consultas" description={`${queries.length} consultas registradas na plataforma.`} />
      <Card>
        <Table>
          <THead>
            <tr>
              <TH>Protocolo</TH>
              <TH>Cliente</TH>
              <TH>Placa</TH>
              <TH>Produto</TH>
              <TH>Data</TH>
              <TH>Status</TH>
              <TH className="text-right">Custo API</TH>
              <TH className="text-right">Valor cobrado</TH>
              <TH className="text-right">Margem</TH>
              <TH></TH>
            </tr>
          </THead>
          <TBody>
            {queries.map((q) => {
              const client = store.users.find((u) => u.id === q.userId)
              const margin = q.priceCents - q.providerCostCents
              return (
                <React.Fragment key={q.id}>
                  <TR>
                    <TD className="font-mono text-[12px] text-navy-400">{q.protocol}</TD>
                    <TD>{client?.name || '—'}</TD>
                    <TD className="font-mono-plate font-semibold">{q.plate}</TD>
                    <TD>{q.productName}</TD>
                    <TD>{formatDate(q.createdAt, true)}</TD>
                    <TD><QueryStatusBadge status={q.status} /></TD>
                    <TD className="text-right text-navy-400">{formatCurrencyBRL(q.providerCostCents)}</TD>
                    <TD className="text-right font-semibold">{formatCurrencyBRL(q.priceCents)}</TD>
                    <TD className={cn('text-right font-semibold', margin >= 0 ? 'text-positive-600' : 'text-critical-600')}>
                      {formatCurrencyBRL(margin)}
                    </TD>
                    <TD>
                      {q.report && (
                        <details>
                          <summary className="cursor-pointer text-[12px] font-medium text-electric-600 hover:text-electric-700">
                            Resposta técnica
                          </summary>
                        </details>
                      )}
                    </TD>
                  </TR>
                  {q.report && (
                    <tr>
                      <td colSpan={10} className="bg-navy-50/40 px-4 pb-3">
                        <pre className="max-h-40 overflow-auto rounded-lg bg-navy-950 p-3 text-[11px] leading-relaxed text-navy-100">
                          {JSON.stringify(q.report, null, 2)}
                        </pre>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              )
            })}
          </TBody>
        </Table>
      </Card>
      <p className="mt-3 text-[12px] text-navy-300">
        A resposta técnica completa é visível apenas para administradores autenticados e deve ser consultada somente
        quando necessário, conforme o princípio de minimização de exposição de dados.
      </p>
    </div>
  )
}
