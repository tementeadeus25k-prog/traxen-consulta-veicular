import type { Metadata } from 'next'
import Link from 'next/link'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { formatCurrencyBRL, formatDate } from '@/lib/utils'

export const metadata: Metadata = { title: 'Clientes', robots: { index: false } }

export default function AdminClientesPage() {
  const clients = store.users.filter((u) => u.role !== 'admin')

  return (
    <div>
      <PageHeader title="Clientes" description={`${clients.length} contas cadastradas na plataforma.`} />
      <Card>
        <Table>
          <THead>
            <tr>
              <TH>ID</TH>
              <TH>Nome</TH>
              <TH>E-mail</TH>
              <TH>Telefone</TH>
              <TH>Cadastro</TH>
              <TH className="text-right">Consultas</TH>
              <TH className="text-right">Saldo</TH>
              <TH>Status</TH>
            </tr>
          </THead>
          <TBody>
            {clients.map((c) => {
              const count = store.queries.filter((q) => q.userId === c.id).length
              return (
                <TR key={c.id}>
                  <TD className="font-mono text-[12px] text-navy-300">{c.id}</TD>
                  <TD>
                    <Link href={`/admin/clientes/${c.id}`} className="font-semibold text-navy-950 hover:text-electric-600">
                      {c.name}
                    </Link>
                    {c.role === 'empresa' && <Badge tone="electric" className="ml-2">Empresa</Badge>}
                  </TD>
                  <TD>{c.email}</TD>
                  <TD>{c.phone}</TD>
                  <TD>{formatDate(c.createdAt)}</TD>
                  <TD className="text-right">{count}</TD>
                  <TD className="text-right font-semibold">{formatCurrencyBRL(c.walletCents)}</TD>
                  <TD>
                    <Badge tone={c.status === 'ativo' ? 'positive' : 'critical'}>
                      {c.status === 'ativo' ? 'Ativo' : 'Bloqueado'}
                    </Badge>
                  </TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </Card>
    </div>
  )
}
