import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { store } from '@/lib/store'
import { ClientDetail } from '@/components/admin/client-detail'

export const metadata: Metadata = { title: 'Detalhe do cliente', robots: { index: false } }

export default function AdminClientDetailPage({ params }: { params: { id: string } }) {
  const client = store.users.find((u) => u.id === params.id)
  if (!client) notFound()

  const queries = store.queries.filter((q) => q.userId === client.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  const wallet = store.wallet.filter((w) => w.userId === client.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  const logs = store.auditLogs.filter((l) => l.meta?.includes(client.email))

  return <ClientDetail client={client} queries={queries} wallet={wallet} logs={logs} />
}
