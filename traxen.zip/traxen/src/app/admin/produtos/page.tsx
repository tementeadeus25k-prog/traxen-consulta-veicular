import type { Metadata } from 'next'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { ProdutosManager } from '@/components/admin/produtos-manager'

export const metadata: Metadata = { title: 'Produtos e preços', robots: { index: false } }

export default function AdminProdutosPage() {
  const products = [...store.products].sort((a, b) => a.order - b.order)
  return (
    <div>
      <PageHeader title="Produtos e preços" description="Altere preços e disponibilidade sem precisar de um novo deploy." />
      <ProdutosManager products={products} />
    </div>
  )
}
