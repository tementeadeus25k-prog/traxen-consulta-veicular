import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth/current-user'
import { AdminShell } from '@/components/admin/shell'

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()
  if (!user || user.role !== 'admin') redirect('/entrar?next=/admin')

  return (
    <AdminShell name={user.name} email={user.email}>
      {children}
    </AdminShell>
  )
}
