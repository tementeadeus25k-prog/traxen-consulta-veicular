import type { Metadata } from 'next'
import { store } from '@/lib/store'
import { PageHeader } from '@/components/dashboard/page-header'
import { CuponsManager } from '@/components/admin/cupons-manager'

export const metadata: Metadata = { title: 'Cupons', robots: { index: false } }

export default function AdminCuponsPage() {
  return (
    <div>
      <PageHeader title="Cupons" description="Crie e gerencie cupons de desconto." />
      <CuponsManager coupons={store.coupons} />
    </div>
  )
}
