import type { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_APP_URL || 'https://www.traxen.com.br'
  const routes = ['', '/como-funciona', '/para-empresas', '/precos', '/duvidas', '/termos', '/privacidade', '/entrar', '/cadastro']
  return routes.map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: 'weekly',
    priority: route === '' ? 1 : 0.6,
  }))
}
