import type { Metadata } from 'next'
import { ReportShell } from '@/components/report/report-shell'
import { buildVehicleReport } from '@/lib/vehicle-provider/normalize'

export const metadata: Metadata = {
  title: 'Exemplo de relatório veicular',
  description: 'Veja um exemplo ilustrativo do relatório veicular completo da Traxen.',
}

// Gera o exemplo a cada requisição (protocolo e data/hora sempre atuais, e
// sempre refletindo o produto "completa" tal como configurado no admin) em
// vez de congelar o resultado no momento do build.
export const dynamic = 'force-dynamic'

export default async function RelatorioExemploPage() {
  const report = await buildVehicleReport('ABC1D23', 'completa')
  if (!report) return null
  return <ReportShell report={report} backHref="/" isSample />
}
