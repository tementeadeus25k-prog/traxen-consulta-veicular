// ---------------------------------------------------------------------------
// Catálogo de produtos (consultas). Em produção isto vive na tabela
// `products` (ver prisma/schema.prisma) e é editável pelo admin sem deploy —
// esta constante é o seed inicial / fallback usado pelo protótipo.
// ---------------------------------------------------------------------------

export type ReportFieldKey =
  | 'identity'
  | 'restrictions'
  | 'debts'
  | 'theft'
  | 'lien'
  | 'claims'
  | 'history'

export interface Product {
  slug: 'basica' | 'completa' | 'premium'
  name: string
  tagline: string
  priceCents: number
  badge?: string
  fields: ReportFieldKey[]
  bullets: string[]
  active: boolean
  order: number
}

export const PRODUCTS: Product[] = [
  {
    slug: 'basica',
    name: 'Consulta Básica',
    tagline: 'Informações cadastrais essenciais.',
    priceCents: 990,
    fields: ['identity'],
    bullets: [
      'Informações cadastrais',
      'Marca e modelo',
      'Ano de fabricação e modelo',
      'Município e UF',
      'Características gerais do veículo',
    ],
    active: true,
    order: 1,
  },
  {
    slug: 'completa',
    name: 'Consulta Completa',
    tagline: 'A opção mais escolhida por quem vai comprar um veículo.',
    priceCents: 2990,
    badge: 'Mais escolhida',
    fields: ['identity', 'restrictions', 'debts', 'theft', 'lien', 'claims'],
    bullets: [
      'Tudo da Consulta Básica',
      'Restrições disponíveis',
      'Débitos informados na fonte',
      'Roubo e furto',
      'Gravame (vínculo financeiro)',
      'Sinistros informados',
    ],
    active: true,
    order: 2,
  },
  {
    slug: 'premium',
    name: 'Consulta Premium',
    tagline: 'A consulta mais completa disponível na plataforma.',
    priceCents: 4990,
    fields: ['identity', 'restrictions', 'debts', 'theft', 'lien', 'claims', 'history'],
    bullets: [
      'Tudo da Consulta Completa',
      'Histórico adicional (recall, leilão)',
      'Outras informações disponíveis nas bases parceiras',
      'Prioridade na geração do relatório',
    ],
    active: true,
    order: 3,
  },
]

export function getProduct(slug: string): Product | undefined {
  return PRODUCTS.find((p) => p.slug === slug)
}
