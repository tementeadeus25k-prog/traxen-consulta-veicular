import type { UserRole } from '@/lib/store'

// ---------------------------------------------------------------------------
// Sessão assinada (HMAC-SHA256 via Web Crypto) armazenada em cookie HttpOnly.
//
// Usamos Web Crypto (crypto.subtle) em vez de `node:crypto` para que o mesmo
// código funcione tanto nas Route Handlers (runtime Node) quanto no
// middleware (runtime Edge) — um único ponto de verificação de sessão.
//
// Isto é um mecanismo enxuto adequado ao protótipo. Em produção, prefira
// Auth.js (NextAuth) com armazenamento de sessão em banco/Redis e rotação de
// refresh tokens — o ponto de integração está isolado neste arquivo.
// ---------------------------------------------------------------------------

export const SESSION_COOKIE = 'traxen_session'
const SESSION_TTL_SECONDS = 60 * 60 * 8 // 8 horas

export interface SessionPayload {
  sub: string
  name: string
  email: string
  role: UserRole
  exp: number
}

function getSecret(): string {
  return process.env.AUTH_SECRET || 'dev-secret-nao-use-em-producao-substitua-via-env'
}

function toBase64Url(bytes: ArrayBuffer | Uint8Array): string {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)
  let str = ''
  arr.forEach((b) => (str += String.fromCharCode(b)))
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function fromBase64Url(value: string): Uint8Array {
  const padded = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=')
  const bin = atob(padded)
  return new Uint8Array([...bin].map((c) => c.charCodeAt(0)))
}

async function hmacKey() {
  const enc = new TextEncoder().encode(getSecret())
  return crypto.subtle.importKey('raw', enc as unknown as BufferSource, { name: 'HMAC', hash: 'SHA-256' }, false, [
    'sign',
    'verify',
  ])
}

export async function createSessionToken(payload: Omit<SessionPayload, 'exp'>): Promise<string> {
  const full: SessionPayload = { ...payload, exp: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS }
  const body = toBase64Url(new TextEncoder().encode(JSON.stringify(full)))
  const key = await hmacKey()
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(body) as unknown as BufferSource)
  return `${body}.${toBase64Url(sig)}`
}

export async function verifySessionToken(token: string | undefined | null): Promise<SessionPayload | null> {
  if (!token) return null
  const [body, sig] = token.split('.')
  if (!body || !sig) return null
  try {
    const key = await hmacKey()
    const valid = await crypto.subtle.verify(
      'HMAC',
      key,
      fromBase64Url(sig) as unknown as BufferSource,
      new TextEncoder().encode(body) as unknown as BufferSource,
    )
    if (!valid) return null
    const payload = JSON.parse(new TextDecoder().decode(fromBase64Url(body))) as SessionPayload
    if (payload.exp < Math.floor(Date.now() / 1000)) return null
    return payload
  } catch {
    return null
  }
}

export const sessionCookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  path: '/',
  maxAge: SESSION_TTL_SECONDS,
}
