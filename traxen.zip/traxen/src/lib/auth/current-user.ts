import { cookies } from 'next/headers'
import { findUserById } from '@/lib/store'
import { SESSION_COOKIE, verifySessionToken } from './session'

/** Server-only: lê e valida a sessão a partir do cookie HttpOnly. */
export async function getCurrentUser() {
  const token = cookies().get(SESSION_COOKIE)?.value
  const session = await verifySessionToken(token)
  if (!session) return null
  const user = findUserById(session.sub)
  if (!user || user.status === 'bloqueado') return null
  return user
}
