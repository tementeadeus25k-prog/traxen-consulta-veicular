import { getCurrentUser } from './current-user'

/** Server-only: garante que a requisição vem de um usuário com papel admin. */
export async function requireAdmin() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'admin') return null
  return user
}
