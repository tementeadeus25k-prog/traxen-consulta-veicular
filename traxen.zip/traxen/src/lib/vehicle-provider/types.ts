// ---------------------------------------------------------------------------
// Contrato desacoplado do fornecedor de dados veiculares.
//
// Qualquer bureau/API futura deve implementar esta interface. Nada no
// restante da aplicação importa tipos específicos de um fornecedor — apenas
// este contrato e o tipo normalizado (src/types/report.ts).
//
// IMPORTANTE:
// - Nenhuma implementação real deve fazer scraping de sites governamentais.
// - Chaves de API vivem somente no backend (variáveis de ambiente sem
//   prefixo NEXT_PUBLIC_) e nunca devem ser importadas por código de cliente.
// ---------------------------------------------------------------------------

export interface RawVehicleIdentity {
  plate: string
  brand: string
  model: string
  manufactureYear: number
  modelYear: number
  fuel: string
  color: string
  category: string
  species: string
  city: string
  state: string
  chassisMasked?: string
  renavamMasked?: string
}

export interface RawRestriction {
  found: boolean
  items?: { type: string; date?: string; origin?: string }[]
}

export interface RawDebt {
  found: boolean
  hasOpenDebts?: boolean
  note?: string
}

export interface RawTheftRecord {
  found: boolean
  occurrences?: { date: string; state: string }[]
}

export interface RawLienInformation {
  found: boolean
  hasActiveLien?: boolean
  financialInstitution?: string
}

export interface RawClaim {
  found: boolean
  occurrences?: { date: string; severity: 'baixa' | 'média' | 'alta' }[]
}

export interface RawAdditionalHistory {
  recall: { found: boolean; note?: string }
  auction: { found: boolean; note?: string }
  other?: { label: string; found: boolean; note?: string }[]
}

export interface ProviderLookupResult {
  found: boolean
  plate: string
  brand?: string
  model?: string
  modelYear?: string
}

/**
 * Contrato que qualquer adapter de bureau/API veicular deve implementar.
 * Um adapter "mock" é usado em desenvolvimento (ver mock-provider.ts).
 */
export interface VehicleDataProvider {
  readonly name: string

  /** Consulta pública e rápida — informações mínimas exibidas antes do pagamento. */
  lookupVehicle(plate: string): Promise<ProviderLookupResult>

  /** Dados cadastrais completos do veículo. */
  getVehicleDetails(plate: string): Promise<RawVehicleIdentity | null>

  getRestrictions(plate: string): Promise<RawRestriction>
  getDebts(plate: string): Promise<RawDebt>
  getTheftRecords(plate: string): Promise<RawTheftRecord>
  getLienInformation(plate: string): Promise<RawLienInformation>
  getClaims(plate: string): Promise<RawClaim>
  getAdditionalHistory(plate: string): Promise<RawAdditionalHistory>
}
