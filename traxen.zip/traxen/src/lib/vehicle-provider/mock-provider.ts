import { sanitizePlate } from '@/lib/plate'
import type {
  ProviderLookupResult,
  RawAdditionalHistory,
  RawClaim,
  RawDebt,
  RawLienInformation,
  RawRestriction,
  RawTheftRecord,
  RawVehicleIdentity,
  VehicleDataProvider,
} from './types'

// ---------------------------------------------------------------------------
// MockVehicleProvider
//
// Implementação de demonstração. Gera dados FICTÍCIOS e determinísticos a
// partir da placa informada (mesma placa => mesmo resultado), simulando
// latência de rede real. Substitua por um adapter real implementando
// VehicleDataProvider quando um bureau/API for contratado — nenhuma outra
// camada da aplicação precisa mudar.
// ---------------------------------------------------------------------------

function hashPlate(plate: string): number {
  let h = 0
  for (let i = 0; i < plate.length; i++) {
    h = (h * 31 + plate.charCodeAt(i)) >>> 0
  }
  return h
}

const CATALOG: Array<Omit<RawVehicleIdentity, 'plate' | 'chassisMasked' | 'renavamMasked'>> = [
  {
    brand: 'VOLKSWAGEN',
    model: 'T-CROSS 200 TSI',
    manufactureYear: 2023,
    modelYear: 2024,
    fuel: 'Flex',
    color: 'Branco',
    category: 'Particular',
    species: 'Passageiro',
    city: 'São Paulo',
    state: 'SP',
  },
  {
    brand: 'FIAT',
    model: 'PULSE DRIVE 1.3',
    manufactureYear: 2022,
    modelYear: 2022,
    fuel: 'Flex',
    color: 'Cinza',
    category: 'Particular',
    species: 'Passageiro',
    city: 'Curitiba',
    state: 'PR',
  },
  {
    brand: 'CHEVROLET',
    model: 'ONIX PLUS LTZ',
    manufactureYear: 2021,
    modelYear: 2021,
    fuel: 'Flex',
    color: 'Prata',
    category: 'Particular',
    species: 'Passageiro',
    city: 'Belo Horizonte',
    state: 'MG',
  },
  {
    brand: 'HYUNDAI',
    model: 'CRETA ULTIMATE',
    manufactureYear: 2024,
    modelYear: 2024,
    fuel: 'Flex',
    color: 'Preto',
    category: 'Particular',
    species: 'Passageiro',
    city: 'Porto Alegre',
    state: 'RS',
  },
  {
    brand: 'TOYOTA',
    model: 'COROLLA XEI 2.0',
    manufactureYear: 2020,
    modelYear: 2021,
    fuel: 'Flex',
    color: 'Prata',
    category: 'Particular',
    species: 'Passageiro',
    city: 'Campinas',
    state: 'SP',
  },
  {
    brand: 'JEEP',
    model: 'RENEGADE LONGITUDE',
    manufactureYear: 2019,
    modelYear: 2020,
    fuel: 'Flex',
    color: 'Vermelho',
    category: 'Particular',
    species: 'Passageiro',
    city: 'Salvador',
    state: 'BA',
  },
]

async function delay(min: number, max: number) {
  const ms = min + Math.random() * (max - min)
  await new Promise((resolve) => setTimeout(resolve, ms))
}

export class MockVehicleProvider implements VehicleDataProvider {
  readonly name = 'mock-provider-v1'

  private notFoundPlates = new Set(['ZZZ0000', 'AAA9Z99'])

  async lookupVehicle(rawPlate: string): Promise<ProviderLookupResult> {
    await delay(500, 1100)
    const plate = sanitizePlate(rawPlate)
    if (this.notFoundPlates.has(plate)) {
      return { found: false, plate }
    }
    const entry = CATALOG[hashPlate(plate) % CATALOG.length]
    return {
      found: true,
      plate,
      brand: entry.brand,
      model: entry.model,
      modelYear: `${entry.manufactureYear}/${entry.modelYear}`,
    }
  }

  async getVehicleDetails(rawPlate: string): Promise<RawVehicleIdentity | null> {
    await delay(200, 500)
    const plate = sanitizePlate(rawPlate)
    if (this.notFoundPlates.has(plate)) return null
    const entry = CATALOG[hashPlate(plate) % CATALOG.length]
    const seed = hashPlate(plate)
    return {
      plate,
      ...entry,
      chassisMasked: `•••••••${(seed % 90000 + 10000)}`,
      renavamMasked: `•••••${(seed % 900 + 100)}`,
    }
  }

  async getRestrictions(rawPlate: string): Promise<RawRestriction> {
    await delay(200, 450)
    const seed = hashPlate(sanitizePlate(rawPlate))
    const has = seed % 5 === 0
    return has
      ? { found: true, items: [{ type: 'Restrição judicial', date: '2024-03-12', origin: 'Tribunal de Justiça' }] }
      : { found: false }
  }

  async getDebts(rawPlate: string): Promise<RawDebt> {
    await delay(200, 450)
    const seed = hashPlate(sanitizePlate(rawPlate))
    const has = seed % 4 === 0
    return has
      ? { found: true, hasOpenDebts: true, note: 'IPVA e taxas do exercício vigente' }
      : { found: true, hasOpenDebts: false }
  }

  async getTheftRecords(rawPlate: string): Promise<RawTheftRecord> {
    await delay(200, 450)
    const seed = hashPlate(sanitizePlate(rawPlate))
    const has = seed % 11 === 0
    return has
      ? { found: true, occurrences: [{ date: '2022-08-02', state: 'SP' }] }
      : { found: false }
  }

  async getLienInformation(rawPlate: string): Promise<RawLienInformation> {
    await delay(200, 450)
    const seed = hashPlate(sanitizePlate(rawPlate))
    const has = seed % 3 === 0
    return has
      ? { found: true, hasActiveLien: true, financialInstitution: 'Banco parceiro (dado fictício)' }
      : { found: true, hasActiveLien: false }
  }

  async getClaims(rawPlate: string): Promise<RawClaim> {
    await delay(200, 500)
    const seed = hashPlate(sanitizePlate(rawPlate))
    const has = seed % 6 === 0
    return has
      ? { found: true, occurrences: [{ date: '2023-11-20', severity: 'média' }] }
      : { found: false }
  }

  async getAdditionalHistory(rawPlate: string): Promise<RawAdditionalHistory> {
    await delay(200, 500)
    const seed = hashPlate(sanitizePlate(rawPlate))
    return {
      recall: seed % 9 === 0 ? { found: true, note: 'Campanha de recall do fabricante em aberto' } : { found: false },
      auction: seed % 13 === 0 ? { found: true, note: 'Registro de passagem por leilão' } : { found: false },
      other: [{ label: 'Uso declarado em aplicativo', found: seed % 7 === 0 }],
    }
  }
}
