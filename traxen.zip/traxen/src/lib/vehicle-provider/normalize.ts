import { detectPlateFormat, sanitizePlate } from '@/lib/plate'
import type { Product } from '@/lib/products'
import { getActiveProduct } from '@/lib/store'
import { generateProtocol } from '@/lib/utils'
import type { Finding, VehicleReport } from '@/types/report'
import { MockVehicleProvider } from './mock-provider'
import type { VehicleDataProvider } from './types'

// ---------------------------------------------------------------------------
// Fábrica do provider ativo. Troque a lógica abaixo para selecionar um
// adapter real conforme a variável de ambiente VEHICLE_PROVIDER — nenhuma
// tela ou rota depende de qual provider está ativo.
// ---------------------------------------------------------------------------
let cachedProvider: VehicleDataProvider | null = null

export function getVehicleProvider(): VehicleDataProvider {
  if (!cachedProvider) {
    // switch (process.env.VEHICLE_PROVIDER) {
    //   case 'provider-a': cachedProvider = new ProviderAAdapter(...); break
    //   default: cachedProvider = new MockVehicleProvider()
    // }
    cachedProvider = new MockVehicleProvider()
  }
  return cachedProvider
}

function unavailable(label: string): Finding {
  return { status: 'unavailable', label, detail: 'Informação indisponível na fonte consultada.' }
}

/**
 * Constrói o VehicleReport normalizado, consultando apenas os campos
 * incluídos no produto contratado. Nunca promete campos que a integração
 * (mock ou real) não fornece — na ausência de dado, o status é
 * "unavailable", nunca "ok".
 */
export async function buildVehicleReport(plateInput: string, productSlug: string): Promise<VehicleReport | null> {
  const plate = sanitizePlate(plateInput)
  const format = detectPlateFormat(plate)
  const product = getActiveProduct(productSlug) as Product
  const provider = getVehicleProvider()

  const details = await provider.getVehicleDetails(plate)
  if (!details || !format) return null

  const includes = (key: Product['fields'][number]) => product.fields.includes(key)

  const [restrictionsRaw, debtsRaw, theftRaw, lienRaw, claimsRaw, historyRaw] = await Promise.all([
    includes('restrictions') ? provider.getRestrictions(plate) : Promise.resolve(null),
    includes('debts') ? provider.getDebts(plate) : Promise.resolve(null),
    includes('theft') ? provider.getTheftRecords(plate) : Promise.resolve(null),
    includes('lien') ? provider.getLienInformation(plate) : Promise.resolve(null),
    includes('claims') ? provider.getClaims(plate) : Promise.resolve(null),
    includes('history') ? provider.getAdditionalHistory(plate) : Promise.resolve(null),
  ])

  const restrictions: Finding = !restrictionsRaw
    ? unavailable('Restrições')
    : restrictionsRaw.found
      ? { status: 'restriction', label: 'Restrições', detail: restrictionsRaw.items?.[0]?.type ?? 'Registro encontrado na fonte consultada.' }
      : { status: 'ok', label: 'Restrições', detail: 'Nenhum registro encontrado na fonte consultada.' }

  const debts: Finding = !debtsRaw
    ? unavailable('Débitos')
    : debtsRaw.hasOpenDebts
      ? { status: 'attention', label: 'Débitos', detail: debtsRaw.note ?? 'Débitos informados na fonte consultada.' }
      : { status: 'ok', label: 'Débitos', detail: 'Nenhum débito informado na fonte consultada.' }

  const theft: Finding = !theftRaw
    ? unavailable('Roubo/Furto')
    : theftRaw.found
      ? { status: 'restriction', label: 'Roubo/Furto', detail: 'Ocorrência encontrada na fonte consultada.' }
      : { status: 'ok', label: 'Roubo/Furto', detail: 'Sem registro de roubo/furto na fonte consultada.' }

  const lien: Finding = !lienRaw
    ? unavailable('Gravame')
    : lienRaw.hasActiveLien
      ? { status: 'attention', label: 'Gravame', detail: lienRaw.financialInstitution ? `Vínculo com ${lienRaw.financialInstitution}` : 'Vínculo financeiro encontrado.' }
      : { status: 'ok', label: 'Gravame', detail: 'Nenhum vínculo financeiro informado na fonte consultada.' }

  const claims: Finding = !claimsRaw
    ? unavailable('Sinistros')
    : claimsRaw.found
      ? { status: 'attention', label: 'Sinistros', detail: 'Ocorrência informada na fonte consultada.' }
      : { status: 'ok', label: 'Sinistros', detail: 'Nenhum sinistro informado na fonte consultada.' }

  const recall: Finding = !historyRaw
    ? unavailable('Recall')
    : historyRaw.recall.found
      ? { status: 'attention', label: 'Recall', detail: historyRaw.recall.note }
      : { status: 'ok', label: 'Recall', detail: 'Nenhuma campanha em aberto informada.' }

  const auction: Finding = !historyRaw
    ? unavailable('Leilão')
    : historyRaw.auction.found
      ? { status: 'attention', label: 'Leilão', detail: historyRaw.auction.note }
      : { status: 'ok', label: 'Leilão', detail: 'Nenhum registro de passagem por leilão informado.' }

  const other: Finding = !historyRaw
    ? unavailable('Outras informações')
    : { status: 'ok', label: 'Outras informações', detail: 'Sem apontamentos adicionais nas bases consultadas.' }

  const summary: Finding[] = [
    { status: 'ok' as const, label: 'Dados cadastrais encontrados' },
    theft.status !== 'unavailable' ? theft : unavailable('Roubo/Furto'),
    ...([restrictions, debts, lien, claims].filter((f) => f.status !== 'unavailable') as Finding[]),
  ].slice(0, 4)

  const weights: Record<Finding['status'], number> = { ok: 0, unavailable: 4, attention: 14, restriction: 30 }
  const consideredFindings = [restrictions, debts, theft, lien, claims, recall, auction].filter(
    (f) => f.status !== 'unavailable',
  )
  const raw = consideredFindings.reduce((acc, f) => acc + weights[f.status], 0)
  const score = Math.max(2, Math.min(96, raw === 0 ? 6 : raw))
  const scoreLabel = score <= 25 ? 'Baixo nível de atenção' : score <= 55 ? 'Atenção moderada' : 'Alto nível de atenção'

  return {
    protocol: generateProtocol(),
    productSlug: product.slug,
    productName: product.name,
    queriedAt: new Date().toISOString(),
    provider: provider.name,
    plateInput: plate,
    identity: {
      plate: details.plate,
      plateFormat: format,
      brand: details.brand,
      model: details.model,
      manufactureYear: details.manufactureYear,
      modelYear: details.modelYear,
      fuel: details.fuel,
      color: details.color,
      category: details.category,
      species: details.species,
      city: details.city,
      state: details.state,
      chassisMasked: details.chassisMasked,
      renavamMasked: details.renavamMasked,
    },
    score: { value: score, label: scoreLabel, isInterpretive: true },
    summary,
    sections: { theft, restrictions, lien, debts, claims, recall, auction, other },
  }
}
