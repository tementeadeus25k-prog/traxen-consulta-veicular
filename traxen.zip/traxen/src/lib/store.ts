import bcrypt from 'bcryptjs'
import type { VehicleReport } from '@/types/report'
import { PRODUCTS, type Product } from './products'

// ---------------------------------------------------------------------------
// "Banco de dados" em memória — SOMENTE para fins de demonstração.
//
// Em produção isto é substituído por PostgreSQL via Prisma (ver
// prisma/schema.prisma, que já modela estas mesmas entidades). É mantido em
// `globalThis` para sobreviver ao hot-reload do Next.js em desenvolvimento.
// Os dados são perdidos ao reiniciar o servidor — isso é esperado aqui.
// ---------------------------------------------------------------------------

export type UserRole = 'cliente' | 'empresa' | 'admin'
export type UserStatus = 'ativo' | 'bloqueado'

export interface StoredUser {
  id: string
  name: string
  email: string
  phone: string
  passwordHash: string
  role: UserRole
  status: UserStatus
  walletCents: number
  createdAt: string
}

export type QueryStatus = 'aguardando_pagamento' | 'processando' | 'concluida' | 'falhou'

export interface StoredQuery {
  id: string
  userId: string
  protocol: string
  plate: string
  vehicleLabel?: string
  productSlug: string
  productName: string
  priceCents: number
  providerCostCents: number
  status: QueryStatus
  chargeId?: string
  paymentMethod?: 'pix' | 'card'
  report?: VehicleReport
  createdAt: string
}

export interface WalletTransaction {
  id: string
  userId: string
  description: string
  amountCents: number // positivo = entrada, negativo = saída
  balanceAfterCents: number
  createdAt: string
}

export interface Coupon {
  id: string
  code: string
  discountType: 'percent' | 'fixed'
  value: number
  maxUses: number
  uses: number
  expiresAt: string
  status: 'ativo' | 'inativo'
}

export interface AuditLogEntry {
  id: string
  actor: string
  action: string
  meta?: string
  createdAt: string
}

interface Store {
  users: StoredUser[]
  queries: StoredQuery[]
  wallet: WalletTransaction[]
  coupons: Coupon[]
  products: Product[]
  auditLogs: AuditLogEntry[]
  chargeToQuery: Map<string, string>
}

function seed(): Store {
  const demoPasswordHash = bcrypt.hashSync('demo1234', 8)
  const now = Date.now()
  const iso = (daysAgo: number) => new Date(now - daysAgo * 86400000).toISOString()

  const users: StoredUser[] = [
    {
      id: 'usr_demo',
      name: 'Marina Alves',
      email: 'demo@traxen.com.br',
      phone: '(11) 98888-1234',
      passwordHash: demoPasswordHash,
      role: 'cliente',
      status: 'ativo',
      walletCents: 4200,
      createdAt: iso(120),
    },
    {
      id: 'usr_admin',
      name: 'Equipe Traxen',
      email: 'admin@traxen.com.br',
      phone: '(11) 90000-0000',
      passwordHash: demoPasswordHash,
      role: 'admin',
      status: 'ativo',
      walletCents: 0,
      createdAt: iso(400),
    },
    {
      id: 'usr_0001',
      name: 'Rodrigo Nascimento',
      email: 'rodrigo.nascimento@exemplo.com',
      phone: '(21) 99123-4455',
      passwordHash: demoPasswordHash,
      role: 'cliente',
      status: 'ativo',
      walletCents: 0,
      createdAt: iso(88),
    },
    {
      id: 'usr_0002',
      name: 'Loja Autêntico Veículos',
      email: 'contato@autenticoveiculos.com.br',
      phone: '(31) 3222-1010',
      passwordHash: demoPasswordHash,
      role: 'empresa',
      status: 'ativo',
      walletCents: 128000,
      createdAt: iso(210),
    },
    {
      id: 'usr_0003',
      name: 'Camila Torres',
      email: 'camila.torres@exemplo.com',
      phone: '(41) 98811-2233',
      passwordHash: demoPasswordHash,
      role: 'cliente',
      status: 'bloqueado',
      walletCents: 0,
      createdAt: iso(300),
    },
  ]

  const historicalPlates = ['ABC1D23', 'RIO2A18', 'BRA4B77', 'PJT9C02', 'SPX1E45']
  const queries: StoredQuery[] = historicalPlates.map((plate, i) => {
    const product = PRODUCTS[i % PRODUCTS.length]
    return {
      id: `qry_seed_${i}`,
      userId: 'usr_demo',
      protocol: `TRX-SEED-${1000 + i}`,
      plate,
      vehicleLabel: undefined,
      productSlug: product.slug,
      productName: product.name,
      priceCents: product.priceCents,
      providerCostCents: Math.round(product.priceCents * 0.35),
      status: 'concluida',
      createdAt: iso(3 + i * 6),
    }
  })

  const wallet: WalletTransaction[] = [
    { id: 'wtx_1', userId: 'usr_demo', description: 'Recarga via PIX', amountCents: 5000, balanceAfterCents: 5000, createdAt: iso(40) },
    { id: 'wtx_2', userId: 'usr_demo', description: 'Consulta Completa · ABC1D23', amountCents: -800, balanceAfterCents: 4200, createdAt: iso(3) },
  ]

  const coupons: Coupon[] = [
    { id: 'cpn_1', code: 'BEMVINDO10', discountType: 'percent', value: 10, maxUses: 500, uses: 214, expiresAt: iso(-30), status: 'ativo' },
    { id: 'cpn_2', code: 'FROTA20', discountType: 'percent', value: 20, maxUses: 100, uses: 41, expiresAt: iso(-60), status: 'ativo' },
    { id: 'cpn_3', code: 'BLACKFRIDAY', discountType: 'fixed', value: 1000, maxUses: 1000, uses: 1000, expiresAt: iso(20), status: 'inativo' },
  ]

  const auditLogs: AuditLogEntry[] = [
    { id: 'log_1', actor: 'admin@traxen.com.br', action: 'Cliente bloqueado', meta: 'camila.torres@exemplo.com', createdAt: iso(2) },
    { id: 'log_2', actor: 'admin@traxen.com.br', action: 'Crédito adicionado', meta: '+R$ 500,00 · Loja Autêntico Veículos', createdAt: iso(6) },
    { id: 'log_3', actor: 'sistema', action: 'Produto atualizado', meta: 'Consulta Premium · preço alterado', createdAt: iso(15) },
  ]

  return { users, queries, wallet, coupons, products: PRODUCTS.map((p) => ({ ...p })), auditLogs, chargeToQuery: new Map() }
}

const globalForStore = globalThis as unknown as { __traxenStore?: Store }
export const store: Store = globalForStore.__traxenStore ?? seed()
if (!globalForStore.__traxenStore) globalForStore.__traxenStore = store

// --- Helpers -----------------------------------------------------------

export function getActiveProduct(slug: string): Product | undefined {
  return store.products.find((p) => p.slug === slug)
}

export function findUserByEmail(email: string) {
  return store.users.find((u) => u.email.toLowerCase() === email.toLowerCase())
}

export function findUserById(id: string) {
  return store.users.find((u) => u.id === id)
}

export function createUser(input: { name: string; email: string; phone: string; password: string }): StoredUser {
  const user: StoredUser = {
    id: `usr_${Math.random().toString(36).slice(2, 10)}`,
    name: input.name,
    email: input.email,
    phone: input.phone,
    passwordHash: bcrypt.hashSync(input.password, 8),
    role: 'cliente',
    status: 'ativo',
    walletCents: 0,
    createdAt: new Date().toISOString(),
  }
  store.users.push(user)
  return user
}

export function getQueriesByUser(userId: string): StoredQuery[] {
  return store.queries.filter((q) => q.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export function getQueryById(id: string): StoredQuery | undefined {
  return store.queries.find((q) => q.id === id)
}

export function createQuery(input: Omit<StoredQuery, 'id' | 'createdAt' | 'status'>): StoredQuery {
  const query: StoredQuery = {
    ...input,
    id: `qry_${Math.random().toString(36).slice(2, 10)}`,
    status: 'aguardando_pagamento',
    createdAt: new Date().toISOString(),
  }
  store.queries.push(query)
  return query
}

export function updateQuery(id: string, patch: Partial<StoredQuery>) {
  const idx = store.queries.findIndex((q) => q.id === id)
  if (idx === -1) return undefined
  store.queries[idx] = { ...store.queries[idx], ...patch }
  return store.queries[idx]
}

export function addAuditLog(actor: string, action: string, meta?: string) {
  store.auditLogs.unshift({ id: `log_${Math.random().toString(36).slice(2, 8)}`, actor, action, meta, createdAt: new Date().toISOString() })
}

export function adminMetrics() {
  const now = Date.now()
  const startOfDay = new Date(new Date().setHours(0, 0, 0, 0)).getTime()
  const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime()

  const paid = store.queries.filter((q) => q.status === 'concluida')
  const today = paid.filter((q) => new Date(q.createdAt).getTime() >= startOfDay)
  const month = paid.filter((q) => new Date(q.createdAt).getTime() >= startOfMonth)

  const sum = (arr: StoredQuery[]) => arr.reduce((a, q) => a + q.priceCents, 0)
  const revenueToday = sum(today)
  const revenueMonth = sum(month) || sum(paid) // garante gráfico não-vazio na demo
  const ticketMedio = paid.length ? Math.round(sum(paid) / paid.length) : 0
  const totalAttempts = store.queries.length || 1
  const approvalRate = Math.round((paid.length / totalAttempts) * 100)

  return {
    revenueTodayCents: revenueToday,
    revenueMonthCents: revenueMonth,
    queriesToday: today.length,
    queriesMonth: month.length || paid.length,
    newClients: store.users.filter((u) => u.role !== 'admin' && Date.now() - new Date(u.createdAt).getTime() < 30 * 86400000).length,
    ticketMedioCents: ticketMedio,
    approvalRate,
    now,
  }
}
