import type { ChargeResult, CreateChargeInput, PaymentProvider, PaymentStatus } from './types'

// ---------------------------------------------------------------------------
// MockPaymentProvider — simula PIX e Cartão para fins de demonstração.
// Em produção, substitua por um adapter real (ex.: gateway brasileiro),
// implementando o mesmo contrato PaymentProvider. As chaves de API do
// gateway real ficam somente em variáveis de ambiente do servidor.
// ---------------------------------------------------------------------------

const charges = new Map<string, PaymentStatus>()
const idempotency = new Map<string, string>() // idempotencyKey -> chargeId

export class MockPaymentProvider implements PaymentProvider {
  readonly name = 'mock-payment-v1'

  async createCharge(input: CreateChargeInput): Promise<ChargeResult> {
    const existing = idempotency.get(input.idempotencyKey)
    if (existing) {
      const status = charges.get(existing) ?? 'pending'
      return { chargeId: existing, status, method: input.method, amountCents: input.amountCents }
    }

    const chargeId = `chg_${Math.random().toString(36).slice(2, 10)}`
    charges.set(chargeId, 'pending')
    idempotency.set(input.idempotencyKey, chargeId)

    if (input.method === 'pix') {
      return {
        chargeId,
        status: 'pending',
        method: 'pix',
        amountCents: input.amountCents,
        pixCopyPaste: `00020126580014BR.GOV.BCB.PIX0136${chargeId}5204000053039865406${(input.amountCents / 100).toFixed(2)}5802BR5913TRAXEN PAG6009SAO PAULO62070503***6304MOCK`,
      }
    }

    return { chargeId, status: 'pending', method: 'card', amountCents: input.amountCents }
  }

  async getChargeStatus(chargeId: string): Promise<PaymentStatus> {
    return charges.get(chargeId) ?? 'pending'
  }

  async refund(chargeId: string): Promise<{ ok: boolean }> {
    if (!charges.has(chargeId)) return { ok: false }
    charges.set(chargeId, 'refunded')
    return { ok: true }
  }

  verifyWebhookSignature(_payload: string, signature: string | null): boolean {
    // Em produção: validar HMAC com PAYMENT_WEBHOOK_SECRET.
    return Boolean(signature)
  }

  // Utilitário exclusivo do mock, para simular a confirmação assíncrona do
  // gateway (o que um webhook real faria chegando de fora).
  __simulateApproval(chargeId: string, approve = true) {
    charges.set(chargeId, approve ? 'approved' : 'refused')
  }
}

let instance: MockPaymentProvider | null = null
export function getPaymentProvider(): MockPaymentProvider {
  if (!instance) instance = new MockPaymentProvider()
  return instance
}
