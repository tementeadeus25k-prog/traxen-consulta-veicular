import { store, updateQuery } from '@/lib/store'
import { getPaymentProvider } from './mock-provider'

/**
 * Único ponto de confirmação de pagamento. É chamado pelo endpoint de
 * webhook (src/app/api/payments/webhook) quando o gateway real notifica o
 * resultado, e — apenas neste protótipo — também pelo timer que simula essa
 * notificação assíncrona (ver create-charge/route.ts).
 *
 * O frontend NUNCA chama esta função nem pode marcar um pagamento como
 * aprovado por conta própria.
 */
export function confirmPayment(chargeId: string, status: 'approved' | 'refused') {
  const provider = getPaymentProvider()
  provider.__simulateApproval(chargeId, status === 'approved')

  const queryId = store.chargeToQuery.get(chargeId)
  if (!queryId) return
  updateQuery(queryId, { status: status === 'approved' ? 'processando' : 'falhou' })
}
