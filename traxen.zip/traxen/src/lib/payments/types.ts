// ---------------------------------------------------------------------------
// Contrato de gateway de pagamento, desacoplado do provedor.
//
// REGRAS DE OURO (ver README > Pagamentos):
// 1) O backend NUNCA libera uma consulta paga apenas porque o frontend
//    informou "pagamento aprovado" — a confirmação vem do webhook/consulta
//    segura ao gateway (ver src/app/api/payments/webhook/route.ts).
// 2) Toda criação de cobrança usa uma chave de idempotência para evitar
//    cobrança ou consulta duplicada em caso de retry.
// ---------------------------------------------------------------------------

export type PaymentMethod = 'pix' | 'card'
export type PaymentStatus = 'pending' | 'approved' | 'refused' | 'refunded'

export interface CreateChargeInput {
  idempotencyKey: string
  amountCents: number
  method: PaymentMethod
  description: string
  customer: { name: string; email: string }
}

export interface ChargeResult {
  chargeId: string
  status: PaymentStatus
  method: PaymentMethod
  amountCents: number
  pixCopyPaste?: string
  pixQrCodeDataUrl?: string
}

export interface WebhookEvent {
  chargeId: string
  status: PaymentStatus
  receivedAt: string
  raw: Record<string, unknown>
}

export interface PaymentProvider {
  readonly name: string
  createCharge(input: CreateChargeInput): Promise<ChargeResult>
  getChargeStatus(chargeId: string): Promise<PaymentStatus>
  refund(chargeId: string): Promise<{ ok: boolean }>
  /** Valida a assinatura/segredo do webhook recebido. */
  verifyWebhookSignature(payload: string, signature: string | null): boolean
}
