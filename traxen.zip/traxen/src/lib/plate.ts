// Reconhecimento e máscara de placas — padrão antigo (LLL-NNNN) e Mercosul (LLLNLNN)

const OLD_PATTERN = /^[A-Z]{3}[0-9]{4}$/
const MERCOSUL_PATTERN = /^[A-Z]{3}[0-9][A-Z][0-9]{2}$/

export type PlateFormat = 'antiga' | 'mercosul' | null

export function sanitizePlate(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 7)
}

export function detectPlateFormat(raw: string): PlateFormat {
  const value = sanitizePlate(raw)
  if (OLD_PATTERN.test(value)) return 'antiga'
  if (MERCOSUL_PATTERN.test(value)) return 'mercosul'
  return null
}

export function isValidPlate(raw: string): boolean {
  return detectPlateFormat(raw) !== null
}

export function formatPlateDisplay(raw: string): string {
  const value = sanitizePlate(raw)
  if (value.length <= 3) return value
  return `${value.slice(0, 3)}-${value.slice(3)}`
}

export function maskPlateInput(raw: string): string {
  // Aplica máscara enquanto o usuário digita, sem travar formato antes de 4 chars
  const value = sanitizePlate(raw)
  if (value.length <= 3) return value
  return `${value.slice(0, 3)}${value.length > 3 ? '-' : ''}${value.slice(3)}`
}
