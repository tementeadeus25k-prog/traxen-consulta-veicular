import { NextResponse, type NextRequest } from 'next/server'
import { SESSION_COOKIE, verifySessionToken } from '@/lib/auth/session'

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl
  const token = req.cookies.get(SESSION_COOKIE)?.value
  const session = await verifySessionToken(token)

  if (pathname.startsWith('/painel') || pathname.startsWith('/checkout')) {
    if (!session) {
      const url = req.nextUrl.clone()
      url.pathname = '/entrar'
      url.searchParams.set('next', pathname)
      return NextResponse.redirect(url)
    }
  }

  if (pathname.startsWith('/admin')) {
    if (!session || session.role !== 'admin') {
      const url = req.nextUrl.clone()
      url.pathname = '/entrar'
      url.searchParams.set('next', pathname)
      return NextResponse.redirect(url)
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/painel/:path*', '/admin/:path*', '/checkout/:path*'],
}
