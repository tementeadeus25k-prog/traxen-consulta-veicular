'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { useToast } from '@/components/ui/toast'

export function ReportActionsBar({ backHref }: { backHref: string }) {
  const { push } = useToast()

  function handleShare() {
    if (typeof navigator !== 'undefined' && navigator.share) {
      navigator.share({ title: 'Relatório veicular Traxen', url: window.location.href }).catch(() => {})
    } else if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(window.location.href)
      push({ title: 'Link copiado', description: 'O link deste relatório foi copiado para a área de transferência.', tone: 'success' })
    }
  }

  function handlePdf() {
    window.print()
  }

  return (
    <div className="no-print sticky top-0 z-30 border-b border-surface-border bg-white/90 backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 sm:px-8">
        <Link href={backHref} className="flex items-center gap-2 text-[13px] font-medium text-navy-500 hover:text-navy-950">
          <Icon.ArrowRight className="h-4 w-4 rotate-180" />
          Voltar
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleShare} iconLeft={<Icon.Share className="h-4 w-4" />}>
            Compartilhar
          </Button>
          <Button variant="outline" size="sm" onClick={handlePdf} iconLeft={<Icon.Printer className="h-4 w-4" />}>
            Imprimir
          </Button>
          <Button size="sm" onClick={handlePdf} iconLeft={<Icon.Download className="h-4 w-4" />}>
            Baixar PDF
          </Button>
        </div>
      </div>
    </div>
  )
}
