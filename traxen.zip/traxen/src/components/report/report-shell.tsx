'use client'

import { formatDate } from '@/lib/utils'
import { ReportView } from './report-view'
import { ReportActionsBar } from './report-actions-bar'
import type { VehicleReport } from '@/types/report'

const NAV = [
  { id: 'visao-geral', label: 'Visão geral' },
  { id: 'dados-cadastrais', label: 'Dados cadastrais' },
  { id: 'restricoes', label: 'Restrições' },
  { id: 'debitos', label: 'Débitos' },
  { id: 'roubo-furto', label: 'Roubo/Furto' },
  { id: 'gravame', label: 'Gravame' },
  { id: 'sinistros', label: 'Sinistros' },
  { id: 'historico', label: 'Histórico' },
  { id: 'observacoes', label: 'Observações' },
]

export function ReportShell({ report, backHref, isSample }: { report: VehicleReport; backHref: string; isSample?: boolean }) {
  return (
    <div className="min-h-screen bg-surface-muted">
      <ReportActionsBar backHref={backHref} />

      {isSample && (
        <div className="no-print bg-attention-50 py-2.5 text-center text-[12.5px] font-medium text-attention-600">
          Exemplo ilustrativo com dados fictícios — não corresponde a um veículo real.
        </div>
      )}

      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-8 sm:px-8 lg:grid-cols-[220px_1fr]">
        <aside className="no-print hidden lg:block">
          <div className="sticky top-24 flex flex-col gap-0.5">
            {NAV.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className="rounded-lg px-3 py-2 text-[13px] font-medium text-navy-500 transition-colors hover:bg-white hover:text-navy-950"
              >
                {item.label}
              </a>
            ))}
            <div className="mt-4 rounded-xl border border-surface-border bg-white p-4">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-navy-300">Consultado em</p>
              <p className="mt-1 text-[13px] font-semibold text-navy-800">{formatDate(report.queriedAt, true)}</p>
            </div>
          </div>
        </aside>

        <div className="no-print mb-1 flex gap-2 overflow-x-auto pb-1 lg:hidden">
          {NAV.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className="shrink-0 rounded-full border border-surface-border bg-white px-3 py-1.5 text-[12.5px] font-medium text-navy-600"
            >
              {item.label}
            </a>
          ))}
        </div>

        <main>
          <ReportView report={report} id={(s) => s} />
        </main>
      </div>
    </div>
  )
}
