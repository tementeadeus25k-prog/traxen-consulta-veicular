import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import { StatusIcon, StatusRow, statusText } from '@/components/ui/status-pill'
import { ScoreGauge } from './score-gauge'
import { formatDate } from '@/lib/utils'
import type { VehicleReport } from '@/types/report'

function DataField({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-b border-surface-border py-3 last:border-0 sm:border-0 sm:py-0">
      <p className="text-[11.5px] font-medium uppercase tracking-wide text-navy-300">{label}</p>
      <p className="mt-1 text-[14px] font-semibold text-navy-950">{value}</p>
    </div>
  )
}

export function ReportView({ report, id }: { report: VehicleReport; id?: (section: string) => string }) {
  const anchor = (section: string) => (id ? id(section) : undefined)
  const s = report.sections

  return (
    <div className="flex flex-col gap-6">
      {/* Cabeçalho do documento */}
      <Card id={anchor('visao-geral')} className="overflow-hidden">
        <div className="border-b border-surface-border bg-navy-950 px-6 py-5 text-white sm:px-8 sm:py-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-electric-300">Relatório veicular</p>
              <p className="mt-1 text-[13px] text-navy-200">
                Consulta realizada em {formatDate(report.queriedAt, true)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-electric-300">Protocolo</p>
              <p className="mt-1 font-mono-plate text-[13px] font-semibold text-white">{report.protocol}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 px-6 py-6 sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <div>
            <Badge tone="electric">{report.productName}</Badge>
            <h1 className="mt-3 text-[22px] font-bold tracking-tight text-navy-950">
              {report.identity.brand} {report.identity.model}
            </h1>
            <p className="mt-1 font-mono-plate text-[14px] font-semibold text-navy-400">
              Placa {report.identity.plate}
              <span className="ml-2 font-sans text-[12px] font-medium text-navy-300">
                ({report.identity.plateFormat === 'mercosul' ? 'Mercosul' : 'Padrão antigo'})
              </span>
            </p>
          </div>
          <ScoreGauge value={report.score.value} label={report.score.label} />
        </div>
      </Card>

      {/* Resumo */}
      <Card>
        <div className="border-b border-surface-border px-6 py-4 sm:px-8">
          <h2 className="text-[15px] font-semibold text-navy-950">Resumo</h2>
        </div>
        <div className="grid gap-x-8 px-6 py-2 sm:grid-cols-2 sm:px-8">
          {report.summary.map((f, i) => (
            <div key={i} className="flex items-center gap-2.5 border-b border-surface-border py-3 last:border-0 sm:[&:nth-last-child(-n+1)]:border-0">
              <StatusIcon status={f.status} />
              <span className="text-[13.5px] font-medium text-navy-800">{f.label}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Dados do veículo */}
      <Card id={anchor('dados-cadastrais')}>
        <div className="border-b border-surface-border px-6 py-4 sm:px-8">
          <h2 className="text-[15px] font-semibold text-navy-950">Dados do veículo</h2>
        </div>
        <div className="grid grid-cols-2 gap-x-6 gap-y-5 px-6 py-6 sm:grid-cols-3 sm:px-8">
          <DataField label="Marca" value={report.identity.brand} />
          <DataField label="Modelo" value={report.identity.model} />
          <DataField label="Ano de fabricação" value={String(report.identity.manufactureYear)} />
          <DataField label="Ano modelo" value={String(report.identity.modelYear)} />
          <DataField label="Combustível" value={report.identity.fuel} />
          <DataField label="Cor" value={report.identity.color} />
          <DataField label="Categoria" value={report.identity.category} />
          <DataField label="Espécie" value={report.identity.species} />
          <DataField label="Município" value={report.identity.city} />
          <DataField label="UF" value={report.identity.state} />
          {report.identity.chassisMasked && <DataField label="Chassi" value={report.identity.chassisMasked} />}
          {report.identity.renavamMasked && <DataField label="Renavam" value={report.identity.renavamMasked} />}
        </div>
      </Card>

      {/* Situação */}
      <Card id={anchor('situacao')}>
        <div className="border-b border-surface-border px-6 py-4 sm:px-8">
          <h2 className="text-[15px] font-semibold text-navy-950">Situação</h2>
        </div>
        <div className="divide-y divide-surface-border px-6 sm:px-8">
          <div id={anchor('roubo-furto')}>
            <StatusRow label="Roubo/Furto" status={s.theft.status} detail={s.theft.detail} />
          </div>
          <div id={anchor('restricoes')}>
            <StatusRow label="Restrições" status={s.restrictions.status} detail={s.restrictions.detail} />
          </div>
          <div id={anchor('gravame')}>
            <StatusRow label="Gravame" status={s.lien.status} detail={s.lien.detail} />
          </div>
          <div id={anchor('debitos')}>
            <StatusRow label="Débitos" status={s.debts.status} detail={s.debts.detail} />
          </div>
          <div id={anchor('sinistros')}>
            <StatusRow label="Sinistros" status={s.claims.status} detail={s.claims.detail} />
          </div>
          <StatusRow label="Recall" status={s.recall.status} detail={s.recall.detail} />
          <div id={anchor('historico')}>
            <StatusRow label="Leilão" status={s.auction.status} detail={s.auction.detail} />
          </div>
          <StatusRow label="Outras informações disponíveis" status={s.other.status} detail={s.other.detail} />
        </div>
      </Card>

      {/* Observações */}
      <Card id={anchor('observacoes')} className="bg-navy-50/60 p-6 sm:p-8">
        <h2 className="text-[13.5px] font-semibold text-navy-950">Observações</h2>
        <p className="mt-2 text-[13px] leading-relaxed text-navy-500">
          As informações apresentadas correspondem às bases disponíveis no momento da consulta e podem sofrer
          alterações. O símbolo <strong>—</strong> indica informação indisponível na fonte consultada e nunca deve
          ser interpretado como &quot;nada consta&quot;. O índice de atenção é uma interpretação interna da Traxen
          sobre os dados encontrados e não constitui certificação de qualidade, procedência ou estado de
          conservação do veículo. Fonte de dados: {report.provider === 'mock-provider-v1' ? 'ambiente de demonstração (dados fictícios)' : report.provider}.
        </p>
      </Card>
    </div>
  )
}

export function legendItems() {
  return [
    { status: 'ok' as const, text: statusText('ok') },
    { status: 'attention' as const, text: statusText('attention') },
    { status: 'restriction' as const, text: statusText('restriction') },
    { status: 'unavailable' as const, text: statusText('unavailable') },
  ]
}
