import { cn } from '@/lib/utils'

function toneFor(score: number) {
  if (score <= 25) return { stroke: '#159A4E', text: 'text-positive-600', bg: 'text-positive-50' }
  if (score <= 55) return { stroke: '#D8930F', text: 'text-attention-600', bg: 'text-attention-50' }
  return { stroke: '#DC3128', text: 'text-critical-600', bg: 'text-critical-50' }
}

export function ScoreGauge({ value, label, size = 168 }: { value: number; label: string; size?: number }) {
  const tone = toneFor(value)
  const radius = 70
  const circumference = Math.PI * radius // semicírculo
  const offset = circumference * (1 - value / 100)

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size / 1.62 }}>
        <svg viewBox="0 0 180 100" className="h-full w-full overflow-visible">
          <path
            d="M 20 95 A 70 70 0 0 1 160 95"
            fill="none"
            stroke="#EEF0F6"
            strokeWidth={14}
            strokeLinecap="round"
          />
          <path
            d="M 20 95 A 70 70 0 0 1 160 95"
            fill="none"
            stroke={tone.stroke}
            strokeWidth={14}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 900ms cubic-bezier(0.16,1,0.3,1)' }}
          />
        </svg>
        <div className="absolute inset-x-0 bottom-0 flex flex-col items-center">
          <span className="text-[34px] font-extrabold leading-none tracking-tight text-navy-950">{value}</span>
          <span className="text-[12px] font-medium text-navy-300">/ 100</span>
        </div>
      </div>
      <p className={cn('mt-1 text-[13.5px] font-semibold', tone.text)}>{label}</p>
      <p className="mt-4 max-w-[240px] text-center text-[12px] leading-relaxed text-navy-300">
        Índice de atenção: interpretação interna dos dados encontrados nesta consulta. Não é uma certificação de
        qualidade do veículo.
      </p>
    </div>
  )
}
