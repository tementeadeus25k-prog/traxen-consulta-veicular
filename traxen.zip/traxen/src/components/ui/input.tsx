import * as React from 'react'
import { cn } from '@/lib/utils'

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: string
  hint?: string
  label?: string
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, error, hint, label, id, ...props }, ref) => {
    const inputId = id || props.name
    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label htmlFor={inputId} className="text-[13px] font-medium text-navy-700">
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={cn(
            'focus-ring h-11 w-full rounded-xl border bg-white px-3.5 text-[14px] text-navy-950 placeholder:text-navy-300',
            'transition-colors duration-150',
            error ? 'border-critical-500' : 'border-surface-border hover:border-navy-300',
            className,
          )}
          {...props}
        />
        {error ? (
          <p className="text-[12.5px] font-medium text-critical-600">{error}</p>
        ) : hint ? (
          <p className="text-[12.5px] text-navy-400">{hint}</p>
        ) : null}
      </div>
    )
  },
)
Input.displayName = 'Input'
