import type { SVGProps } from 'react'

type IconProps = SVGProps<SVGSVGElement>

const base = {
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.7,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
}

export const Icon = {
  Shield: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
      <path d="M9 12l2 2 4-4" />
    </svg>
  ),
  Bolt: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8z" />
    </svg>
  ),
  Lock: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <rect x="5" y="11" width="14" height="9" rx="2" />
      <path d="M8 11V8a4 4 0 0 1 8 0v3" />
    </svg>
  ),
  Doc: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M7 3h7l4 4v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" />
      <path d="M14 3v4h4" />
      <path d="M9 13h6M9 17h6M9 9h2" />
    </svg>
  ),
  ArrowRight: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  ),
  Search: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.3-4.3" />
    </svg>
  ),
  Building: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M4 21V6l8-3 8 3v15" />
      <path d="M9 21v-5h6v5M9 10h.01M9 14h.01M15 10h.01M15 14h.01" />
    </svg>
  ),
  Users: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6" />
      <path d="M16.2 4.6a3.2 3.2 0 0 1 0 6.2M20 20c0-3-1.8-5.1-4.2-5.8" />
    </svg>
  ),
  Card: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <rect x="3" y="5" width="18" height="14" rx="2.2" />
      <path d="M3 10h18M7 15h4" />
    </svg>
  ),
  Chart: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M4 20V10M11 20V4M18 20v-7" />
      <path d="M2.5 20.5h19" />
    </svg>
  ),
  Alert: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M12 3 2 20h20L12 3z" />
      <path d="M12 10v4M12 17h.01" />
    </svg>
  ),
  Check: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M20 6 9 17l-5-5" />
    </svg>
  ),
  ChevronDown: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="m6 9 6 6 6-6" />
    </svg>
  ),
  Pix: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M8 4.5 4.5 8a2 2 0 0 0 0 2.8L8 14.3M16 4.5 19.5 8a2 2 0 0 1 0 2.8L16 14.3M9.5 6l1.8-1.8a2 2 0 0 1 2.8 0L16 6M9.5 18l1.8 1.8a2 2 0 0 0 2.8 0L16 18" />
      <circle cx="12" cy="12" r="1.6" />
    </svg>
  ),
  Download: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M12 3v12m0 0 4.5-4.5M12 15 7.5 10.5" />
      <path d="M4 18v1.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V18" />
    </svg>
  ),
  Printer: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M6 9V4h12v5" />
      <rect x="4" y="9" width="16" height="8" rx="1.5" />
      <path d="M6 14h12v6H6z" />
    </svg>
  ),
  Share: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <circle cx="18" cy="5" r="2.4" />
      <circle cx="6" cy="12" r="2.4" />
      <circle cx="18" cy="19" r="2.4" />
      <path d="M8.1 10.8 15.9 6.2M8.1 13.2l7.8 4.6" />
    </svg>
  ),
  Wallet: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h11A2.5 2.5 0 0 1 19 7.5" />
      <rect x="3" y="7.5" width="18" height="12" rx="2" />
      <path d="M15.5 13.5h2M3 11h18" />
    </svg>
  ),
  Settings: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9c.2.6.7 1 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
    </svg>
  ),
  LayoutGrid: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.4" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.4" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.4" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.4" />
    </svg>
  ),
  History: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M3 12a9 9 0 1 0 3-6.7" />
      <path d="M3 4v4h4M12 8v4l3 2" />
    </svg>
  ),
  LifeBuoy: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.4" />
      <path d="m7.5 7.5 2.6 2.6M16.5 7.5l-2.6 2.6M16.5 16.5l-2.6-2.6M7.5 16.5l2.6-2.6" />
    </svg>
  ),
  Ticket: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4V8z" />
      <path d="M10 6v12" strokeDasharray="2.5 3" />
    </svg>
  ),
  Logs: (p: IconProps) => (
    <svg viewBox="0 0 24 24" {...base} {...p}>
      <path d="M4 4h16v16H4z" opacity="0" />
      <path d="M5 6h14M5 12h14M5 18h9" />
    </svg>
  ),
}
