'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'

export function Tooltip({
  label,
  children,
  side = 'top',
}: {
  label: React.ReactNode
  children: React.ReactNode
  side?: 'top' | 'bottom'
}) {
  const [open, setOpen] = React.useState(false)
  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      <span
        role="tooltip"
        className={cn(
          'pointer-events-none absolute left-1/2 z-50 w-max max-w-[220px] -translate-x-1/2 rounded-md bg-navy-950 px-2.5 py-1.5 text-center text-[12px] font-medium text-white shadow-lifted transition-all duration-150',
          side === 'top' ? 'bottom-[calc(100%+8px)]' : 'top-[calc(100%+8px)]',
          open ? 'translate-y-0 opacity-100' : cn(side === 'top' ? 'translate-y-1' : '-translate-y-1', 'opacity-0'),
        )}
      >
        {label}
      </span>
    </span>
  )
}
