import type { ReactNode } from 'react'
import { Card } from './card'
import { cn } from '@/lib/utils'

export function StatCard({
  label,
  value,
  hint,
  trend,
  icon,
}: {
  label: string
  value: string
  hint?: string
  trend?: { value: string; positive: boolean }
  icon?: ReactNode
}) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <p className="text-[13px] font-medium text-navy-400">{label}</p>
        {icon && <div className="text-electric-500">{icon}</div>}
      </div>
      <p className="mt-2 text-[26px] font-bold tracking-tight text-navy-950">{value}</p>
      <div className="mt-1.5 flex items-center gap-1.5">
        {trend && (
          <span
            className={cn(
              'text-[12.5px] font-semibold',
              trend.positive ? 'text-positive-600' : 'text-critical-600',
            )}
          >
            {trend.positive ? '↑' : '↓'} {trend.value}
          </span>
        )}
        {hint && <span className="text-[12.5px] text-navy-300">{hint}</span>}
      </div>
    </Card>
  )
}
