'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'
import { detectPlateFormat, maskPlateInput, sanitizePlate } from '@/lib/plate'

export function PlateInput({
  value,
  onChange,
  size = 'md',
  autoFocus,
  placeholder = 'ABC1D23',
}: {
  value: string
  onChange: (value: string) => void
  size?: 'md' | 'lg'
  autoFocus?: boolean
  placeholder?: string
}) {
  const format = detectPlateFormat(value)
  const isTyping = sanitizePlate(value).length > 0

  return (
    <div className="flex flex-col gap-1.5">
      <div className="relative">
        <input
          autoFocus={autoFocus}
          value={maskPlateInput(value)}
          onChange={(e) => onChange(sanitizePlate(e.target.value))}
          placeholder={placeholder}
          maxLength={8}
          aria-label="Placa do veículo"
          className={cn(
            'focus-ring w-full rounded-xl border-2 bg-white text-center font-mono-plate font-bold uppercase text-navy-950 placeholder:text-navy-200',
            'transition-colors duration-150',
            format ? 'border-positive-500' : 'border-navy-950/90 focus-visible:border-electric-500',
            size === 'lg' ? 'h-16 text-[28px] sm:text-[32px]' : 'h-12 text-[18px]',
          )}
        />
        {isTyping && (
          <span
            className={cn(
              'absolute right-4 top-1/2 -translate-y-1/2 text-[11px] font-semibold uppercase tracking-wide',
              format ? 'text-positive-600' : 'text-navy-300',
            )}
          >
            {format ? (format === 'mercosul' ? 'Mercosul' : 'Padrão antigo') : ''}
          </span>
        )}
      </div>
    </div>
  )
}
