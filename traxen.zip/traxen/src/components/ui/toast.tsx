'use client'

import * as React from 'react'
import { cn } from '@/lib/utils'

type ToastTone = 'default' | 'success' | 'error'
interface ToastItem {
  id: number
  title: string
  description?: string
  tone: ToastTone
}

interface ToastContextValue {
  push: (toast: Omit<ToastItem, 'id' | 'tone'> & { tone?: ToastTone }) => void
}

const ToastContext = React.createContext<ToastContextValue | null>(null)

export function useToast() {
  const ctx = React.useContext(ToastContext)
  if (!ctx) throw new Error('useToast deve ser usado dentro de <ToastProvider>')
  return ctx
}

const toneStyles: Record<ToastTone, string> = {
  default: 'border-surface-border',
  success: 'border-positive-100',
  error: 'border-critical-100',
}

const toneDot: Record<ToastTone, string> = {
  default: 'bg-electric-500',
  success: 'bg-positive-500',
  error: 'bg-critical-500',
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<ToastItem[]>([])

  const push = React.useCallback((toast: Omit<ToastItem, 'id' | 'tone'> & { tone?: ToastTone }) => {
    const id = Date.now() + Math.random()
    setToasts((prev) => [...prev, { tone: 'default', ...toast, id }])
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id))
    }, 4200)
  }, [])

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-5 right-5 z-[100] flex w-full max-w-sm flex-col gap-2.5">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              'animate-fade-up pointer-events-auto flex items-start gap-3 rounded-xl border bg-white/95 p-4 shadow-lifted backdrop-blur',
              toneStyles[t.tone],
            )}
          >
            <span className={cn('mt-1 h-2 w-2 shrink-0 rounded-full', toneDot[t.tone])} />
            <div>
              <p className="text-[13.5px] font-semibold text-navy-950">{t.title}</p>
              {t.description && <p className="mt-0.5 text-[13px] text-navy-400">{t.description}</p>}
            </div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}
