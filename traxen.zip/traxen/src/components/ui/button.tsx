import * as React from 'react'
import { cn } from '@/lib/utils'

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger'
type Size = 'sm' | 'md' | 'lg'

const variants: Record<Variant, string> = {
  primary:
    'bg-electric-500 text-white shadow-[0_1px_0_rgba(255,255,255,0.15)_inset,0_8px_20px_-8px_rgba(47,92,245,0.55)] hover:bg-electric-600 active:bg-electric-700',
  secondary:
    'bg-navy-950 text-white hover:bg-navy-900 active:bg-navy-800',
  outline:
    'bg-white text-navy-900 border border-surface-border hover:border-navy-300 hover:bg-navy-50/40',
  ghost: 'bg-transparent text-navy-700 hover:bg-navy-50',
  danger: 'bg-critical-500 text-white hover:bg-critical-600',
}

const sizes: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-[13px] gap-1.5 rounded-[10px]',
  md: 'h-11 px-5 text-[14px] gap-2 rounded-xl',
  lg: 'h-13 px-7 text-[15px] gap-2 rounded-xl',
}

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  iconLeft?: React.ReactNode
  iconRight?: React.ReactNode
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', loading, disabled, iconLeft, iconRight, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          'focus-ring inline-flex select-none items-center justify-center whitespace-nowrap font-medium transition-all duration-150 ease-out disabled:cursor-not-allowed disabled:opacity-50',
          'active:scale-[0.98]',
          variants[variant],
          sizes[size],
          className,
        )}
        {...props}
      >
        {loading ? (
          <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3.5" />
            <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v3.2A4.8 4.8 0 007.2 12H4z" />
          </svg>
        ) : (
          iconLeft
        )}
        {children}
        {!loading && iconRight}
      </button>
    )
  },
)
Button.displayName = 'Button'
