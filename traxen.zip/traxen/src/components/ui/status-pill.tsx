import { cn } from '@/lib/utils'
import type { FindingStatus } from '@/types/report'

const config: Record<FindingStatus, { icon: string; classes: string; text: string }> = {
  ok: { icon: '✓', classes: 'bg-positive-50 text-positive-600', text: 'Nada encontrado' },
  attention: { icon: '!', classes: 'bg-attention-50 text-attention-600', text: 'Atenção' },
  restriction: { icon: '×', classes: 'bg-critical-50 text-critical-600', text: 'Restrição encontrada' },
  unavailable: { icon: '—', classes: 'bg-navy-50 text-navy-400', text: 'Indisponível' },
}

export function StatusIcon({ status, className }: { status: FindingStatus; className?: string }) {
  const c = config[status]
  return (
    <span
      className={cn(
        'inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[13px] font-bold',
        c.classes,
        className,
      )}
      aria-hidden
    >
      {c.icon}
    </span>
  )
}

export function statusText(status: FindingStatus): string {
  return config[status].text
}

export function StatusRow({
  label,
  status,
  detail,
}: {
  label: string
  status: FindingStatus
  detail?: string
}) {
  return (
    <div className="flex items-start gap-3 py-3.5">
      <StatusIcon status={status} />
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-semibold text-navy-950">{label}</p>
        <p className="mt-0.5 text-[13px] text-navy-400">{detail || statusText(status)}</p>
      </div>
    </div>
  )
}
