import * as React from 'react'
import { cn } from '@/lib/utils'

type Tone = 'navy' | 'electric' | 'positive' | 'attention' | 'critical' | 'neutral'

const tones: Record<Tone, string> = {
  navy: 'bg-navy-950 text-white',
  electric: 'bg-electric-50 text-electric-600 ring-1 ring-inset ring-electric-200',
  positive: 'bg-positive-50 text-positive-600 ring-1 ring-inset ring-positive-100',
  attention: 'bg-attention-50 text-attention-600 ring-1 ring-inset ring-attention-100',
  critical: 'bg-critical-50 text-critical-600 ring-1 ring-inset ring-critical-100',
  neutral: 'bg-navy-50 text-navy-500 ring-1 ring-inset ring-surface-border',
}

export function Badge({
  tone = 'neutral',
  className,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide',
        tones[tone],
        className,
      )}
      {...props}
    />
  )
}
