import { cn } from '@/lib/utils'

export function Logomark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn('h-8 w-8', className)} aria-hidden>
      <rect width="32" height="32" rx="9" fill="#05070D" />
      <path
        d="M9 17.5 13.2 21.7 23 10.3"
        fill="none"
        stroke="#5A7DFF"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M9 12.2h6.5" stroke="#2F5CF5" strokeWidth="2.2" strokeLinecap="round" opacity="0.55" />
    </svg>
  )
}

export function Logo({ className, dark }: { className?: string; dark?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <Logomark />
      <span
        className={cn(
          'text-[18px] font-bold tracking-[-0.01em]',
          dark ? 'text-white' : 'text-navy-950',
        )}
      >
        Traxen
      </span>
    </span>
  )
}
