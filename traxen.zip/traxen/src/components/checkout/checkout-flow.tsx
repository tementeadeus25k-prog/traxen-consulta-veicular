'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Icon } from '@/components/ui/icons'
import { cn, formatCurrencyBRL } from '@/lib/utils'
import type { PaymentMethod } from '@/lib/payments/types'

type Step = 'method' | 'waiting' | 'approved' | 'generating' | 'error'

interface QueryInfo {
  id: string
  plate: string
  productName: string
  priceCents: number
  status: string
  chargeId?: string
}

export function CheckoutFlow({ query }: { query: QueryInfo }) {
  const router = useRouter()
  const [method, setMethod] = React.useState<PaymentMethod>('pix')
  const [step, setStep] = React.useState<Step>('method')
  const [chargeId, setChargeId] = React.useState<string | undefined>(query.chargeId)
  const [pixCopyPaste, setPixCopyPaste] = React.useState<string | undefined>()
  const [errorMsg, setErrorMsg] = React.useState('')

  async function handlePay() {
    setStep('waiting')
    setErrorMsg('')
    try {
      const res = await fetch('/api/payments/create-charge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ queryId: query.id, method }),
      })
      const data = await res.json()
      if (!res.ok) {
        setErrorMsg(data.error || 'Não foi possível iniciar o pagamento.')
        setStep('error')
        return
      }
      setChargeId(data.chargeId)
      setPixCopyPaste(data.pixCopyPaste)
    } catch {
      setErrorMsg('Não foi possível iniciar o pagamento agora.')
      setStep('error')
    }
  }

  // Polling do status do pagamento
  React.useEffect(() => {
    if (step !== 'waiting' || !chargeId) return
    const interval = setInterval(async () => {
      const res = await fetch(`/api/payments/status?chargeId=${chargeId}`)
      const data = await res.json()
      if (data.status === 'approved') {
        clearInterval(interval)
        setStep('approved')
      } else if (data.status === 'refused') {
        clearInterval(interval)
        setErrorMsg('Pagamento recusado. Tente novamente com outro método.')
        setStep('error')
      }
    }, 1200)
    return () => clearInterval(interval)
  }, [step, chargeId])

  // Após aprovação, gera o relatório e redireciona
  React.useEffect(() => {
    if (step !== 'approved') return
    const t = setTimeout(async () => {
      setStep('generating')
      const res = await fetch('/api/reports/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ queryId: query.id }),
      })
      const data = await res.json()
      if (!res.ok) {
        setErrorMsg(data.error || 'Não foi possível gerar o relatório.')
        setStep('error')
        return
      }
      setTimeout(() => router.push(`/painel/consultas/${data.queryId}`), 900)
    }, 1100)
    return () => clearTimeout(t)
  }, [step, query.id, router])

  return (
    <div className="container max-w-lg">
      <Card className="overflow-hidden">
        <div className="border-b border-surface-border bg-navy-950 px-7 py-5 text-white">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-electric-300">Resumo do pedido</p>
          <p className="mt-1 text-[16px] font-bold">{query.productName}</p>
          <p className="font-mono-plate text-[12.5px] text-navy-300">Placa {query.plate}</p>
        </div>

        <div className="p-7">
          {step === 'method' && (
            <>
              <div className="flex items-center justify-between border-b border-surface-border pb-4">
                <span className="text-[13.5px] text-navy-500">Valor</span>
                <span className="text-[22px] font-extrabold text-navy-950">{formatCurrencyBRL(query.priceCents)}</span>
              </div>

              <p className="mb-3 mt-5 text-[13px] font-semibold text-navy-700">Forma de pagamento</p>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setMethod('pix')}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border p-4 transition-colors',
                    method === 'pix' ? 'border-electric-500 bg-electric-50/60' : 'border-surface-border hover:border-navy-300',
                  )}
                >
                  <Icon.Pix className="h-5 w-5 text-electric-600" />
                  <span className="text-[13px] font-semibold text-navy-800">PIX</span>
                </button>
                <button
                  onClick={() => setMethod('card')}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-xl border p-4 transition-colors',
                    method === 'card' ? 'border-electric-500 bg-electric-50/60' : 'border-surface-border hover:border-navy-300',
                  )}
                >
                  <Icon.Card className="h-5 w-5 text-electric-600" />
                  <span className="text-[13px] font-semibold text-navy-800">Cartão</span>
                </button>
              </div>

              {method === 'card' && (
                <div className="mt-5 flex flex-col gap-3">
                  <Input label="Número do cartão" placeholder="0000 0000 0000 0000" defaultValue="4242 4242 4242 4242" />
                  <div className="grid grid-cols-2 gap-3">
                    <Input label="Validade" placeholder="MM/AA" defaultValue="12/29" />
                    <Input label="CVV" placeholder="123" defaultValue="123" />
                  </div>
                </div>
              )}

              <p className="mt-5 flex items-center gap-1.5 text-[12px] text-navy-300">
                <Icon.Lock className="h-3.5 w-3.5" /> Ambiente seguro · dados de pagamento protegidos
              </p>

              <Button size="lg" className="mt-6 w-full" onClick={handlePay}>
                Pagar {formatCurrencyBRL(query.priceCents)}
              </Button>
            </>
          )}

          {step === 'waiting' && method === 'pix' && (
            <div className="flex flex-col items-center gap-4 py-4 text-center">
              <div className="flex h-40 w-40 items-center justify-center rounded-xl border border-surface-border bg-surface-muted">
                <PixQrPlaceholder />
              </div>
              {pixCopyPaste && (
                <div className="w-full rounded-lg bg-navy-50 px-3 py-2.5 text-left">
                  <p className="truncate font-mono text-[11px] text-navy-500">{pixCopyPaste}</p>
                </div>
              )}
              <p className="text-[13.5px] font-semibold text-navy-800">Aguardando confirmação do PIX…</p>
              <p className="text-[12.5px] text-navy-400">Assim que recebermos a confirmação do banco, o relatório será liberado automaticamente.</p>
              <Spinner />
            </div>
          )}

          {step === 'waiting' && method === 'card' && (
            <div className="flex flex-col items-center gap-4 py-10 text-center">
              <Spinner />
              <p className="text-[13.5px] font-semibold text-navy-800">Processando pagamento…</p>
              <p className="text-[12.5px] text-navy-400">Isso leva só alguns instantes.</p>
            </div>
          )}

          {step === 'approved' && (
            <div className="animate-fade-up flex flex-col items-center gap-3 py-10 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-positive-50 text-positive-600">
                <Icon.Check className="h-7 w-7" />
              </div>
              <p className="text-[16px] font-bold text-navy-950">Pagamento aprovado</p>
              <p className="text-[13px] text-navy-400">Preparando o seu relatório…</p>
            </div>
          )}

          {step === 'generating' && (
            <div className="flex flex-col items-center gap-4 py-10 text-center">
              <Spinner />
              <p className="text-[14px] font-semibold text-navy-800">Estamos preparando sua consulta…</p>
              <p className="text-[12.5px] text-navy-400">Consultando as bases disponíveis para o veículo.</p>
            </div>
          )}

          {step === 'error' && (
            <div className="flex flex-col items-center gap-3 py-8 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-critical-50 text-critical-600">
                <Icon.Alert className="h-6 w-6" />
              </div>
              <p className="text-[14px] font-semibold text-navy-950">Não foi possível concluir</p>
              <p className="max-w-xs text-[13px] text-navy-400">{errorMsg}</p>
              <Button variant="outline" className="mt-2" onClick={() => setStep('method')}>
                Tentar novamente
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  )
}

function Spinner() {
  return (
    <svg className="h-8 w-8 animate-spin text-electric-500" viewBox="0 0 24 24" fill="none">
      <circle className="opacity-20" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
      <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v3.2A4.8 4.8 0 007.2 12H4z" />
    </svg>
  )
}

function PixQrPlaceholder() {
  return (
    <svg viewBox="0 0 100 100" className="h-28 w-28 text-navy-950">
      {Array.from({ length: 8 }).map((_, row) =>
        Array.from({ length: 8 }).map((_, col) => {
          const on = (row * 8 + col + row) % 3 === 0
          return on ? <rect key={`${row}-${col}`} x={row * 12} y={col * 12} width="10" height="10" fill="currentColor" /> : null
        }),
      )}
    </svg>
  )
}
