'use client'

import * as React from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { Card, CardContent } from '@/components/ui/card'

export function LoginForm() {
  const router = useRouter()
  const params = useSearchParams()
  const { push } = useToast()
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState('')
  const [form, setForm] = React.useState({ email: 'demo@traxen.com.br', password: '' })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Não foi possível entrar.')
        setLoading(false)
        return
      }
      push({ title: 'Bem-vindo(a) de volta', tone: 'success' })
      router.push(data.role === 'admin' ? '/admin' : params.get('next') || '/painel')
      router.refresh()
    } catch {
      setError('Não foi possível entrar agora. Tente novamente.')
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-[400px]">
      <CardContent className="p-8">
        <h1 className="text-[22px] font-bold tracking-tight text-navy-950">Entrar na sua conta</h1>
        <p className="mt-1 text-[13.5px] text-navy-400">Acesse seu painel de consultas.</p>

        <form onSubmit={handleSubmit} className="mt-7 flex flex-col gap-4">
          <Input
            label="E-mail"
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            placeholder="voce@email.com"
          />
          <Input
            label="Senha"
            type="password"
            required
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            placeholder="••••••••"
            error={error || undefined}
          />
          <div className="-mt-1 flex justify-end">
            <Link href="#" className="text-[12.5px] font-medium text-electric-600 hover:text-electric-700">
              Esqueci minha senha
            </Link>
          </div>
          <Button type="submit" loading={loading} className="w-full">
            Entrar
          </Button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-surface-border" />
          <span className="text-[11.5px] font-medium uppercase tracking-wide text-navy-300">ou</span>
          <div className="h-px flex-1 bg-surface-border" />
        </div>

        <Button
          variant="outline"
          className="w-full"
          type="button"
          onClick={() => push({ title: 'Login com Google', description: 'Integração disponível em breve neste ambiente de demonstração.' })}
          iconLeft={<GoogleMark />}
        >
          Continuar com Google
        </Button>

        <p className="mt-6 rounded-lg bg-navy-50 px-3.5 py-2.5 text-center text-[12px] text-navy-400">
          Conta de demonstração: <strong className="text-navy-600">demo@traxen.com.br</strong> · senha{' '}
          <strong className="text-navy-600">demo1234</strong>
        </p>

        <p className="mt-6 text-center text-[13.5px] text-navy-400">
          Não possui conta?{' '}
          <Link href="/cadastro" className="font-semibold text-electric-600 hover:text-electric-700">
            Criar conta
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}

function GoogleMark() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4">
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.24 1.4-1.7 4.1-5.5 4.1-3.3 0-6-2.7-6-6.2s2.7-6.2 6-6.2c1.9 0 3.2.8 3.9 1.5l2.7-2.6C16.9 3.1 14.7 2 12 2 6.9 2 2.7 6.2 2.7 11.3S6.9 20.6 12 20.6c6.9 0 9.3-4.8 9.3-7.3 0-.5 0-.9-.1-1.3H12z" />
    </svg>
  )
}
