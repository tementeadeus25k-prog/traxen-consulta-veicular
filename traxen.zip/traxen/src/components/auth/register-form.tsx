'use client'

import * as React from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/components/ui/toast'
import { maskPhone } from '@/lib/utils'

export function RegisterForm() {
  const router = useRouter()
  const params = useSearchParams()
  const { push } = useToast()
  const [loading, setLoading] = React.useState(false)
  const [error, setError] = React.useState('')
  const [accepted, setAccepted] = React.useState(false)
  const [form, setForm] = React.useState({ name: '', email: '', phone: '', password: '', confirmPassword: '' })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!accepted) {
      setError('É necessário aceitar os Termos de Uso e a Política de Privacidade.')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, acceptedTerms: accepted }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Não foi possível criar sua conta.')
        setLoading(false)
        return
      }
      push({ title: 'Conta criada com sucesso', tone: 'success' })
      const next = params.get('next') || '/painel'
      const plate = params.get('plate')
      router.push(plate ? `${next}?placa=${plate}` : next)
      router.refresh()
    } catch {
      setError('Não foi possível criar sua conta agora.')
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-[420px]">
      <CardContent className="p-8">
        <h1 className="text-[22px] font-bold tracking-tight text-navy-950">Criar sua conta</h1>
        <p className="mt-1 text-[13.5px] text-navy-400">Leva menos de um minuto.</p>

        <form onSubmit={handleSubmit} className="mt-7 flex flex-col gap-4">
          <Input label="Nome" required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Seu nome completo" />
          <Input label="E-mail" type="email" required value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="voce@email.com" />
          <Input
            label="Telefone"
            required
            value={form.phone}
            onChange={(e) => setForm((f) => ({ ...f, phone: maskPhone(e.target.value) }))}
            placeholder="(00) 00000-0000"
          />
          <Input label="Senha" type="password" required value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder="Mínimo de 8 caracteres" hint="Use pelo menos 8 caracteres." />
          <Input
            label="Confirmar senha"
            type="password"
            required
            value={form.confirmPassword}
            onChange={(e) => setForm((f) => ({ ...f, confirmPassword: e.target.value }))}
            placeholder="••••••••"
            error={error || undefined}
          />

          <label className="flex items-start gap-2.5 text-[12.5px] text-navy-500">
            <input
              type="checkbox"
              checked={accepted}
              onChange={(e) => setAccepted(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-surface-border text-electric-500 focus-ring"
            />
            Li e concordo com os{' '}
            <Link href="/termos" className="font-medium text-electric-600 hover:underline">Termos de Uso</Link> e a{' '}
            <Link href="/privacidade" className="font-medium text-electric-600 hover:underline">Política de Privacidade</Link>.
          </label>

          <Button type="submit" loading={loading} className="w-full">
            Criar conta
          </Button>
        </form>

        <p className="mt-6 text-center text-[13.5px] text-navy-400">
          Já possui conta?{' '}
          <Link href="/entrar" className="font-semibold text-electric-600 hover:text-electric-700">
            Entrar
          </Link>
        </p>
      </CardContent>
    </Card>
  )
}
