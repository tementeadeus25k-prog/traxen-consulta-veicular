'use client'

import * as React from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { PageHeader } from '@/components/dashboard/page-header'
import { PlateInput } from '@/components/ui/plate-input'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Icon } from '@/components/ui/icons'
import { useToast } from '@/components/ui/toast'
import { isValidPlate, sanitizePlate } from '@/lib/plate'
import { cn, formatCurrencyBRL } from '@/lib/utils'
import type { Product } from '@/lib/products'

export function NovaConsultaFlow() {
  const router = useRouter()
  const params = useSearchParams()
  const { push } = useToast()

  const [plate, setPlate] = React.useState(sanitizePlate(params.get('placa') || ''))
  const [validated, setValidated] = React.useState(false)
  const [selected, setSelected] = React.useState<string>(params.get('produto') || 'completa')
  const [loading, setLoading] = React.useState(false)
  const [products, setProducts] = React.useState<Product[]>([])

  React.useEffect(() => {
    fetch('/api/products')
      .then((r) => r.json())
      .then((data) => setProducts(data.products || []))
      .catch(() => {})
  }, [])

  function handleValidate(e: React.FormEvent) {
    e.preventDefault()
    setValidated(isValidPlate(plate))
  }

  async function handleContinue() {
    setLoading(true)
    try {
      const res = await fetch('/api/queries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plate, productSlug: selected }),
      })
      const data = await res.json()
      if (!res.ok) {
        push({ title: 'Não foi possível continuar', description: data.error, tone: 'error' })
        setLoading(false)
        return
      }
      router.push(`/checkout/${data.id}`)
    } catch {
      push({ title: 'Erro de conexão', description: 'Tente novamente em instantes.', tone: 'error' })
      setLoading(false)
    }
  }

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Consultar veículo" description="Informe a placa para iniciar sua consulta." />

      <Card className="p-7">
        <form onSubmit={handleValidate} className="flex flex-col items-center gap-4 sm:flex-row sm:items-end">
          <div className="w-full flex-1">
            <label className="mb-1.5 block text-[13px] font-medium text-navy-700">Digite a placa</label>
            <PlateInput
              value={plate}
              onChange={(v) => {
                setPlate(v)
                setValidated(false)
              }}
              size="lg"
              autoFocus
            />
          </div>
          <Button type="submit" size="lg" className="w-full sm:w-auto">
            Continuar
          </Button>
        </form>

        {validated && (
          <p className="mt-3 flex items-center gap-1.5 text-[13px] font-semibold text-positive-600">
            <Icon.Check className="h-4 w-4" /> Placa válida
          </p>
        )}
      </Card>

      {validated && (
        <div className="animate-fade-up mt-8">
          <h2 className="mb-4 text-[16px] font-semibold text-navy-950">Escolha sua consulta</h2>
          <div className="flex flex-col gap-3">
            {products.map((product) => (
              <button
                key={product.slug}
                onClick={() => setSelected(product.slug)}
                className={cn(
                  'flex items-center justify-between rounded-xl border p-5 text-left transition-all',
                  selected === product.slug
                    ? 'border-electric-500 bg-electric-50/50 shadow-glow'
                    : 'border-surface-border bg-white hover:border-navy-300',
                )}
              >
                <div className="flex items-center gap-4">
                  <span
                    className={cn(
                      'flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2',
                      selected === product.slug ? 'border-electric-500 bg-electric-500' : 'border-navy-200',
                    )}
                  >
                    {selected === product.slug && <span className="h-2 w-2 rounded-full bg-white" />}
                  </span>
                  <div>
                    <p className="flex items-center gap-2 text-[14.5px] font-semibold text-navy-950">
                      {product.name}
                      {product.badge && (
                        <span className="rounded-full bg-electric-500 px-2 py-0.5 text-[10px] font-semibold uppercase text-white">
                          {product.badge}
                        </span>
                      )}
                    </p>
                    <p className="text-[12.5px] text-navy-400">{product.tagline}</p>
                  </div>
                </div>
                <p className="shrink-0 text-[17px] font-bold text-navy-950">{formatCurrencyBRL(product.priceCents)}</p>
              </button>
            ))}
          </div>

          <Button size="lg" className="mt-6 w-full" loading={loading} onClick={handleContinue}>
            Continuar para pagamento
            <Icon.ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}
