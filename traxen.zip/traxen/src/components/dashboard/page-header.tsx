export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-7 flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 className="text-[22px] font-bold tracking-tight text-navy-950">{title}</h1>
        {description && <p className="mt-1 text-[13.5px] text-navy-400">{description}</p>}
      </div>
      {actions}
    </div>
  )
}
