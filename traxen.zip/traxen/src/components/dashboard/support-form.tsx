'use client'

import * as React from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'

export function SupportForm() {
  const { push } = useToast()
  const [loading, setLoading] = React.useState(false)
  const [sent, setSent] = React.useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    await new Promise((r) => setTimeout(r, 800))
    setLoading(false)
    setSent(true)
    push({ title: 'Chamado aberto', description: 'Nosso suporte responderá pelo e-mail cadastrado.', tone: 'success' })
  }

  if (sent) {
    return (
      <div className="rounded-lg border border-positive-100 bg-positive-50 p-6 text-center">
        <p className="text-[14.5px] font-semibold text-positive-600">Chamado enviado com sucesso</p>
        <p className="mt-1 text-[13px] text-navy-500">Protocolo #{Math.floor(Math.random() * 90000 + 10000)}</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <Input label="Assunto" placeholder="Ex.: Dúvida sobre uma consulta" required />
      <div className="flex flex-col gap-1.5">
        <label className="text-[13px] font-medium text-navy-700">Mensagem</label>
        <textarea
          required
          rows={4}
          placeholder="Descreva o que você precisa..."
          className="focus-ring rounded-xl border border-surface-border px-3.5 py-3 text-[14px] text-navy-950 placeholder:text-navy-300 hover:border-navy-300"
        />
      </div>
      <Button type="submit" loading={loading} className="w-full sm:w-auto">
        Abrir chamado
      </Button>
    </form>
  )
}
