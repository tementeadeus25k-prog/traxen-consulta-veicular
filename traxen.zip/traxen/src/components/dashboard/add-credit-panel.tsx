'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { cn, formatCurrencyBRL } from '@/lib/utils'

const AMOUNTS = [2000, 5000, 10000, 20000]

export function AddCreditPanel() {
  const router = useRouter()
  const { push } = useToast()
  const [open, setOpen] = React.useState(false)
  const [amount, setAmount] = React.useState(AMOUNTS[1])
  const [loading, setLoading] = React.useState(false)

  async function handleConfirm() {
    setLoading(true)
    const res = await fetch('/api/wallet/add-credit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amountCents: amount }),
    })
    setLoading(false)
    if (res.ok) {
      push({ title: 'Créditos adicionados', description: `${formatCurrencyBRL(amount)} disponíveis na sua carteira.`, tone: 'success' })
      setOpen(false)
      router.refresh()
    } else {
      push({ title: 'Não foi possível adicionar créditos', tone: 'error' })
    }
  }

  if (!open) {
    return <Button onClick={() => setOpen(true)}>Adicionar créditos</Button>
  }

  return (
    <Card className="w-full max-w-sm p-6">
      <p className="text-[14px] font-semibold text-navy-950">Adicionar créditos via PIX</p>
      <div className="mt-4 grid grid-cols-2 gap-2.5">
        {AMOUNTS.map((a) => (
          <button
            key={a}
            onClick={() => setAmount(a)}
            className={cn(
              'rounded-lg border px-3 py-2.5 text-[13.5px] font-semibold transition-colors',
              amount === a ? 'border-electric-500 bg-electric-50 text-electric-700' : 'border-surface-border text-navy-600 hover:border-navy-300',
            )}
          >
            {formatCurrencyBRL(a)}
          </button>
        ))}
      </div>
      <div className="mt-5 flex gap-2.5">
        <Button variant="outline" className="flex-1" onClick={() => setOpen(false)}>
          Cancelar
        </Button>
        <Button className="flex-1" loading={loading} onClick={handleConfirm}>
          Confirmar
        </Button>
      </div>
    </Card>
  )
}
