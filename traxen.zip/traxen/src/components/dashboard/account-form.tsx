'use client'

import * as React from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/components/ui/toast'
import { maskPhone } from '@/lib/utils'

export function AccountForm({ initial }: { initial: { name: string; email: string; phone: string } }) {
  const { push } = useToast()
  const [form, setForm] = React.useState(initial)
  const [loading, setLoading] = React.useState(false)
  const [confirmingDelete, setConfirmingDelete] = React.useState(false)
  const [deleteRequested, setDeleteRequested] = React.useState(false)

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    const res = await fetch('/api/account', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name, phone: form.phone }),
    })
    setLoading(false)
    if (res.ok) {
      push({ title: 'Dados atualizados', tone: 'success' })
    } else {
      push({ title: 'Não foi possível salvar', tone: 'error' })
    }
  }

  async function handleDeleteRequest() {
    const res = await fetch('/api/account/delete-request', { method: 'POST' })
    if (res.ok) {
      setDeleteRequested(true)
      push({ title: 'Solicitação registrada', description: 'Vamos processar a exclusão da sua conta conforme a LGPD.', tone: 'success' })
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardContent className="p-7">
          <h2 className="text-[15px] font-semibold text-navy-950">Dados pessoais</h2>
          <form onSubmit={handleSave} className="mt-5 grid gap-4 sm:grid-cols-2">
            <Input label="Nome" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            <Input label="E-mail" value={form.email} disabled hint="Para alterar o e-mail, contate o suporte." />
            <Input
              label="Telefone"
              value={form.phone}
              onChange={(e) => setForm((f) => ({ ...f, phone: maskPhone(e.target.value) }))}
            />
            <div className="flex items-end sm:col-span-2">
              <Button type="submit" loading={loading}>
                Salvar alterações
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="border-critical-100">
        <CardContent className="p-7">
          <h2 className="text-[15px] font-semibold text-critical-600">Excluir conta</h2>
          <p className="mt-1.5 max-w-lg text-[13px] text-navy-400">
            Ao solicitar a exclusão, seus dados pessoais serão removidos das nossas bases conforme a LGPD, exceto o
            que precisarmos reter por obrigação legal. Esta ação não pode ser desfeita.
          </p>
          {deleteRequested ? (
            <p className="mt-4 text-[13px] font-semibold text-positive-600">Solicitação registrada com sucesso.</p>
          ) : confirmingDelete ? (
            <div className="mt-4 flex gap-2.5">
              <Button variant="danger" onClick={handleDeleteRequest}>
                Confirmar exclusão
              </Button>
              <Button variant="outline" onClick={() => setConfirmingDelete(false)}>
                Cancelar
              </Button>
            </div>
          ) : (
            <Button variant="outline" className="mt-4 border-critical-200 text-critical-600 hover:bg-critical-50" onClick={() => setConfirmingDelete(true)}>
              Solicitar exclusão de conta
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
