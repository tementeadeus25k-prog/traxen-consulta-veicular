'use client'

import * as React from 'react'
import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { QueryStatusBadge } from './query-status-badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { cn, formatCurrencyBRL, formatDate } from '@/lib/utils'
import type { StoredQuery } from '@/lib/store'

type DateFilter = 'todos' | 'hoje' | '7dias' | '30dias'
const PAGE_SIZE = 6

export function ConsultasTable({ queries }: { queries: StoredQuery[] }) {
  const [search, setSearch] = React.useState('')
  const [dateFilter, setDateFilter] = React.useState<DateFilter>('todos')
  const [page, setPage] = React.useState(1)

  const filtered = React.useMemo(() => {
    const now = Date.now()
    const limitFor: Record<DateFilter, number> = { todos: Infinity, hoje: 86400000, '7dias': 7 * 86400000, '30dias': 30 * 86400000 }
    return queries.filter((q) => {
      const matchesSearch = q.plate.toLowerCase().includes(search.toLowerCase()) || q.vehicleLabel?.toLowerCase().includes(search.toLowerCase())
      const withinDate = now - new Date(q.createdAt).getTime() <= limitFor[dateFilter]
      return (search === '' || matchesSearch) && withinDate
    })
  }, [queries, search, dateFilter])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  React.useEffect(() => setPage(1), [search, dateFilter])

  return (
    <Card>
      <div className="flex flex-col gap-4 border-b border-surface-border p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-[260px]">
          <Icon.Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-navy-300" />
          <Input
            placeholder="Buscar por placa..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {(['todos', 'hoje', '7dias', '30dias'] as DateFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => setDateFilter(f)}
              className={cn(
                'rounded-full border px-3.5 py-1.5 text-[12.5px] font-medium transition-colors',
                dateFilter === f ? 'border-electric-500 bg-electric-50 text-electric-700' : 'border-surface-border text-navy-500 hover:border-navy-300',
              )}
            >
              {{ todos: 'Todos', hoje: 'Hoje', '7dias': '7 dias', '30dias': '30 dias' }[f]}
            </button>
          ))}
        </div>
      </div>

      {pageItems.length === 0 ? (
        <div className="px-6 py-16 text-center text-[13.5px] text-navy-400">Nenhuma consulta encontrada para este filtro.</div>
      ) : (
        <Table>
          <THead>
            <tr>
              <TH>Data</TH>
              <TH>Placa</TH>
              <TH>Veículo</TH>
              <TH>Consulta</TH>
              <TH>Valor</TH>
              <TH>Status</TH>
              <TH className="text-right">Ações</TH>
            </tr>
          </THead>
          <TBody>
            {pageItems.map((q) => (
              <TR key={q.id}>
                <TD>{formatDate(q.createdAt)}</TD>
                <TD className="font-mono-plate font-semibold">{q.plate}</TD>
                <TD>{q.vehicleLabel || '—'}</TD>
                <TD>{q.productName}</TD>
                <TD>{formatCurrencyBRL(q.priceCents)}</TD>
                <TD><QueryStatusBadge status={q.status} /></TD>
                <TD className="text-right">
                  <div className="flex justify-end gap-3">
                    <Link href={`/painel/consultas/${q.id}`} className="text-[13px] font-medium text-electric-600 hover:text-electric-700">
                      Ver
                    </Link>
                    {q.status === 'concluida' && (
                      <Link href={`/painel/consultas/${q.id}#dados-cadastrais`} className="text-[13px] font-medium text-navy-400 hover:text-navy-700">
                        PDF
                      </Link>
                    )}
                  </div>
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      )}

      <div className="flex items-center justify-between border-t border-surface-border px-5 py-4">
        <p className="text-[12.5px] text-navy-400">
          Página {page} de {totalPages} · {filtered.length} resultado{filtered.length === 1 ? '' : 's'}
        </p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Anterior
          </Button>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
            Próxima
          </Button>
        </div>
      </div>
    </Card>
  )
}
