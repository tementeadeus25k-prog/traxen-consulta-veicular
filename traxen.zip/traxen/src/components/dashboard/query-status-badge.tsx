import { Badge } from '@/components/ui/badge'
import type { QueryStatus } from '@/lib/store'

const CONFIG: Record<QueryStatus, { label: string; tone: 'positive' | 'attention' | 'critical' | 'neutral' }> = {
  aguardando_pagamento: { label: 'Aguardando pagamento', tone: 'attention' },
  processando: { label: 'Processando', tone: 'neutral' },
  concluida: { label: 'Concluída', tone: 'positive' },
  falhou: { label: 'Falhou', tone: 'critical' },
}

export function QueryStatusBadge({ status }: { status: QueryStatus }) {
  const c = CONFIG[status]
  return <Badge tone={c.tone}>{c.label}</Badge>
}
