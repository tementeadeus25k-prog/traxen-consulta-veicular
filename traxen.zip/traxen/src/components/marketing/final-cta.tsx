import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'

export function FinalCta() {
  return (
    <section className="bg-navy-950 py-20">
      <div className="container flex flex-col items-center gap-6 text-center">
        <h2 className="max-w-lg text-balance text-[28px] font-bold leading-tight tracking-tight text-white sm:text-[32px]">
          Negocie com mais segurança. Comece agora sua consulta.
        </h2>
        <p className="max-w-md text-[14.5px] text-navy-300">
          Sem mensalidade para consultas avulsas. Pague apenas pelo que consultar.
        </p>
        <Link href="/painel/nova-consulta">
          <Button size="lg">
            Consultar veículo
            <Icon.ArrowRight className="h-4 w-4" />
          </Button>
        </Link>
      </div>
    </section>
  )
}
