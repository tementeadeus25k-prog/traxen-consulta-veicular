import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { StatusIcon } from '@/components/ui/status-pill'
import { SectionHeading } from './section'

const ROWS = [
  { label: 'Dados cadastrais encontrados', status: 'ok' as const },
  { label: 'Sem registro de roubo/furto na fonte consultada', status: 'ok' as const },
  { label: 'Débitos — atenção necessária', status: 'attention' as const },
  { label: 'Informações verificadas', status: 'ok' as const },
]

export function SampleReportTeaser() {
  return (
    <section className="bg-white py-24">
      <div className="container grid items-center gap-14 lg:grid-cols-2">
        <div>
          <SectionHeading
            align="left"
            eyebrow="Exemplo de relatório"
            title="Um laudo claro, no formato de um documento financeiro."
            description="Cada consulta gera um relatório objetivo, com índice de atenção, status por item e disclaimers claros sobre a origem dos dados."
          />
          <Link href="/relatorio-exemplo" className="mt-7 inline-flex">
            <Button variant="outline">
              Ver relatório de exemplo
              <Icon.ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="relative">
          <div className="pointer-events-none absolute -inset-8 -z-10 rounded-[32px] bg-gradient-to-br from-electric-50 to-transparent" />
          <div className="rounded-2xl border border-surface-border bg-white shadow-lifted">
            <div className="flex items-center justify-between rounded-t-2xl bg-navy-950 px-6 py-4 text-white">
              <div>
                <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-electric-300">Relatório veicular</p>
                <p className="text-[12px] text-navy-200">Protocolo TRX-8F21K3M9</p>
              </div>
              <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10.5px] font-semibold">Completa</span>
            </div>
            <div className="px-6 py-5">
              <p className="text-[13px] font-semibold uppercase tracking-wide text-navy-300">Resumo</p>
              <div className="mt-3 divide-y divide-surface-border">
                {ROWS.map((row) => (
                  <div key={row.label} className="flex items-center gap-3 py-2.5">
                    <StatusIcon status={row.status} />
                    <span className="text-[13px] font-medium text-navy-700">{row.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
