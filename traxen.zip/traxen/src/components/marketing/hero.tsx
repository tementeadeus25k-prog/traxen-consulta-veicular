'use client'

import * as React from 'react'
import Link from 'next/link'
import { PlateInput } from '@/components/ui/plate-input'
import { Button } from '@/components/ui/button'
import { Icon } from '@/components/ui/icons'
import { isValidPlate } from '@/lib/plate'
import { cn } from '@/lib/utils'
import type { QuickLookupResult } from '@/types/report'

type Phase = 'idle' | 'loading' | 'result' | 'error'

export function Hero() {
  const [plate, setPlate] = React.useState('')
  const [phase, setPhase] = React.useState<Phase>('idle')
  const [result, setResult] = React.useState<QuickLookupResult | null>(null)
  const [error, setError] = React.useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!isValidPlate(plate)) {
      setError('Digite uma placa válida (padrão antigo ou Mercosul).')
      return
    }
    setError('')
    setPhase('loading')
    setResult(null)
    try {
      const res = await fetch('/api/vehicle/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plate }),
      })
      const data = await res.json()
      if (!res.ok) {
        setPhase('error')
        setError(data.error || 'Não foi possível concluir a consulta agora.')
        return
      }
      setResult(data)
      setPhase('result')
    } catch {
      setPhase('error')
      setError('Não foi possível concluir a consulta agora. Tente novamente.')
    }
  }

  return (
    <section className="relative overflow-hidden bg-navy-950">
      <div className="bg-dot-grid absolute inset-0 opacity-40" />
      <div className="bg-radial-glow pointer-events-none absolute inset-0" style={{ ['--y' as string]: '-10%' }} />
      <div className="pointer-events-none absolute -left-40 top-24 h-[420px] w-[420px] rounded-full bg-electric-500/20 blur-[120px]" />
      <div className="pointer-events-none absolute -right-24 top-64 h-[360px] w-[360px] rounded-full bg-electric-400/10 blur-[100px]" />

      <div className="container relative grid gap-16 pb-24 pt-16 sm:pt-24 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:pb-32">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-[12.5px] font-medium text-electric-200">
            <Icon.Shield className="h-3.5 w-3.5" />
            Plataforma de inteligência veicular
          </span>

          <h1 className="mt-6 max-w-xl text-balance text-[38px] font-bold leading-[1.1] tracking-tight text-white sm:text-[48px]">
            Conheça o histórico antes de comprar o veículo.
          </h1>

          <p className="mt-5 max-w-md text-balance text-[16px] leading-relaxed text-navy-200">
            Consulte informações importantes de um veículo em poucos minutos e tome decisões com muito mais
            segurança.
          </p>

          <form onSubmit={handleSubmit} className="mt-9 max-w-md rounded-2xl border border-white/10 bg-white/[0.06] p-3 shadow-lifted backdrop-blur">
            <div className="flex flex-col gap-2.5 sm:flex-row">
              <div className="flex-1">
                <PlateInput value={plate} onChange={setPlate} />
              </div>
              <Button type="submit" size="md" loading={phase === 'loading'} className="sm:w-auto">
                Consultar veículo
                <Icon.ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            {error && <p className="mt-2 px-1 text-[12.5px] font-medium text-red-300">{error}</p>}
          </form>

          <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[12.5px] font-medium text-navy-300">
            <span className="inline-flex items-center gap-1.5">
              <Icon.Bolt className="h-3.5 w-3.5 text-electric-400" /> Consulta rápida
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Icon.Lock className="h-3.5 w-3.5 text-electric-400" /> Pagamento seguro
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Icon.Doc className="h-3.5 w-3.5 text-electric-400" /> Relatório online
            </span>
          </div>

          {/* Consulta rápida — resultado */}
          <div className="mt-6 max-w-md">
            {phase === 'loading' && (
              <div className="animate-fade-in flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-5 py-4">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-electric-400" />
                  <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-electric-400" />
                </span>
                <p className="text-[13.5px] font-medium text-navy-100">Localizando veículo…</p>
              </div>
            )}

            {phase === 'result' && result && (
              <div className="animate-fade-up rounded-2xl border border-white/10 bg-white p-5 shadow-lifted">
                {result.found ? (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-positive-50 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-positive-600">
                        <Icon.Check className="h-3 w-3" /> Dados localizados
                      </span>
                      <span className="font-mono-plate text-[12px] font-semibold text-navy-400">{result.plate}</span>
                    </div>
                    <p className="mt-3 text-[17px] font-bold text-navy-950">{result.brand} {result.model}</p>
                    <p className="text-[13px] text-navy-400">Ano {result.modelYear}</p>
                    <Link href={`/cadastro?next=/painel/nova-consulta&plate=${result.plate}`} className="mt-4 block">
                      <Button className="w-full">
                        Ver histórico completo
                        <Icon.ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  </>
                ) : (
                  <>
                    <p className="text-[14px] font-semibold text-navy-950">Nenhum dado encontrado para esta placa</p>
                    <p className="mt-1 text-[13px] text-navy-400">Verifique se a placa foi digitada corretamente e tente novamente.</p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="relative hidden lg:block">
          <ReportPreviewMock />
        </div>
      </div>
    </section>
  )
}

function ReportPreviewMock() {
  const rows = [
    { label: 'Roubo/Furto', ok: true },
    { label: 'Restrições', ok: true },
    { label: 'Débitos', ok: false },
    { label: 'Gravame', ok: true },
  ]
  return (
    <div className="animate-fade-up relative mx-auto max-w-sm [animation-delay:150ms]">
      <div className="absolute -inset-6 rounded-[28px] bg-gradient-to-br from-electric-500/25 via-transparent to-transparent blur-2xl" />
      <div className="relative rounded-2xl border border-white/10 bg-white p-6 shadow-lifted">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-navy-300">Relatório veicular</p>
          <span className="rounded-full bg-navy-50 px-2 py-0.5 text-[10.5px] font-semibold text-navy-400">Protocolo TRX-8F21K</span>
        </div>
        <p className="mt-3 text-[19px] font-bold text-navy-950">VOLKSWAGEN T-CROSS</p>
        <p className="text-[12.5px] text-navy-400">2023/2024 · Placa ABC1D23</p>

        <div className="mt-5 flex items-center gap-5 rounded-xl bg-surface-muted p-4">
          <svg viewBox="0 0 180 100" className="h-14 w-24 shrink-0">
            <path d="M 20 95 A 70 70 0 0 1 160 95" fill="none" stroke="#E4E7F0" strokeWidth={14} strokeLinecap="round" />
            <path
              d="M 20 95 A 70 70 0 0 1 160 95"
              fill="none"
              stroke="#159A4E"
              strokeWidth={14}
              strokeLinecap="round"
              strokeDasharray={Math.PI * 70}
              strokeDashoffset={Math.PI * 70 * (1 - 0.18)}
            />
          </svg>
          <div>
            <p className="text-[22px] font-extrabold leading-none text-navy-950">18<span className="text-[13px] font-medium text-navy-300">/100</span></p>
            <p className="mt-1 text-[12px] font-semibold text-positive-600">Baixo nível de atenção</p>
          </div>
        </div>

        <div className="mt-5 divide-y divide-surface-border">
          {rows.map((row) => (
            <div key={row.label} className="flex items-center justify-between py-2.5">
              <span className="text-[13px] font-medium text-navy-700">{row.label}</span>
              <span
                className={cn(
                  'inline-flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold',
                  row.ok ? 'bg-positive-50 text-positive-600' : 'bg-attention-50 text-attention-600',
                )}
              >
                {row.ok ? '✓' : '!'}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-4 text-[10.5px] text-navy-300">Dados fictícios para fins de demonstração.</p>
      </div>
    </div>
  )
}
