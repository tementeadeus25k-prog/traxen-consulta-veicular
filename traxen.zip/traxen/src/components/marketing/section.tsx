import { cn } from '@/lib/utils'

export function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-electric-50 px-3 py-1 text-[11.5px] font-semibold uppercase tracking-wide text-electric-600 ring-1 ring-inset ring-electric-200">
      {children}
    </span>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'center',
  className,
}: {
  eyebrow?: string
  title: React.ReactNode
  description?: React.ReactNode
  align?: 'center' | 'left'
  className?: string
}) {
  return (
    <div className={cn('flex flex-col gap-4', align === 'center' ? 'items-center text-center' : 'items-start text-left', className)}>
      {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
      <h2 className="max-w-2xl text-balance text-[30px] font-bold leading-[1.15] tracking-tight text-navy-950 sm:text-[38px]">
        {title}
      </h2>
      {description && <p className="max-w-xl text-balance text-[15.5px] leading-relaxed text-navy-400">{description}</p>}
    </div>
  )
}
