import Link from 'next/link'
import { Logo } from '@/components/ui/logo'
import { Icon } from '@/components/ui/icons'

const COLUMNS = [
  {
    title: 'Produto',
    links: [
      { href: '/precos', label: 'Consultas e preços' },
      { href: '/como-funciona', label: 'Como funciona' },
      { href: '/painel/nova-consulta', label: 'Consultar veículo' },
      { href: '/duvidas', label: 'Dúvidas frequentes' },
    ],
  },
  {
    title: 'Empresas',
    links: [
      { href: '/para-empresas', label: 'Consulta em escala' },
      { href: '/para-empresas#api', label: 'API empresarial' },
      { href: '/para-empresas#comercial', label: 'Falar com comercial' },
    ],
  },
  {
    title: 'Empresa',
    links: [
      { href: '/termos', label: 'Termos de uso' },
      { href: '/privacidade', label: 'Política de privacidade' },
      { href: '/duvidas', label: 'Central de ajuda' },
    ],
  },
]

export function MarketingFooter() {
  return (
    <footer className="border-t border-surface-border bg-white">
      <div className="container py-14">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-[13.5px] leading-relaxed text-navy-400">
              Inteligência de dados para decisões mais seguras na compra e venda de veículos no Brasil.
            </p>
            <div className="mt-5 flex items-center gap-2 text-[12.5px] font-medium text-navy-400">
              <Icon.Lock className="h-4 w-4 text-electric-500" />
              Ambiente seguro · dados protegidos
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <p className="text-[12px] font-semibold uppercase tracking-wide text-navy-300">{col.title}</p>
              <ul className="mt-4 flex flex-col gap-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href} className="text-[13.5px] text-navy-500 transition-colors hover:text-navy-950">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-surface-border pt-6 text-[12.5px] text-navy-300 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Traxen Tecnologia Ltda. Todos os direitos reservados.</p>
          <p className="max-w-xl sm:text-right">
            A Traxen é uma plataforma de tecnologia e apresenta informações de acordo com as bases de dados
            disponíveis no momento da consulta. Não somos um órgão público nem substituímos a vistoria do veículo.
          </p>
        </div>
      </div>
    </footer>
  )
}
