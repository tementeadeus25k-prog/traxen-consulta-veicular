import Link from 'next/link'
import { Icon } from '@/components/ui/icons'
import { Button } from '@/components/ui/button'
import { cn, formatCurrencyBRL } from '@/lib/utils'
import { PRODUCTS } from '@/lib/products'
import { SectionHeading } from './section'

export function ProductCards() {
  return (
    <section className="container py-24">
      <SectionHeading
        eyebrow="Consultas"
        title="Escolha o nível de consulta ideal"
        description="Os campos exibidos dependem exclusivamente das informações disponíveis nas bases parceiras da Traxen no momento da consulta."
      />

      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {PRODUCTS.map((product) => {
          const highlighted = Boolean(product.badge)
          return (
            <div
              key={product.slug}
              className={cn(
                'relative flex flex-col rounded-lg border p-7 transition-shadow',
                highlighted
                  ? 'border-electric-500 bg-navy-950 text-white shadow-glow'
                  : 'border-surface-border bg-white shadow-card hover:shadow-lifted',
              )}
            >
              {product.badge && (
                <span className="absolute -top-3 left-7 rounded-full bg-electric-500 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-white shadow-soft">
                  {product.badge}
                </span>
              )}

              <p className={cn('text-[15px] font-semibold', highlighted ? 'text-white' : 'text-navy-950')}>
                {product.name}
              </p>
              <p className={cn('mt-1 text-[13.5px]', highlighted ? 'text-navy-200' : 'text-navy-400')}>
                {product.tagline}
              </p>

              <p className={cn('mt-6 text-[32px] font-extrabold tracking-tight', highlighted ? 'text-white' : 'text-navy-950')}>
                {formatCurrencyBRL(product.priceCents)}
              </p>

              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {product.bullets.map((bullet) => (
                  <li key={bullet} className="flex items-start gap-2.5 text-[13.5px]">
                    <Icon.Check className={cn('mt-0.5 h-4 w-4 shrink-0', highlighted ? 'text-electric-300' : 'text-electric-500')} />
                    <span className={highlighted ? 'text-navy-100' : 'text-navy-600'}>{bullet}</span>
                  </li>
                ))}
              </ul>

              <Link href={`/painel/nova-consulta?produto=${product.slug}`} className="mt-7">
                <Button variant={highlighted ? 'primary' : 'outline'} className="w-full">
                  Consultar agora
                </Button>
              </Link>
            </div>
          )
        })}
      </div>

      <p className="mx-auto mt-8 max-w-2xl text-center text-[12.5px] text-navy-300">
        Os valores acima são ilustrativos para este ambiente de demonstração. Nenhuma informação é prometida além do
        que a integração contratada efetivamente fornece.
      </p>
    </section>
  )
}
