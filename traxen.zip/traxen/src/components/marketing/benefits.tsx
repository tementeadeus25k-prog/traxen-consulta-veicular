import { Icon } from '@/components/ui/icons'
import { SectionHeading } from './section'

const BENEFITS = [
  { icon: Icon.History, title: 'Histórico do veículo', description: 'Conheça informações relevantes antes da negociação.' },
  { icon: Icon.Shield, title: 'Restrições', description: 'Identifique possíveis apontamentos disponíveis nas bases consultadas.' },
  { icon: Icon.Alert, title: 'Roubo e furto', description: 'Verifique ocorrências disponíveis para o veículo.' },
  { icon: Icon.Wallet, title: 'Débitos', description: 'Consulte informações financeiras disponíveis na fonte consultada.' },
  { icon: Icon.Lock, title: 'Gravame', description: 'Verifique possíveis vínculos financeiros associados ao veículo.' },
  { icon: Icon.Doc, title: 'Dados cadastrais', description: 'Confira características e informações gerais do veículo.' },
]

export function Benefits() {
  return (
    <section className="bg-surface-muted py-24">
      <div className="container">
        <SectionHeading title="Informação para negociar com mais segurança." />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {BENEFITS.map((item) => (
            <div
              key={item.title}
              className="group rounded-lg border border-surface-border bg-white p-6 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-electric-50 text-electric-600 transition-colors group-hover:bg-electric-500 group-hover:text-white">
                <item.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-[15px] font-semibold text-navy-950">{item.title}</h3>
              <p className="mt-1.5 text-[13.5px] leading-relaxed text-navy-400">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
