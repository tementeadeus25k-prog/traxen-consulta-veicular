'use client'

import * as React from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { maskPhone } from '@/lib/utils'

export function LeadForm() {
  const { push } = useToast()
  const [loading, setLoading] = React.useState(false)
  const [sent, setSent] = React.useState(false)
  const [phone, setPhone] = React.useState('')

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)
    await new Promise((r) => setTimeout(r, 900))
    setLoading(false)
    setSent(true)
    push({ title: 'Recebemos seu contato', description: 'Nosso time comercial vai retornar em breve.', tone: 'success' })
  }

  if (sent) {
    return (
      <div className="rounded-lg border border-positive-100 bg-positive-50 p-6 text-center">
        <p className="text-[15px] font-semibold text-positive-600">Solicitação enviada com sucesso</p>
        <p className="mt-1 text-[13.5px] text-navy-500">Nosso time comercial entrará em contato em até 1 dia útil.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4 sm:grid-cols-2">
      <Input label="Nome" name="name" placeholder="Seu nome" required />
      <Input label="E-mail corporativo" name="email" type="email" placeholder="voce@empresa.com.br" required />
      <Input label="Empresa" name="company" placeholder="Nome da empresa" required />
      <Input
        label="Telefone"
        name="phone"
        placeholder="(00) 00000-0000"
        value={phone}
        onChange={(e) => setPhone(maskPhone(e.target.value))}
        required
      />
      <div className="sm:col-span-2">
        <Button type="submit" loading={loading} className="w-full sm:w-auto">
          Falar com comercial
        </Button>
      </div>
    </form>
  )
}
