'use client'

import * as React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Logo } from '@/components/ui/logo'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/', label: 'Início' },
  { href: '/precos', label: 'Consultas' },
  { href: '/como-funciona', label: 'Como funciona' },
  { href: '/para-empresas', label: 'Para empresas' },
  { href: '/precos', label: 'Preços' },
  { href: '/duvidas', label: 'Dúvidas' },
]

export function MarketingHeader() {
  const [scrolled, setScrolled] = React.useState(false)
  const [open, setOpen] = React.useState(false)
  const pathname = usePathname()

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-300',
        scrolled
          ? 'border-b border-surface-border bg-white/80 shadow-xs backdrop-blur-md'
          : 'border-b border-transparent bg-transparent',
      )}
    >
      <div className="container flex h-[68px] items-center justify-between">
        <Link href="/" className="focus-ring rounded-md">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                'focus-ring rounded-lg px-3.5 py-2 text-[13.5px] font-medium text-navy-600 transition-colors hover:bg-navy-50 hover:text-navy-950',
                pathname === item.href && 'text-navy-950',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link href="/entrar" className="focus-ring rounded-lg px-3.5 py-2 text-[13.5px] font-medium text-navy-600 hover:text-navy-950">
            Entrar
          </Link>
          <Link href="/painel/nova-consulta">
            <Button size="sm">Consultar veículo</Button>
          </Link>
        </div>

        <button
          aria-label="Abrir menu"
          className="focus-ring flex h-10 w-10 items-center justify-center rounded-lg text-navy-800 lg:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </div>

      {open && (
        <div className="animate-fade-in border-t border-surface-border bg-white px-5 pb-6 pt-2 lg:hidden">
          <nav className="flex flex-col">
            {NAV.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={() => setOpen(false)}
                className="border-b border-surface-border py-3.5 text-[14px] font-medium text-navy-700"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mt-4 flex flex-col gap-2.5">
            <Link href="/entrar" onClick={() => setOpen(false)}>
              <Button variant="outline" className="w-full">Entrar</Button>
            </Link>
            <Link href="/painel/nova-consulta" onClick={() => setOpen(false)}>
              <Button className="w-full">Consultar veículo</Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
