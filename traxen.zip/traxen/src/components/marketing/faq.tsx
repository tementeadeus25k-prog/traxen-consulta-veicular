'use client'

import * as React from 'react'
import { Icon } from '@/components/ui/icons'
import { cn } from '@/lib/utils'

export interface FaqItem {
  q: string
  a: string
}

export function Faq({ items, title }: { items: FaqItem[]; title?: string }) {
  const [open, setOpen] = React.useState<number | null>(0)

  return (
    <div className="mx-auto max-w-2xl">
      {title && <h2 className="mb-6 text-[20px] font-bold text-navy-950">{title}</h2>}
      <div className="flex flex-col divide-y divide-surface-border rounded-lg border border-surface-border bg-white">
        {items.map((item, i) => {
          const isOpen = open === i
          return (
            <div key={item.q}>
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="focus-ring flex w-full items-center justify-between gap-4 px-5 py-4.5 text-left"
                aria-expanded={isOpen}
              >
                <span className="text-[14.5px] font-semibold text-navy-950">{item.q}</span>
                <Icon.ChevronDown
                  className={cn('h-4.5 w-4.5 shrink-0 text-navy-400 transition-transform duration-200', isOpen && 'rotate-180')}
                />
              </button>
              <div
                className={cn(
                  'grid transition-all duration-200 ease-out',
                  isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
                )}
              >
                <div className="overflow-hidden">
                  <p className="px-5 pb-4.5 text-[13.5px] leading-relaxed text-navy-400">{item.a}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
