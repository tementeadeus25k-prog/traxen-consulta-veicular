import { Icon } from '@/components/ui/icons'
import { SectionHeading } from './section'

const STEPS = [
  { n: '01', title: 'Digite a placa', description: 'Informe a placa do veículo — reconhecemos automaticamente o padrão antigo ou Mercosul.', icon: Icon.Search },
  { n: '02', title: 'Escolha sua consulta e pague', description: 'Selecione o nível de detalhe ideal e finalize o pagamento via PIX ou cartão em ambiente seguro.', icon: Icon.Card },
  { n: '03', title: 'Receba o relatório online', description: 'Acesse o relatório completo em minutos, com opção de download em PDF a qualquer momento.', icon: Icon.Doc },
]

export function HowItWorks() {
  return (
    <section className="bg-white py-24">
      <div className="container">
        <SectionHeading eyebrow="Como funciona" title="Do zero ao relatório em 3 passos" />

        <div className="relative mt-16 grid gap-10 md:grid-cols-3">
          <div className="pointer-events-none absolute left-0 right-0 top-9 hidden h-px bg-gradient-to-r from-transparent via-surface-border to-transparent md:block" />
          {STEPS.map((step) => (
            <div key={step.n} className="relative flex flex-col items-center text-center">
              <div className="relative flex h-[72px] w-[72px] items-center justify-center rounded-2xl border border-surface-border bg-white shadow-card">
                <step.icon className="h-7 w-7 text-electric-500" />
                <span className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-navy-950 text-[11px] font-bold text-white">
                  {step.n}
                </span>
              </div>
              <h3 className="mt-5 text-[16px] font-semibold text-navy-950">{step.title}</h3>
              <p className="mt-2 max-w-[260px] text-[13.5px] leading-relaxed text-navy-400">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
