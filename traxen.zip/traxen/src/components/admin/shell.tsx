'use client'

import * as React from 'react'
import Link from 'next/link'
import { Logo } from '@/components/ui/logo'
import { AdminSidebarContent } from './sidebar'

export function AdminShell({ name, email, children }: { name: string; email: string; children: React.ReactNode }) {
  const [open, setOpen] = React.useState(false)

  return (
    <div className="min-h-screen bg-surface-muted lg:flex">
      <aside className="hidden w-[260px] shrink-0 border-r border-surface-border bg-white lg:block">
        <div className="sticky top-0 h-screen">
          <AdminSidebarContent name={name} email={email} />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="sticky top-0 z-30 flex h-[60px] items-center justify-between border-b border-surface-border bg-white/90 px-5 backdrop-blur lg:hidden">
          <Link href="/admin">
            <Logo />
          </Link>
          <button
            aria-label="Abrir menu"
            className="focus-ring flex h-9 w-9 items-center justify-center rounded-lg text-navy-800"
            onClick={() => setOpen(true)}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 7h16M4 12h16M4 17h16" />
            </svg>
          </button>
        </div>

        <main className="flex-1 px-5 py-7 sm:px-8 lg:px-10 lg:py-9">{children}</main>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy-950/50" onClick={() => setOpen(false)} />
          <div className="animate-fade-up absolute inset-y-0 left-0 w-[280px] bg-white shadow-lifted">
            <button
              className="absolute right-3 top-4 flex h-8 w-8 items-center justify-center rounded-lg text-navy-400"
              onClick={() => setOpen(false)}
              aria-label="Fechar menu"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
            <AdminSidebarContent name={name} email={email} />
          </div>
        </div>
      )}
    </div>
  )
}
