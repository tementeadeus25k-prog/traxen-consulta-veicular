export function BreakdownList({ items }: { items: { label: string; value: number; percent: number }[] }) {
  return (
    <div className="flex flex-col gap-4">
      {items.map((item) => (
        <div key={item.label}>
          <div className="flex items-center justify-between text-[13px]">
            <span className="font-medium text-navy-700">{item.label}</span>
            <span className="font-semibold text-navy-950">{item.value}</span>
          </div>
          <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-navy-50">
            <div className="h-full rounded-full bg-electric-500" style={{ width: `${item.percent}%` }} />
          </div>
        </div>
      ))}
    </div>
  )
}
