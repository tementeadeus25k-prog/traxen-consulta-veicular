'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/components/ui/toast'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { formatDate } from '@/lib/utils'
import type { Coupon } from '@/lib/store'

export function CuponsManager({ coupons }: { coupons: Coupon[] }) {
  const router = useRouter()
  const { push } = useToast()
  const [creating, setCreating] = React.useState(false)
  const [loading, setLoading] = React.useState<string | null>(null)
  const [form, setForm] = React.useState({ code: '', discountType: 'percent' as 'percent' | 'fixed', value: '10', maxUses: '100' })

  async function toggle(id: string) {
    setLoading(id)
    const res = await fetch(`/api/admin/coupons/${id}`, { method: 'PATCH' })
    setLoading(null)
    if (res.ok) {
      push({ title: 'Cupom atualizado', tone: 'success' })
      router.refresh()
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault()
    setLoading('create')
    const res = await fetch('/api/admin/coupons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code: form.code,
        discountType: form.discountType,
        value: Number(form.value),
        maxUses: Number(form.maxUses),
        expiresAt: new Date(Date.now() + 30 * 86400000).toISOString(),
      }),
    })
    setLoading(null)
    const data = await res.json()
    if (res.ok) {
      push({ title: 'Cupom criado', tone: 'success' })
      setCreating(false)
      setForm({ code: '', discountType: 'percent', value: '10', maxUses: '100' })
      router.refresh()
    } else {
      push({ title: 'Não foi possível criar o cupom', description: data.error, tone: 'error' })
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-end">
        <Button onClick={() => setCreating((v) => !v)}>{creating ? 'Cancelar' : 'Novo cupom'}</Button>
      </div>

      {creating && (
        <Card className="p-6">
          <form onSubmit={handleCreate} className="grid gap-4 sm:grid-cols-4">
            <Input label="Código" required value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} placeholder="EX: BEMVINDO10" />
            <div className="flex flex-col gap-1.5">
              <label className="text-[13px] font-medium text-navy-700">Tipo</label>
              <select
                value={form.discountType}
                onChange={(e) => setForm((f) => ({ ...f, discountType: e.target.value as 'percent' | 'fixed' }))}
                className="focus-ring h-11 rounded-xl border border-surface-border bg-white px-3.5 text-[14px]"
              >
                <option value="percent">Percentual (%)</option>
                <option value="fixed">Valor fixo (centavos)</option>
              </select>
            </div>
            <Input label="Valor" type="number" required value={form.value} onChange={(e) => setForm((f) => ({ ...f, value: e.target.value }))} />
            <Input label="Máx. usos" type="number" required value={form.maxUses} onChange={(e) => setForm((f) => ({ ...f, maxUses: e.target.value }))} />
            <div className="sm:col-span-4">
              <Button type="submit" loading={loading === 'create'}>Criar cupom</Button>
            </div>
          </form>
        </Card>
      )}

      <Card>
        <Table>
          <THead>
            <tr>
              <TH>Código</TH>
              <TH>Desconto</TH>
              <TH className="text-right">Usos</TH>
              <TH>Validade</TH>
              <TH>Status</TH>
              <TH className="text-right">Ações</TH>
            </tr>
          </THead>
          <TBody>
            {coupons.map((c) => (
              <TR key={c.id}>
                <TD className="font-mono font-semibold">{c.code}</TD>
                <TD>{c.discountType === 'percent' ? `${c.value}%` : `R$ ${(c.value / 100).toFixed(2)}`}</TD>
                <TD className="text-right">{c.uses} / {c.maxUses}</TD>
                <TD>{formatDate(c.expiresAt)}</TD>
                <TD><Badge tone={c.status === 'ativo' ? 'positive' : 'neutral'}>{c.status === 'ativo' ? 'Ativo' : 'Inativo'}</Badge></TD>
                <TD className="text-right">
                  <Button variant="ghost" size="sm" loading={loading === c.id} onClick={() => toggle(c.id)}>
                    {c.status === 'ativo' ? 'Desativar' : 'Ativar'}
                  </Button>
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </Card>
    </div>
  )
}
