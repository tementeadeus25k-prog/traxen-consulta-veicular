'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/components/ui/toast'
import { formatCurrencyBRL } from '@/lib/utils'
import type { Product } from '@/lib/products'

export function ProdutosManager({ products }: { products: Product[] }) {
  const router = useRouter()
  const { push } = useToast()
  const [prices, setPrices] = React.useState<Record<string, string>>(
    Object.fromEntries(products.map((p) => [p.slug, (p.priceCents / 100).toFixed(2).replace('.', ',')])),
  )
  const [loading, setLoading] = React.useState<string | null>(null)

  async function savePrice(slug: string) {
    setLoading(`price-${slug}`)
    const priceCents = Math.round(parseFloat(prices[slug].replace(',', '.')) * 100)
    const res = await fetch(`/api/admin/products/${slug}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ priceCents }),
    })
    setLoading(null)
    if (res.ok) {
      push({ title: 'Preço atualizado', description: 'O novo valor já está disponível para os clientes.', tone: 'success' })
      router.refresh()
    } else {
      push({ title: 'Não foi possível atualizar', tone: 'error' })
    }
  }

  async function toggleActive(slug: string, active: boolean) {
    setLoading(`active-${slug}`)
    const res = await fetch(`/api/admin/products/${slug}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: !active }),
    })
    setLoading(null)
    if (res.ok) {
      push({ title: !active ? 'Produto ativado' : 'Produto desativado', tone: 'success' })
      router.refresh()
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      {products.map((product) => (
        <Card key={product.slug} className="flex flex-col p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-[15px] font-semibold text-navy-950">{product.name}</p>
              <p className="mt-0.5 text-[12.5px] text-navy-400">{product.tagline}</p>
            </div>
            <Badge tone={product.active ? 'positive' : 'neutral'}>{product.active ? 'Ativo' : 'Inativo'}</Badge>
          </div>

          <div className="mt-5 flex items-end gap-2.5">
            <Input
              label="Preço (R$)"
              value={prices[product.slug]}
              onChange={(e) => setPrices((p) => ({ ...p, [product.slug]: e.target.value }))}
            />
            <Button variant="outline" size="sm" loading={loading === `price-${product.slug}`} onClick={() => savePrice(product.slug)}>
              Salvar
            </Button>
          </div>

          <p className="mt-3 text-[12px] text-navy-300">Campos incluídos: {product.fields.length} · Ordem: {product.order}</p>

          <Button
            variant="outline"
            size="sm"
            className="mt-4 w-fit"
            loading={loading === `active-${product.slug}`}
            onClick={() => toggleActive(product.slug, product.active)}
          >
            {product.active ? 'Desativar produto' : 'Ativar produto'}
          </Button>

          <p className="mt-4 text-[13px] font-bold text-navy-950">{formatCurrencyBRL(product.priceCents)} atual</p>
        </Card>
      ))}
    </div>
  )
}
