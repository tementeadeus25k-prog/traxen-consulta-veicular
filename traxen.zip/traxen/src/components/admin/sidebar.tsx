'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Logo } from '@/components/ui/logo'
import { Icon } from '@/components/ui/icons'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/admin', label: 'Dashboard', icon: Icon.LayoutGrid, exact: true },
  { href: '/admin/clientes', label: 'Clientes', icon: Icon.Users },
  { href: '/admin/consultas', label: 'Consultas', icon: Icon.History },
  { href: '/admin/produtos', label: 'Produtos e preços', icon: Icon.Card },
  { href: '/admin/cupons', label: 'Cupons', icon: Icon.Ticket },
  { href: '/admin/logs', label: 'Logs de auditoria', icon: Icon.Logs },
]

export function AdminSidebarContent({ name, email }: { name: string; email: string }) {
  const pathname = usePathname()
  const router = useRouter()

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/')
    router.refresh()
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-[68px] items-center justify-between px-6">
        <Link href="/admin">
          <Logo />
        </Link>
        <Badge tone="navy">Admin</Badge>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2">
        {NAV.map((item) => {
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'group mb-0.5 flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13.5px] font-medium transition-colors',
                active ? 'bg-electric-50 text-electric-700' : 'text-navy-500 hover:bg-navy-50 hover:text-navy-900',
              )}
            >
              <item.icon className={cn('h-[18px] w-[18px]', active ? 'text-electric-600' : 'text-navy-300 group-hover:text-navy-500')} />
              {item.label}
            </Link>
          )
        })}
      </nav>

      <div className="border-t border-surface-border p-4">
        <div className="flex items-center gap-3 rounded-xl px-2 py-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-navy-950 text-[13px] font-semibold text-white">
            {name.slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-semibold text-navy-950">{name}</p>
            <p className="truncate text-[12px] text-navy-300">{email}</p>
          </div>
          <button
            onClick={handleLogout}
            aria-label="Sair"
            className="focus-ring flex h-8 w-8 items-center justify-center rounded-lg text-navy-300 hover:bg-critical-50 hover:text-critical-600"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}
