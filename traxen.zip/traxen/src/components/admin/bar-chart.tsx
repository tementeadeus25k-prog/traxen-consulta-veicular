export function BarChart({ data, formatValue }: { data: { label: string; value: number }[]; formatValue?: (v: number) => string }) {
  const max = Math.max(...data.map((d) => d.value), 1)
  return (
    <div className="flex h-[180px] items-end gap-2.5">
      {data.map((d) => {
        const heightPct = Math.max(4, (d.value / max) * 100)
        return (
          <div key={d.label} className="group flex flex-1 flex-col items-center gap-2">
            <div className="relative flex h-[140px] w-full items-end">
              <div
                className="w-full rounded-md bg-electric-500/85 transition-all duration-500 ease-out group-hover:bg-electric-500"
                style={{ height: `${heightPct}%` }}
              />
              <div className="pointer-events-none absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-md bg-navy-950 px-2 py-1 text-[11px] font-semibold text-white opacity-0 transition-opacity group-hover:opacity-100">
                {formatValue ? formatValue(d.value) : d.value}
              </div>
            </div>
            <span className="text-[11px] font-medium text-navy-300">{d.label}</span>
          </div>
        )
      })}
    </div>
  )
}
