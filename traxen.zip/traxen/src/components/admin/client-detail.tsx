'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useToast } from '@/components/ui/toast'
import { QueryStatusBadge } from '@/components/dashboard/query-status-badge'
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table'
import { cn, formatCurrencyBRL, formatDate } from '@/lib/utils'
import type { AuditLogEntry, StoredQuery, StoredUser, WalletTransaction } from '@/lib/store'

const TABS = ['Dados', 'Consultas', 'Pagamentos', 'Saldo', 'Logs'] as const

export function ClientDetail({
  client,
  queries,
  wallet,
  logs,
}: {
  client: StoredUser
  queries: StoredQuery[]
  wallet: WalletTransaction[]
  logs: AuditLogEntry[]
}) {
  const router = useRouter()
  const { push } = useToast()
  const [tab, setTab] = React.useState<(typeof TABS)[number]>('Dados')
  const [name, setName] = React.useState(client.name)
  const [phone, setPhone] = React.useState(client.phone)
  const [creditAmount, setCreditAmount] = React.useState('50,00')
  const [loading, setLoading] = React.useState<string | null>(null)

  async function callAction(action: string, extra?: Record<string, unknown>) {
    setLoading(action)
    const res = await fetch(`/api/admin/clients/${client.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...extra }),
    })
    setLoading(null)
    if (res.ok) {
      push({ title: 'Alteração aplicada com sucesso', tone: 'success' })
      router.refresh()
    } else {
      const data = await res.json().catch(() => ({}))
      push({ title: 'Não foi possível aplicar a alteração', description: data.error, tone: 'error' })
    }
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-navy-950 text-[18px] font-bold text-white">
            {client.name.slice(0, 1)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-[20px] font-bold text-navy-950">{client.name}</h1>
              <Badge tone={client.status === 'ativo' ? 'positive' : 'critical'}>{client.status === 'ativo' ? 'Ativo' : 'Bloqueado'}</Badge>
            </div>
            <p className="text-[13px] text-navy-400">{client.email} · {client.phone}</p>
          </div>
        </div>
        <div className="flex gap-2.5">
          {client.status === 'ativo' ? (
            <Button variant="outline" loading={loading === 'block'} onClick={() => callAction('block')} className="border-critical-200 text-critical-600 hover:bg-critical-50">
              Bloquear conta
            </Button>
          ) : (
            <Button variant="outline" loading={loading === 'unblock'} onClick={() => callAction('unblock')}>
              Desbloquear
            </Button>
          )}
        </div>
      </div>

      <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl bg-navy-50 p-1">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              'shrink-0 rounded-lg px-4 py-2 text-[13px] font-semibold transition-colors',
              tab === t ? 'bg-white text-navy-950 shadow-xs' : 'text-navy-400 hover:text-navy-700',
            )}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Dados' && (
        <Card className="max-w-lg p-7">
          <div className="grid gap-4">
            <Input label="Nome" value={name} onChange={(e) => setName(e.target.value)} />
            <Input label="Telefone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <Input label="E-mail" value={client.email} disabled />
            <Button loading={loading === 'update'} onClick={() => callAction('update', { name, phone })} className="w-fit">
              Salvar alterações
            </Button>
          </div>
        </Card>
      )}

      {tab === 'Consultas' && (
        <Card>
          {queries.length === 0 ? (
            <p className="px-6 py-10 text-center text-[13.5px] text-navy-400">Nenhuma consulta.</p>
          ) : (
            <Table>
              <THead>
                <tr><TH>Data</TH><TH>Placa</TH><TH>Produto</TH><TH>Status</TH></tr>
              </THead>
              <TBody>
                {queries.map((q) => (
                  <TR key={q.id}>
                    <TD>{formatDate(q.createdAt)}</TD>
                    <TD className="font-mono-plate font-semibold">{q.plate}</TD>
                    <TD>{q.productName}</TD>
                    <TD><QueryStatusBadge status={q.status} /></TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          )}
        </Card>
      )}

      {tab === 'Pagamentos' && (
        <Card>
          {queries.length === 0 ? (
            <p className="px-6 py-10 text-center text-[13.5px] text-navy-400">Nenhum pagamento.</p>
          ) : (
            <Table>
              <THead>
                <tr><TH>Data</TH><TH>Descrição</TH><TH className="text-right">Valor</TH><TH>Status</TH></tr>
              </THead>
              <TBody>
                {queries.map((q) => (
                  <TR key={q.id}>
                    <TD>{formatDate(q.createdAt, true)}</TD>
                    <TD>{q.productName} · {q.plate}</TD>
                    <TD className="text-right font-semibold">{formatCurrencyBRL(q.priceCents)}</TD>
                    <TD><QueryStatusBadge status={q.status} /></TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          )}
        </Card>
      )}

      {tab === 'Saldo' && (
        <div className="flex flex-col gap-6">
          <Card className="max-w-md p-7">
            <p className="text-[13px] font-medium text-navy-400">Saldo atual</p>
            <p className="mt-1 text-[26px] font-bold text-navy-950">{formatCurrencyBRL(client.walletCents)}</p>
            <div className="mt-5 flex items-end gap-3">
              <Input label="Valor (R$)" value={creditAmount} onChange={(e) => setCreditAmount(e.target.value)} className="max-w-[140px]" />
              <Button
                loading={loading === 'credit-add'}
                onClick={() => callAction('credit', { amountCents: Math.round(parseFloat(creditAmount.replace(',', '.')) * 100) }).then(() => {})}
                variant="outline"
              >
                Adicionar
              </Button>
              <Button
                variant="outline"
                loading={loading === 'credit-remove'}
                className="border-critical-200 text-critical-600 hover:bg-critical-50"
                onClick={() => callAction('credit', { amountCents: -Math.round(parseFloat(creditAmount.replace(',', '.')) * 100) })}
              >
                Remover
              </Button>
            </div>
          </Card>
          <Card>
            <Table>
              <THead>
                <tr><TH>Data</TH><TH>Descrição</TH><TH className="text-right">Valor</TH><TH className="text-right">Saldo</TH></tr>
              </THead>
              <TBody>
                {wallet.map((w) => (
                  <TR key={w.id}>
                    <TD>{formatDate(w.createdAt, true)}</TD>
                    <TD>{w.description}</TD>
                    <TD className={cn('text-right font-semibold', w.amountCents > 0 ? 'text-positive-600' : 'text-critical-600')}>
                      {w.amountCents > 0 ? '+' : ''}{formatCurrencyBRL(w.amountCents)}
                    </TD>
                    <TD className="text-right font-semibold">{formatCurrencyBRL(w.balanceAfterCents)}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          </Card>
        </div>
      )}

      {tab === 'Logs' && (
        <Card>
          {logs.length === 0 ? (
            <p className="px-6 py-10 text-center text-[13.5px] text-navy-400">Nenhum log relacionado a este cliente.</p>
          ) : (
            <ul className="divide-y divide-surface-border">
              {logs.map((l) => (
                <li key={l.id} className="flex items-center justify-between px-6 py-3.5 text-[13px]">
                  <div>
                    <p className="font-semibold text-navy-800">{l.action}</p>
                    {l.meta && <p className="text-navy-400">{l.meta}</p>}
                  </div>
                  <span className="text-navy-300">{formatDate(l.createdAt, true)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
    </div>
  )
}
